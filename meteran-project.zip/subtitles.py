#!/usr/bin/env python3
"""Subtitles from the word timing of the voiceover (the output of timing.py).
  python3 subtitles.py [--words work/words.json] [--script work/script.txt] [--out work] [--style short|classic]
                       [--karaoke] [--font NAME] [--size N] [--max-chars N] [--max-words N] [--y 0.705] [--outline N]
Writes <out>/subs.srt (any player / editor) and <out>/subs.ass (styled for the 1080x1920 frame; finish.sh burns it into
out/<Title>-sub.mp4). The clean master video is never touched: subtitles are a separate layer built after the render.

--style short (default, matches the user's reference frames): 1-3 words per cue (at most 16 characters, ONE line), natural case with
          the script's punctuation, heavy white text (Montserrat ExtraBold, bundled in fonts/; 106 px: same width AND height as the reference text) with a thin black outline (5 px), always at the same spot: centre at 70.5 % of the
          frame height (y = 1354 px of 1920). A new cue starts on its first word; it stays until the next cue starts (or 0.25 s after
          the last word before a pause).
--style classic: 2 balanced lines of 22 characters near the bottom, a few seconds per cue (a calmer, longer-form look).
--script: the exact script text. Whisper makes spelling mistakes (especially in Indonesian), so the script's wording replaces the
          recognised words and keeps their timing (matched by sequence; missing spots are interpolated).
--karaoke: the word being spoken is highlighted (yellow) inside the cue (most useful with --style classic)."""
import argparse, difflib, json, os, re

ap = argparse.ArgumentParser()
ap.add_argument("--words", default="work/words.json"); ap.add_argument("--script"); ap.add_argument("--out", default="work")
ap.add_argument("--style", choices=["short", "classic"], default="short"); ap.add_argument("--karaoke", action="store_true")
ap.add_argument("--font"); ap.add_argument("--size", type=int); ap.add_argument("--max-chars", type=int); ap.add_argument("--max-words", type=int)
ap.add_argument("--scale-x", type=int, help="horizontal text scale in %% (default 100)")
ap.add_argument("--y", type=float, help="vertical centre as a fraction of the frame height (short style)"); ap.add_argument("--outline", type=int)
ap.add_argument("--margin-v", type=int, default=320, help="classic style: distance from the bottom edge, px")
A = ap.parse_args()
SHORT = A.style == "short"
A.font = A.font or ("Montserrat ExtraBold" if SHORT else "DejaVu Sans"); A.size = A.size or (106 if SHORT else 68); A.scale_x = A.scale_x or 100
A.max_chars = A.max_chars or (16 if SHORT else 22); A.max_words = A.max_words or (3 if SHORT else 99)
A.y = A.y if A.y is not None else 0.705; A.outline = A.outline or (5 if SHORT else max(3, A.size // 11))

words = json.load(open(A.words, encoding="utf-8"))
if not words: raise SystemExit("words.json is empty: run timing.py first")
norm = lambda t: re.sub(r"[\W_]+", "", t.lower())

# ---- tokens with timing: the script's words (if given) on the recognised timing, else the recognised words
if A.script:
    raw = open(A.script, encoding="utf-8").read() if os.path.exists(A.script) else A.script
    toks = raw.split()
    S = [None] * len(toks); E = [None] * len(toks)
    sm = difflib.SequenceMatcher(None, [norm(w["w"]) for w in words], [norm(t) for t in toks], autojunk=False)
    for blk in sm.get_matching_blocks():
        for k in range(blk.size): S[blk.b + k] = words[blk.a + k]["s"]; E[blk.b + k] = words[blk.a + k]["e"]
    i = 0
    while i < len(toks):                                  # interpolate every run of unmatched script words between its anchors
        if S[i] is not None: i += 1; continue
        j = i
        while j < len(toks) and S[j] is None: j += 1
        left = E[i - 1] if i > 0 else words[0]["s"]; right = S[j] if j < len(toks) else words[-1]["e"]
        right = max(right, left + 0.05 * (j - i)); wt = [max(1, len(norm(t))) for t in toks[i:j]]; t = left
        for k in range(i, j): d = (right - left) * wt[k - i] / sum(wt); S[k], E[k] = t, t + d; t += d
        i = j
    toks_t = [{"w": toks[k], "s": S[k], "e": E[k]} for k in range(len(toks))]
    hit = sum(b.size for b in sm.get_matching_blocks())
    print(f"script words {len(toks)}, matched to the recognised words: {hit} ({100 * hit // max(1, len(toks))} %)")
else:
    toks_t = [dict(w) for w in words]

# ---- cues
cues, cur = [], []
def flush():
    global cur
    if cur: cues.append(cur); cur = []
for w in toks_t:
    chars = sum(len(x["w"]) + 1 for x in cur) - 1 if cur else 0
    if cur and (chars + 1 + len(w["w"]) > (A.max_chars if SHORT else A.max_chars * 2) or len(cur) >= A.max_words): flush()
    if cur and w["s"] - cur[-1]["e"] > (0.35 if SHORT else 0.6): flush()
    cur.append(w); t = w["w"]
    if SHORT:
        if re.search(r"[,.;:!?…]['\")\]]*$", t): flush()           # every punctuation mark ends a cue ("Well," / "After you.")
    elif re.search(r"[.!?…]['\")\]]*$", t): flush()
    elif re.search(r"[,;:]$", t) and sum(len(x["w"]) + 1 for x in cur) >= 14: flush()
flush()

def split_lines(ws):                                       # classic: at most 2 balanced lines; index where line 2 starts (or None)
    if SHORT or len(" ".join(x["w"] for x in ws)) <= A.max_chars or len(ws) < 2: return None
    best, bi = 10 ** 9, None
    for i in range(1, len(ws)):
        a = len(" ".join(x["w"] for x in ws[:i])); b = len(" ".join(x["w"] for x in ws[i:]))
        if max(a, b) < best: best, bi = max(a, b), i
    return bi

# ---- timing of each cue
T = []
for k, c in enumerate(cues):
    nxt = cues[k + 1][0]["s"] if k + 1 < len(cues) else None
    if SHORT:
        s = c[0]["s"]; e = c[-1]["e"] + 0.25
        if nxt is not None and nxt - c[-1]["e"] < 0.3: e = nxt                    # continuous speech: no blank frame between cues
        T.append([s, max(e, s + 0.2)])
    else: T.append([max(0.0, c[0]["s"] - 0.05), c[-1]["e"] + 0.2])
for i, (s, e) in enumerate(T):
    nxt = T[i + 1][0] if i + 1 < len(T) else 1e9; prv = T[i - 1][1] if i else 0.0
    s = max(s, prv); e = max(e, s + (0.2 if SHORT else 0.7)); e = min(e, nxt - 0.02) if nxt - 0.02 > s + 0.15 else e
    T[i] = [s, e]
os.makedirs(A.out, exist_ok=True)

def tc_srt(t): t = max(0, t); h, r = divmod(int(round(t * 1000)), 3600000); m, r = divmod(r, 60000); s, ms = divmod(r, 1000); return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
def tc_ass(t): t = max(0, t); cs = int(round(t * 100)); h, r = divmod(cs, 360000); m, r = divmod(r, 6000); s, c = divmod(r, 100); return f"{h}:{m:02d}:{s:02d}.{c:02d}"

srt = []; ass = []
POS = "{\\an5\\pos(540,%d)}" % round(1920 * A.y) if SHORT else ""
for n, (c, (s, e)) in enumerate(zip(cues, T), 1):
    br = split_lines(c)
    l1 = " ".join(x["w"] for x in c[:br]) if br else " ".join(x["w"] for x in c)
    txt = l1 + ("\n" + " ".join(x["w"] for x in c[br:]) if br else "")
    srt.append(f"{n}\n{tc_srt(s)} --> {tc_srt(e)}\n{txt}\n")
    if A.karaoke:
        parts = []
        for k, x in enumerate(c):
            nxt = c[k + 1]["s"] if k + 1 < len(c) else max(x["e"], e - 0.2)
            parts.append(("\\N" if br and k == br else "") + "{\\k%d}%s " % (max(1, round((nxt - x["s"]) * 100)), re.sub(r"[{}]", "", x["w"])))
        body = "{\\k%d}" % round((c[0]["s"] - s) * 100) + "".join(parts).rstrip() if c[0]["s"] > s else "".join(parts).rstrip()
    else:
        body = re.sub(r"[{}]", "", txt).replace("\n", "\\N")
    ass.append(f"Dialogue: 0,{tc_ass(s)},{tc_ass(e)},Sub,,0,0,0,,{POS}{body}")

open(os.path.join(A.out, "subs.srt"), "w", encoding="utf-8").write("\n".join(srt))
prim, sec = ("&H0000E6FF", "&H00FFFFFF") if A.karaoke else ("&H00FFFFFF", "&H00FFFFFF")      # karaoke: spoken word turns yellow
align, mv = (5, 0) if SHORT else (2, A.margin_v)
head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,{A.font},{A.size},{prim},{sec},&H00000000,&H80000000,-1,0,0,0,{A.scale_x},100,0,0,1,{A.outline},{2 if SHORT else 0},{align},60,60,{mv},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
open(os.path.join(A.out, "subs.ass"), "w", encoding="utf-8").write(head + "\n".join(ass) + "\n")
print(f"{len(cues)} cues -> {A.out}/subs.srt, {A.out}/subs.ass ({A.style}{', karaoke' if A.karaoke else ''}, font {A.font} {A.size}px, outline {A.outline})")
