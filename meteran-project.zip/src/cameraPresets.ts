/**
 * cameraPresets.ts — pustaka preset kamera untuk skill cartoon-3d-short.
 *
 * Preset BUKAN angka dunia (pos/look) yang ditulis tangan. Preset adalah resep relatif terhadap subjek:
 *   target (titik yang dibingkai) + size (tinggi/lebar subjek, meter) + facing (arah hadap subjek).
 * Setiap preset menghasilkan `Key[]` yang formatnya sama dengan CAMS di story.ts, jadi bisa langsung dipakai:
 *   CAMS[shotId] = keysDariPreset
 *
 * Aturan dari references/reports/motion.md yang ditegakkan di sini:
 *  - gerakan = glide smootherstep (bukan snap), puncak kecepatan <= ~25 px/f pada 720p (di-autofit);
 *  - tidak ada hold statis: setiap segmen punya creep push-in (0.15-0.35 %/f) kecuali sengaja diubah;
 *  - reframe besar = cut (segmen baru dengan cut:true), bukan terbang;
 *  - roll 4-8 derajat hanya di beat penekanan; dampak = kick, bukan getaran sinus.
 */
export type V3 = [number, number, number];
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
export type Shot = Partial<Cam> & { pos: V3; look: V3 };
export type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export type Tgt = V3 | ((f: number) => V3);

export const FPS = 30;
export const SPEED_LIMIT = 25; // px/f pada 720x1280 (p75 referensi)
/** Skala lensa yang diterapkan SATU KALI oleh story.ts (camAt): fov_render = fov_preset * FOV_SCALE.
 *  Preset selalu mengeluarkan FOV DASAR (34-46 derajat vertikal) dan posisi kamera dihitung dari FOV dasar itu, jadi
 *  FOV_SCALE hanya melebarkan lensa dari posisi yang sama. JANGAN mengalikannya lagi di sini atau di CAMS.
 *  Di sini ia dipakai hanya untuk mengukur kecepatan layar (lensa lebar = piksel per derajat lebih sedikit). */
export const FOV_SCALE = 1.35;
export const renderFov = (fov: number, k: number = FOV_SCALE) => fov * k;
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const EASE = {
  glide,
  lin: clamp01,
  in: (u: number) => clamp01(u) ** 2.2,
  out: (u: number) => 1 - (1 - clamp01(u)) ** 2.2,
};
export type EaseName = keyof typeof EASE;
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const rad = (d: number) => (d * Math.PI) / 180;

// ---------------------------------------------------------------- taksonomi
export type Beat = 'hook' | 'establish' | 'setup' | 'introduce' | 'escalate' | 'explain' | 'reveal' | 'impact'
  | 'aftermath' | 'punchline' | 'transition' | 'tension' | 'callback';
export type Kind = 'character' | 'twoShot' | 'crowd' | 'prop' | 'flat' | 'tall' | 'place' | 'mover' | 'fall' | 'interior';
export type SizeClass = 'ecu' | 'cu' | 'ms' | 'ws' | 'vws';
export type Motion = 'push' | 'pull' | 'orbit' | 'tilt' | 'pan' | 'track' | 'crane' | 'zoom' | 'static' | 'whip' | 'roll' | 'cut';
export type Angle = 'low' | 'eye' | 'high' | 'top' | 'dutch';

/** kepribadian kamera per video: inilah yang membuat dua video dengan cerita mirip tetap terasa berbeda */
export type Personality = {
  name: string;
  fov: number;       // lensa DASAR (derajat vertikal), sebelum FOV_SCALE; lensa render = fov * FOV_SCALE
  frame: number;     // pengali jarak bingkai (<1 lebih dekat, >1 lebih lebar)
  push: number;      // laju creep push-in dasar per frame
  roll: number;      // pengali roll (0 = tanpa dutch)
  elBias: number;    // tambahan elevasi (derajat) untuk sudut non-top-down
  whipOk: boolean;
  weights: Partial<Record<Motion | Angle | SizeClass, number>>;
};

/** pose kamera relatif subjek. az/el/roll dalam radian di sini; preset menulisnya dalam derajat lewat pose() */
export type Pose = { az: number; el: number; dist: number; fov: number; roll: number; off: V3 };

export type Seg = {
  at: number;            // awal segmen sebagai pecahan 0..1 dari durasi shot
  from?: Pose;           // wajib untuk segmen pertama dan segmen cut; selain itu = pose akhir segmen sebelumnya
  to?: Partial<Pose>;    // tujuan gerak (kosong = hanya creep)
  len?: number;          // panjang gerak sebagai pecahan dari span segmen (default 1)
  fr?: number;           // atau panjang gerak dalam frame (menimpa len)
  ease?: EaseName;
  push?: number;         // laju creep per frame (negatif = pull-out)
  cut?: boolean;         // potong keras di awal segmen
  fast?: boolean;        // gerak cepat yang disengaja (snap zoom, whip, jatuh): tidak di-autofit
  kick?: number;         // gain kick dampak (lihat kickAt di story.ts)
  kickEnd?: boolean;     // kick di akhir gerak, bukan di awal
  whip?: boolean;        // beri tanda motion blur
};
export type DofHint = { at: number; cInf: number; focus: 'target' | 'look' | 'near'; dur?: number };
export type FxHint = { kind: 'iris'; at: number; len: number };
export type Plan = { segs: Seg[]; dof?: DofHint[]; fx?: FxHint[] };

export type Ctx = {
  a: number; b: number;            // frame awal/akhir shot
  target: Tgt; size: number;       // titik bingkai dan ukuran subjek (m)
  facing: number;                  // yaw subjek (rad); gaya story.ts: depan = (sin f, 0, cos f)
  side: 1 | -1;                    // cermin kiri/kanan
  rnd: () => number;
  pers: Personality;
  kind: Kind;
  emphasisF?: number;              // frame kata penekanan (untuk ecu_punch, snap_zoom)
  impactF?: number;                // frame dampak (untuk kick_slam_cut)
  groundY?: number;                // lantai: kamera tidak boleh turun di bawahnya
  fovScale?: number;               // skala lensa story.ts untuk pengukuran kecepatan (default FOV_SCALE)
};

export type Preset = {
  name: string; family: string; size: SizeClass; motion: Motion; angle: Angle; energy: 1 | 2 | 3 | 4 | 5;
  beats: Beat[]; kinds: Kind[]; minFrames: number; maxUse?: number; note: string;
  plan: (c: Ctx) => Plan;
};

// ---------------------------------------------------------------- helper preset
const r = (c: Ctx, lo: number, hi: number) => lo + (hi - lo) * c.rnd();
const fr = (c: Ctx, k: number) => c.size * k; // tinggi bingkai terlihat = k x ukuran subjek
const tgtAt = (t: Tgt, f: number): V3 => (typeof t === 'function' ? t(f) : t);
const half = (c: Ctx, f: number) => tgtAt(c.target, f);

export const pose = (
  c: Ctx,
  o: { frame: number; fov?: number; az?: number; el?: number; roll?: number; off?: V3 },
): Pose => {
  const fov = o.fov ?? c.pers.fov;
  const el = o.el ?? 0;
  const elAdj = Math.abs(el) > 60 ? el : el + c.pers.elBias;
  return {
    az: rad(o.az ?? 0) * c.side, el: rad(elAdj), fov, roll: rad((o.roll ?? 0) * c.pers.roll) * c.side,
    dist: (o.frame * c.pers.frame) / (2 * Math.tan(rad(fov) / 2)), off: o.off ?? [0, 0, 0],
  };
};
const mixPose = (a: Pose, b: Pose, k: number): Pose => ({
  az: lerp(a.az, b.az, k), el: lerp(a.el, b.el, k), dist: lerp(a.dist, b.dist, k), fov: lerp(a.fov, b.fov, k),
  roll: lerp(a.roll, b.roll, k), off: [lerp(a.off[0], b.off[0], k), lerp(a.off[1], b.off[1], k), lerp(a.off[2], b.off[2], k)],
});
const zoomFov = (fov: number, k: number) => (360 / Math.PI) * Math.atan(Math.tan(rad(fov) / 2) * k);

// ---------------------------------------------------------------- matematika kamera
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const len3 = (a: V3) => Math.hypot(a[0], a[1], a[2]);
const nrm = (a: V3): V3 => { const l = len3(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

/** proyeksi titik dunia ke piksel layar 720x1280 (pusat = 0,0; y ke atas). null jika di belakang kamera */
export const projectPx = (cam: Cam, p: V3): [number, number] | null => {
  const fwd = nrm(sub(cam.look, cam.pos));
  let right = cross(fwd, [0, 1, 0]);
  if (len3(right) < 1e-6) right = [1, 0, 0];
  right = nrm(right);
  const up = cross(right, fwd);
  const cr = Math.cos(cam.roll), sr = Math.sin(cam.roll);
  const rx: V3 = [right[0] * cr + up[0] * sr, right[1] * cr + up[1] * sr, right[2] * cr + up[2] * sr];
  const ry: V3 = [-right[0] * sr + up[0] * cr, -right[1] * sr + up[1] * cr, -right[2] * sr + up[2] * cr];
  const rel = sub(p, cam.pos), z = dot(rel, fwd);
  if (z <= 1e-3) return null;
  const t = Math.tan(rad(cam.fov) / 2);
  return [(dot(rel, rx) / (z * t * 0.5625)) * 360, (dot(rel, ry) / (z * t)) * 640];
};
const visH = (c: Cam) => Math.tan(rad(c.fov) / 2) * len3(sub(c.look, c.pos));

/** perkiraan kecepatan layar (px/f @720p) antara dua frame: pergeseran titik look + titik jauh di belakangnya + zoom.
 *  Pendekatan, bukan pengukuran render: cukup untuk menandai gerakan yang jauh lebih cepat dari referensi. */
export const camSpeedPx = (prev: Cam, cur: Cam): number => {
  const fwd = nrm(sub(prev.look, prev.pos)), d = len3(sub(prev.look, prev.pos));
  const far: V3 = [prev.look[0] + fwd[0] * d * 1.5, prev.look[1] + fwd[1] * d * 1.5, prev.look[2] + fwd[2] * d * 1.5];
  const m = (p: V3) => { const q = projectPx(cur, p); return q ? Math.hypot(q[0], q[1]) : 2000; };
  const pan = 0.5 * (m(prev.look) + m(far));
  return pan + Math.abs(Math.log(visH(cur) / visH(prev))) * 734;
};

// ---------------------------------------------------------------- compile: Seg[] -> Key[]
type Node = { fa: number; fb: number; seg: Seg; from: Pose; to: Pose | null; span: number; group: number };

const evalNode = (c: Ctx, n: Node, f: number): Pose => {
  const k = n.to ? EASE[n.seg.ease ?? 'glide']((f - n.fa) / n.span) : 0;
  const p = mixPose(n.from, n.to ?? n.from, k);
  const rate = n.seg.push ?? c.pers.push;
  return { ...p, dist: p.dist * Math.exp(-rate * Math.max(0, f - n.fa)) };
};

const toShot = (c: Ctx, p: Pose, f: number): Shot => {
  const T = tgtAt(c.target, f), fa = c.facing;
  const sx = Math.sin(fa), cx = Math.cos(fa);
  // off lokal: x kanan, y atas, z maju (arah hadap subjek)
  const look: V3 = [T[0] + p.off[0] * cx + p.off[2] * sx, T[1] + p.off[1], T[2] - p.off[0] * sx + p.off[2] * cx];
  const a = fa + p.az, ce = Math.cos(p.el);
  const pos: V3 = [look[0] + p.dist * Math.sin(a) * ce, look[1] + p.dist * Math.sin(p.el), look[2] + p.dist * Math.cos(a) * ce];
  if (c.groundY !== undefined) pos[1] = Math.max(pos[1], c.groundY + 0.25);
  return { pos, look, fov: p.fov, roll: p.roll };
};
const camOf = (c: Ctx, n: Node, f: number): Cam => {
  const s = toShot(c, evalNode(c, n, f), f);
  return { pos: s.pos, look: s.look, fov: renderFov(s.fov ?? 40, c.fovScale ?? FOV_SCALE), roll: s.roll ?? 0 };
};

/** kecilkan gerak sampai puncak kecepatan <= SPEED_LIMIT (durasi shot tetap, jadi jaraknya yang dikurangi) */
const fit = (c: Ctx, n: Node) => {
  for (let it = 0; it < 5 && n.to; it++) {
    let peak = 0, prev = camOf(c, n, n.fa);
    const end = Math.min(n.fb, n.fa + Math.ceil(n.span));
    for (let f = n.fa + 1; f <= end; f++) { const cur = camOf(c, n, f); peak = Math.max(peak, camSpeedPx(prev, cur)); prev = cur; }
    if (peak <= SPEED_LIMIT) return;
    n.to = mixPose(n.from, n.to, Math.max(0.12, (SPEED_LIMIT / peak) * 0.96));
  }
};

export type Mark = { f: number; kind: 'kick' | 'whip' | 'iris' | 'cut'; g?: number; len?: number };

export const compile = (c: Ctx, segs: Seg[]): { keys: Key[]; marks: Mark[] } => {
  const nodes: Node[] = [], marks: Mark[] = [];
  let group = -1;
  segs.forEach((seg, i) => {
    const fa = Math.round(c.a + seg.at * (c.b - c.a));
    const fb = i + 1 < segs.length ? Math.round(c.a + segs[i + 1].at * (c.b - c.a)) : c.b;
    const isCut = i === 0 || !!seg.cut;
    if (isCut) group++;
    let from = seg.from;
    if (!from) {
      if (i === 0 || isCut) throw new Error(`segmen ${i} butuh 'from'`);
      from = evalNode(c, nodes[i - 1], nodes[i - 1].fb);
    }
    const span = Math.max(1, seg.fr ?? (fb - fa) * (seg.len ?? 1));
    const n: Node = { fa, fb, seg, from, to: seg.to ? { ...from, ...seg.to } : null, span, group };
    if (n.to && !seg.fast) fit(c, n);
    nodes.push(n);
    if (i > 0 && isCut) marks.push({ f: fa, kind: 'cut' });
    if (seg.kick) marks.push({ f: seg.kickEnd ? Math.round(fa + span) : fa, kind: 'kick', g: seg.kick });
    if (seg.whip) marks.push({ f: fa, kind: 'whip', len: Math.round(span) });
  });
  const keys: Key[] = [];
  for (let g = 0; g <= group; g++) {
    const mine = nodes.filter((n) => n.group === g);
    keys.push({
      f: mine[0].fa, cut: g > 0 || undefined,
      s: (f) => {
        let n = mine[0];
        for (const m of mine) if (f >= m.fa) n = m;
        return toShot(c, evalNode(c, n, f), f);
      },
    });
  }
  return { keys, marks };
};

// ---------------------------------------------------------------- PRESET
/** fraksi shot tempat kata penekanan/dampak jatuh (untuk preset yang memotong di sana) */
const frac = (c: Ctx, f: number | undefined, fallback: number) =>
  f === undefined ? fallback : Math.min(0.85, Math.max(0.2, (f - c.a) / (c.b - c.a)));

export const PRESETS: Preset[] = [
  // ----- ESTABLISH / TEMPAT -----
  {
    name: 'wide_push', family: 'establish', size: 'ws', motion: 'push', angle: 'high', energy: 2, minFrames: 45,
    beats: ['hook', 'establish', 'setup', 'callback', 'aftermath'], kinds: ['place', 'crowd', 'character', 'mover'],
    note: 'Wide 3/4 dari atas, perlahan mendekat ke subjek. Dasar pembuka lokasi.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0015,
      from: pose(c, { frame: fr(c, r(c, 7, 10)), az: r(c, 25, 50), el: r(c, 16, 28) }),
      to: pose(c, { frame: fr(c, r(c, 4.5, 6.5)), az: r(c, 8, 22), el: r(c, 6, 12) }) }] }),
  },
  {
    name: 'crane_pullback', family: 'establish', size: 'ws', motion: 'crane', angle: 'high', energy: 3, minFrames: 90, maxUse: 1,
    beats: ['hook', 'reveal', 'transition', 'callback', 'aftermath', 'establish'], kinds: ['place', 'crowd', 'character', 'mover'],
    note: 'Crane naik dan mundur: dari dekat ke wide tinggi. Cocok untuk penutup atau pengungkapan skala.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0008, ease: 'glide',
      from: pose(c, { frame: fr(c, r(c, 1.8, 2.6)), az: r(c, -12, 12), el: r(c, 2, 8) }),
      to: pose(c, { frame: fr(c, r(c, 9, 12)), az: r(c, 25, 45), el: r(c, 26, 36) }) }] }),
  },
  {
    name: 'aerial_arc', family: 'establish', size: 'ws', motion: 'orbit', angle: 'high', energy: 2, minFrames: 70,
    beats: ['establish', 'reveal', 'aftermath', 'transition'], kinds: ['place', 'crowd'],
    note: 'Orbit lambat dari udara (kota melingkar, lapangan). Memberi rasa diorama.',
    plan: (c) => { const e = r(c, 30, 42), s = r(c, 25, 40); return { segs: [{ at: 0, push: 0.001,
      from: pose(c, { frame: fr(c, r(c, 8, 11)), az: -s, el: e }), to: pose(c, { frame: fr(c, r(c, 8, 11)), az: s, el: e + r(c, -4, 4) }) }] }; },
  },
  {
    name: 'topdown_pull', family: 'establish', size: 'vws', motion: 'pull', angle: 'top', energy: 2, minFrames: 60,
    beats: ['establish', 'explain', 'aftermath', 'reveal'], kinds: ['place', 'flat', 'crowd', 'prop'],
    note: 'Pandangan tegak lurus dari atas, menjauh pelan dengan roll kecil. Peta, arena, kerumunan.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0008, ease: 'lin',
      from: pose(c, { frame: fr(c, r(c, 7, 9)), el: 82, az: r(c, 0, 40) }),
      to: pose(c, { frame: fr(c, r(c, 11, 14)), el: 78, az: r(c, 10, 60), roll: r(c, 2, 5) }) }] }),
  },
  {
    name: 'one_point_push', family: 'establish', size: 'ws', motion: 'push', angle: 'eye', energy: 3, minFrames: 60,
    beats: ['establish', 'escalate', 'explain', 'tension'], kinds: ['place', 'interior', 'crowd'],
    note: 'Perspektif satu titik, simetris, maju menyusuri lorong atau aula. Tanpa roll.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.002,
      from: pose(c, { frame: fr(c, r(c, 6.5, 8)), az: 0, el: r(c, 1, 3), roll: 0 }),
      to: pose(c, { frame: fr(c, r(c, 3.2, 4.5)), az: 0, el: r(c, 1, 3), roll: 0 }) }] }),
  },
  {
    name: 'rise_reveal', family: 'establish', size: 'ws', motion: 'tilt', angle: 'low', energy: 3, minFrames: 75,
    beats: ['reveal', 'establish', 'escalate', 'hook'], kinds: ['tall', 'place', 'character'],
    note: 'Kamera naik dari bawah ke elevasi tinggi sambil look ikut naik; skala subjek terungkap.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.001, len: 0.85,
      from: pose(c, { frame: fr(c, r(c, 2.4, 3.2)), el: r(c, 1, 5), az: r(c, 5, 20) }),
      to: pose(c, { frame: fr(c, r(c, 4.5, 6)), el: r(c, 24, 34), az: r(c, 15, 35), off: [0, fr(c, 0.8), 0] }) }] }),
  },
  {
    name: 'crowd_dolly', family: 'establish', size: 'ws', motion: 'track', angle: 'eye', energy: 3, minFrames: 60,
    beats: ['establish', 'escalate', 'setup'], kinds: ['crowd', 'place'],
    note: 'Dolly menyamping melewati barisan kerumunan sambil sedikit maju.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0025,
      from: pose(c, { frame: fr(c, r(c, 4, 6)), az: r(c, -10, 10), el: r(c, 5, 10), off: [-fr(c, 0.6), 0, 0] }),
      to: pose(c, { frame: fr(c, r(c, 4, 6)), az: r(c, -10, 10), el: r(c, 5, 10), off: [fr(c, 0.6), 0, 0] }) }] }),
  },

  // ----- KARAKTER / DIALOG -----
  {
    name: 'ms_creep', family: 'character', size: 'ms', motion: 'push', angle: 'eye', energy: 1, minFrames: 20, maxUse: 3,
    beats: ['setup', 'introduce', 'explain', 'escalate', 'aftermath', 'callback'], kinds: ['character', 'twoShot', 'mover'],
    note: 'Medium shot setinggi mata dengan creep push-in. Kuda kerja; jangan lebih dari 3 kali per video.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0022,
      from: pose(c, { frame: fr(c, r(c, 2.2, 3)), az: r(c, 6, 20), el: r(c, 1, 5) }),
      to: pose(c, { frame: fr(c, r(c, 2, 2.6)), az: r(c, 2, 14), el: r(c, 1, 5) }) }] }),
  },
  {
    name: 'orbit_hero', family: 'character', size: 'ms', motion: 'orbit', angle: 'low', energy: 3, minFrames: 45,
    beats: ['hook', 'introduce', 'escalate', 'reveal', 'punchline', 'tension'], kinds: ['character', 'twoShot', 'prop'],
    note: 'Orbit pelan dengan sudut rendah; subjek terasa penting.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0015,
      from: pose(c, { frame: fr(c, r(c, 2.4, 3.2)), az: -r(c, 15, 25), el: r(c, 3, 8) }),
      to: pose(c, { frame: fr(c, r(c, 2, 2.8)), az: r(c, 25, 40), el: r(c, 6, 12) }) }] }),
  },
  {
    name: 'two_shot_roll', family: 'character', size: 'ms', motion: 'roll', angle: 'eye', energy: 2, minFrames: 60,
    beats: ['setup', 'introduce', 'explain', 'punchline'], kinds: ['twoShot', 'character'],
    note: 'Dua karakter di satu bingkai, lalu roll 4 derajat di kata penekanan.',
    plan: (c) => { const k = frac(c, c.emphasisF, 0.55); return { segs: [
      { at: 0, push: 0.002, from: pose(c, { frame: fr(c, r(c, 2.4, 3.2)), az: r(c, 8, 18), el: r(c, 1, 4), roll: r(c, -1.5, 1.5) }) },
      { at: Math.max(0.1, k - 0.08), push: 0.003, len: 0.35, ease: 'glide', to: pose(c, { frame: fr(c, 2.2), az: r(c, 4, 12), el: r(c, 1, 4), roll: r(c, 4, 5) }) },
    ] }; },
  },
  {
    name: 'side_track', family: 'character', size: 'ms', motion: 'track', angle: 'eye', energy: 3, minFrames: 40,
    beats: ['setup', 'introduce', 'escalate', 'tension', 'aftermath'], kinds: ['mover', 'character', 'crowd'],
    note: 'Kamera mengikuti dari samping (profil). Target harus berupa fungsi posisi bila subjek bergerak.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0008,
      from: pose(c, { frame: fr(c, r(c, 3, 4.5)), az: 90 - r(c, 0, 10), el: r(c, 2, 5), off: [0, 0, fr(c, 0.25)] }) }] }),
  },
  {
    name: 'walk_toward', family: 'character', size: 'ms', motion: 'pull', angle: 'eye', energy: 3, minFrames: 40,
    beats: ['setup', 'introduce', 'escalate', 'tension'], kinds: ['mover', 'crowd', 'character'],
    note: 'Kamera berjalan mundur di depan subjek yang mendekat (pull-out lambat).',
    plan: (c) => ({ segs: [{ at: 0, push: -0.0015,
      from: pose(c, { frame: fr(c, r(c, 2.6, 3.4)), az: r(c, -8, 8), el: r(c, 1, 4) }) }] }),
  },
  {
    name: 'cu_push', family: 'character', size: 'cu', motion: 'push', angle: 'eye', energy: 3, minFrames: 20, maxUse: 2,
    beats: ['hook', 'tension', 'escalate', 'punchline', 'setup'], kinds: ['character', 'twoShot'],
    note: 'Close-up wajah dengan push 0.35 %/f dan DOF tebal. Untuk reaksi dan ketegangan.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0035,
      from: pose(c, { frame: fr(c, r(c, 0.9, 1.3)), az: r(c, 5, 15), el: r(c, 0, 4) }) }],
      dof: [{ at: 0, cInf: 13, focus: 'target' }] }),
  },
  {
    name: 'hold_stare', family: 'character', size: 'cu', motion: 'push', angle: 'eye', energy: 1, minFrames: 20, maxUse: 2,
    beats: ['punchline', 'aftermath', 'callback', 'setup'], kinds: ['character', 'twoShot'],
    note: 'Tatapan deadpan: close-up tanpa roll, push sangat lambat. Untuk punchline kering.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0012,
      from: pose(c, { frame: fr(c, r(c, 1, 1.25)), az: r(c, 0, 6), el: r(c, 0, 2), roll: 0 }) }],
      dof: [{ at: 0, cInf: 12, focus: 'target' }] }),
  },
  {
    name: 'low_loom', family: 'character', size: 'cu', motion: 'push', angle: 'low', energy: 4, minFrames: 30, maxUse: 2,
    beats: ['hook', 'tension', 'impact', 'escalate', 'introduce'], kinds: ['character', 'tall', 'prop'],
    note: 'Sudut sangat rendah menjulang ke atas subjek, dengan sedikit roll. Ancaman atau kebanggaan.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.003,
      from: pose(c, { frame: fr(c, r(c, 1.6, 2.2)), el: -r(c, 10, 16), az: r(c, 8, 18), roll: r(c, 1.5, 3) }),
      to: pose(c, { frame: fr(c, r(c, 1.1, 1.5)), el: -r(c, 8, 14), az: r(c, 4, 12), roll: r(c, 2, 3.5) }) }] }),
  },
  {
    name: 'dutch_tense', family: 'character', size: 'cu', motion: 'roll', angle: 'dutch', energy: 4, minFrames: 30, maxUse: 2,
    beats: ['tension', 'escalate', 'impact', 'hook'], kinds: ['character', 'twoShot', 'prop'],
    note: 'Dutch angle 4-6 derajat bertahan sambil push lambat. Rasa tidak enak.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0035,
      from: pose(c, { frame: fr(c, r(c, 1.3, 2)), az: r(c, 10, 20), el: r(c, 0, 5), roll: r(c, 4, 6) }),
      to: pose(c, { frame: fr(c, r(c, 1, 1.5)), az: r(c, 6, 14), el: r(c, 0, 5), roll: r(c, 4.5, 7) }) }] }),
  },
  {
    name: 'ecu_punch', family: 'character', size: 'ecu', motion: 'cut', angle: 'eye', energy: 4, minFrames: 50, maxUse: 2,
    beats: ['punchline', 'impact', 'tension', 'hook', 'escalate'], kinds: ['character', 'twoShot'],
    note: 'Medium creep, lalu CUT ke extreme close-up tepat di kata penekanan (mata/mulut).',
    plan: (c) => { const k = frac(c, c.emphasisF, 0.6); return { segs: [
      { at: 0, push: 0.002, from: pose(c, { frame: fr(c, r(c, 2.4, 3)), az: r(c, 6, 16), el: r(c, 1, 4) }) },
      { at: k, cut: true, push: 0.0045, from: pose(c, { frame: fr(c, r(c, 0.4, 0.55)), az: r(c, -6, 6), el: r(c, 0, 3) }) },
    ], dof: [{ at: 0, cInf: 11, focus: 'target' }, { at: k, cInf: 14, focus: 'target' }] }; },
  },
  {
    name: 'snap_zoom', family: 'character', size: 'ms', motion: 'zoom', angle: 'eye', energy: 4, minFrames: 45, maxUse: 1,
    beats: ['impact', 'punchline', 'escalate', 'hook'], kinds: ['character', 'twoShot', 'prop'],
    note: 'Zoom lensa cepat (+40 % dalam 10 frame) di kata penekanan, kamera tidak bergerak. Maks 1 per video.',
    plan: (c) => { const k = frac(c, c.emphasisF, 0.6); const from = pose(c, { frame: fr(c, r(c, 2.4, 3.2)), az: r(c, 6, 16), el: r(c, 1, 4) }); return { segs: [
      { at: 0, push: 0.0015, from },
      { at: Math.max(0.05, k - 0.03), fr: 10, fast: true, ease: 'in', push: 0.002, kick: 0.6, kickEnd: true, to: { fov: zoomFov(from.fov, 0.6) } },
    ], dof: [{ at: Math.max(0.05, k - 0.03), cInf: 13, focus: 'target' }] }; },
  },

  // ----- PROP / INSERT -----
  {
    name: 'macro_insert', family: 'insert', size: 'ecu', motion: 'push', angle: 'high', energy: 2, minFrames: 20,
    beats: ['explain', 'hook', 'tension', 'escalate', 'setup'], kinds: ['prop', 'flat'],
    note: 'Insert makro pada benda penting, bidang tajam sempit (DOF 14-16 px), drift kecil.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.004,
      from: pose(c, { frame: fr(c, r(c, 0.55, 0.8)), az: r(c, 12, 28), el: r(c, 10, 24) }),
      to: pose(c, { frame: fr(c, r(c, 0.5, 0.7)), az: -r(c, 4, 10), el: r(c, 10, 24) }) }],
      dof: [{ at: 0, cInf: 15, focus: 'target' }] }),
  },
  {
    name: 'tilt_tall', family: 'insert', size: 'ms', motion: 'tilt', angle: 'eye', energy: 2, minFrames: 75,
    beats: ['explain', 'reveal', 'establish', 'escalate'], kinds: ['tall', 'prop'],
    note: 'Tilt menyusuri benda tinggi (gedung, daftar reel, menara). Arah atas/bawah diacak seed.',
    plan: (c) => { const d = c.rnd() < 0.5 ? 1 : -1, h = c.size * 0.25; return { segs: [{ at: 0, push: 0.0008,
      from: pose(c, { frame: fr(c, 0.5), az: r(c, -10, 10), el: 0, off: [0, -d * h, 0] }),
      to: pose(c, { frame: fr(c, 0.5), az: r(c, -10, 10), el: 0, off: [0, d * h, 0] }) }] }; },
  },
  {
    name: 'pan_board', family: 'insert', size: 'ms', motion: 'pan', angle: 'eye', energy: 2, minFrames: 60,
    beats: ['explain', 'reveal', 'escalate'], kinds: ['flat', 'prop'],
    note: 'Pan menyamping melintasi papan/peta/cek yang datar.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0012,
      from: pose(c, { frame: fr(c, 0.55), az: r(c, 0, 10), el: r(c, 0, 5), off: [-fr(c, 0.2), 0, 0] }),
      to: pose(c, { frame: fr(c, 0.55), az: r(c, 0, 10), el: r(c, 0, 5), off: [fr(c, 0.2), 0, 0] }) }] }),
  },
  {
    name: 'topdown_pov', family: 'insert', size: 'cu', motion: 'roll', angle: 'top', energy: 2, minFrames: 30,
    beats: ['explain', 'tension', 'escalate'], kinds: ['flat', 'prop', 'interior'],
    note: 'Pandangan dari atas meja/papan (seperti tangan memegang pensil), roll sangat pelan.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.003,
      from: pose(c, { frame: fr(c, r(c, 1.8, 2.6)), el: 84, az: r(c, 0, 60) }),
      to: pose(c, { frame: fr(c, r(c, 1.5, 2.2)), el: 82, az: r(c, 0, 60), roll: r(c, 3, 5) }) }] }),
  },

  // ----- REVEAL / TRANSISI -----
  {
    name: 'pullback_reveal', family: 'reveal', size: 'ws', motion: 'pull', angle: 'eye', energy: 3, minFrames: 80, maxUse: 2,
    beats: ['reveal', 'aftermath', 'callback', 'hook', 'punchline'], kinds: ['character', 'prop', 'place', 'twoShot', 'crowd'],
    note: 'Mulai dari close-up, mundur pelan sampai konteks terlihat (kejutan skala).',
    plan: (c) => ({ segs: [{ at: 0, push: 0.0015, len: 0.75,
      from: pose(c, { frame: fr(c, r(c, 1, 1.3)), az: r(c, -8, 8), el: r(c, 0, 4) }),
      to: pose(c, { frame: fr(c, r(c, 9, 13)), az: r(c, 15, 30), el: r(c, 8, 16) }) }] }),
  },
  {
    name: 'rack_reveal', family: 'reveal', size: 'ms', motion: 'static', angle: 'eye', energy: 2, minFrames: 45,
    beats: ['reveal', 'hook', 'introduce', 'explain'], kinds: ['character', 'prop', 'twoShot'],
    note: 'Fokus pindah dari benda di depan lensa ke subjek (rack focus) sambil kamera bergeser sedikit.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.002,
      from: pose(c, { frame: fr(c, r(c, 2.2, 2.8)), az: r(c, 10, 20), el: r(c, 1, 4), off: [-fr(c, 0.45), 0, 0] }),
      to: pose(c, { frame: fr(c, r(c, 2, 2.5)), az: r(c, 4, 12), el: r(c, 1, 4), off: [0, 0, 0] }) }],
      dof: [{ at: 0, cInf: 16, focus: 'near' }, { at: 0.5, cInf: 14, focus: 'target', dur: 12 }] }),
  },
  {
    name: 'iris_reveal', family: 'reveal', size: 'ms', motion: 'push', angle: 'eye', energy: 2, minFrames: 45, maxUse: 1,
    beats: ['reveal', 'transition', 'establish', 'explain'], kinds: ['place', 'character', 'prop', 'interior'],
    note: 'Bingkai bulat (teropong, jendela kapal, lubang kunci) membuka ke bidang penuh. Butuh efek post iris.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.003,
      from: pose(c, { frame: fr(c, r(c, 3, 4)), az: r(c, -10, 10), el: r(c, 0, 5) }) }],
      fx: [{ kind: 'iris', at: 0, len: Math.min(45, Math.round((c.b - c.a) * 0.4)) }] }),
  },
  {
    name: 'through_window', family: 'reveal', size: 'ms', motion: 'push', angle: 'eye', energy: 3, minFrames: 40, maxUse: 1,
    beats: ['transition', 'reveal', 'escalate'], kinds: ['place', 'interior', 'prop', 'character'],
    note: 'Maju cepat menembus bukaan (jendela/pintu) sebagai transisi. Dipasangkan dengan cut ke shot berikutnya.',
    plan: (c) => ({ segs: [{ at: 0, push: 0.002, fast: true, ease: 'in', len: 0.85,
      from: pose(c, { frame: fr(c, r(c, 3.5, 5)), az: r(c, -6, 6), el: r(c, 0, 4) }),
      to: pose(c, { frame: fr(c, 0.6), az: 0, el: r(c, 0, 3) }) }] }),
  },
  {
    name: 'whip_pan', family: 'reveal', size: 'ms', motion: 'whip', angle: 'eye', energy: 5, minFrames: 60, maxUse: 1,
    beats: ['transition', 'impact'], kinds: ['character', 'place', 'crowd', 'twoShot'],
    note: 'Whip pan ~15 frame (puncak ~90 px/f, sama dengan referensi) dengan motion blur wajib. Maks 1 per video dan hanya jika kepribadian mengizinkan.',
    plan: (c) => { const k = frac(c, c.impactF ?? c.emphasisF, 0.6); const from = pose(c, { frame: fr(c, r(c, 2.6, 3.6)), az: r(c, 8, 18), el: r(c, 1, 4) }); return { segs: [
      { at: 0, push: 0.002, from },
      { at: k, fr: 15, fast: true, whip: true, ease: 'glide', push: 0.003, to: { az: from.az + rad(r(c, 24, 30)) * c.side } },
    ] }; },
  },

  // ----- DAMPAK -----
  {
    name: 'kick_slam_cut', family: 'impact', size: 'ms', motion: 'cut', angle: 'eye', energy: 5, minFrames: 50, maxUse: 2,
    beats: ['impact', 'escalate', 'tension'], kinds: ['prop', 'character', 'place', 'crowd', 'mover'],
    note: 'Wide yang merayap, lalu CUT ke medium tepat di dampak dengan kick yang berganti tanda tiap frame.',
    plan: (c) => { const k = frac(c, c.impactF, 0.6); return { segs: [
      { at: 0, push: 0.002, from: pose(c, { frame: fr(c, r(c, 5, 7)), az: r(c, 20, 40), el: r(c, 10, 18) }) },
      { at: k, cut: true, push: 0.004, kick: 1.2, from: pose(c, { frame: fr(c, r(c, 2.2, 3)), az: r(c, -15, 15), el: r(c, 0, 5) }) },
    ], dof: [{ at: k, cInf: 10, focus: 'target' }] }; },
  },
  {
    name: 'dutch_fall', family: 'impact', size: 'ms', motion: 'roll', angle: 'dutch', energy: 5, minFrames: 40, maxUse: 1,
    beats: ['impact', 'escalate', 'tension'], kinds: ['fall', 'mover'],
    note: 'Kamera dari atas mengikuti subjek yang jatuh dengan roll besar. Target harus fungsi posisi.',
    plan: (c) => ({ segs: [{ at: 0, push: 0, fast: true, ease: 'in',
      from: pose(c, { frame: fr(c, r(c, 3, 4)), el: 72, az: r(c, 0, 40) }),
      to: pose(c, { frame: fr(c, r(c, 2, 2.8)), el: 55, az: r(c, 0, 40), roll: r(c, 14, 22) }) }] }),
  },
];
