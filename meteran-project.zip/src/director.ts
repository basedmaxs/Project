/**
 * director.ts — "sutradara kamera": memilih preset dari cameraPresets.ts untuk setiap shot di storyboard.
 *
 * Tujuan: dua video berbeda tidak boleh terasa dari template yang sama. Variasi datang dari 5 sumber:
 *  1. Kepribadian kamera per video (lensa, jarak, laju push, bobot sudut/gerak).
 *  2. Seed per video (parameter di dalam preset diacak; pilihan preset di-Gumbel-sampling, bukan argmax).
 *  3. Aturan anti-pengulangan di dalam satu video (preset, keluarga, ukuran, gerak, sudut tidak berulang berurutan).
 *  4. Riwayat lintas video (`history`): preset yang baru dipakai video sebelumnya dikenai penalti.
 *  5. Kurva energi: energi kamera mengikuti busur cerita (hook tinggi, setup rendah, impact puncak).
 */
import {
  PRESETS, compile, FPS, FOV_SCALE, renderFov,
  type Beat, type Kind, type Personality, type Preset, type Ctx, type Key, type Mark, type DofHint, type FxHint, type Tgt, type V3, type Cam,
} from './cameraPresets';

// ---------------------------------------------------------------- RNG
export const mulberry32 = (seed: number) => () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
export const hashSeed = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const gumbel = (rnd: () => number) => -Math.log(-Math.log(Math.max(1e-9, rnd())));

// ---------------------------------------------------------------- kepribadian
export const PERSONALITIES: Personality[] = [
  { name: 'observer', fov: 40, frame: 1.0, push: 0.0022, roll: 1, elBias: 0, whipOk: false,
    weights: { push: 1, ms: 1, eye: 1, ws: 0.5 } },
  { name: 'hero_low', fov: 36, frame: 0.92, push: 0.0028, roll: 1.3, elBias: -2, whipOk: true,
    weights: { low: 2, orbit: 1.5, cu: 1.2, cut: 1, dutch: 1 } },
  { name: 'diorama', fov: 44, frame: 1.15, push: 0.0014, roll: 0.5, elBias: 6, whipOk: false,
    weights: { high: 2, top: 1.5, orbit: 1.5, crane: 1.5, ws: 1.5, pull: 1, track: 0.8 } },
  { name: 'intimate', fov: 34, frame: 0.85, push: 0.003, roll: 0.8, elBias: 0, whipOk: false,
    weights: { cu: 2, ecu: 1.5, eye: 1, push: 1.2, static: 1, zoom: 0.5 } },
  { name: 'kinetic', fov: 42, frame: 1.0, push: 0.0025, roll: 1.6, elBias: 2, whipOk: true,
    weights: { track: 1.8, whip: 1.5, roll: 1.5, dutch: 1.2, cut: 1.2, zoom: 1.2, orbit: 1 } },
  { name: 'deadpan', fov: 38, frame: 1.05, push: 0.0012, roll: 0.2, elBias: 0, whipOk: false,
    weights: { static: 2, push: 1.2, eye: 1.8, ms: 1.2, cu: 1, dutch: -2, whip: -3, zoom: -1 } },
  { name: 'epic', fov: 46, frame: 1.25, push: 0.0018, roll: 0.7, elBias: 4, whipOk: false,
    weights: { crane: 2, ws: 2, vws: 1.5, tilt: 1.5, low: 1.2, pull: 1.2, orbit: 1 } },
];

export const makePersonality = (rnd: () => number, forced?: string): Personality => {
  const base = forced ? PERSONALITIES.find((p) => p.name === forced) ?? PERSONALITIES[0] : PERSONALITIES[Math.floor(rnd() * PERSONALITIES.length)];
  const j = (v: number, s: number) => v * (1 + (rnd() - 0.5) * 2 * s);
  return { ...base, fov: j(base.fov, 0.06), frame: j(base.frame, 0.08), push: j(base.push, 0.2), roll: j(base.roll, 0.15) };
};

// ---------------------------------------------------------------- storyboard
export type ShotBrief = {
  id: number;
  a: number; b: number;       // frame awal / akhir (b eksklusif)
  beat: Beat;
  kind: Kind;
  target: Tgt;                // titik bingkai (atau fungsi f -> posisi untuk subjek bergerak)
  size: number;               // tinggi/lebar subjek dalam meter
  facing?: number;            // yaw subjek (rad), default 0
  emphasisF?: number;         // frame kata penekanan
  impactF?: number;           // frame dampak
  groundY?: number;
  need?: string[];            // nama preset yang WAJIB dipakai (override), mis. ['iris_reveal']
  forbid?: string[];          // nama preset yang dilarang untuk shot ini
};

export type Directed = {
  id: number; a: number; b: number; preset: string; family: string; beat: Beat;
  keys: Key[]; marks: Mark[]; dof: DofHint[]; fx: FxHint[];
  why: string;
};
export type DirectOpts = {
  seed: number | string;
  personality?: string;       // paksa kepribadian tertentu
  history?: string[][];       // daftar preset yang dipakai video-video sebelumnya (yang terbaru di akhir)
  allowWhip?: boolean;
  fovScale?: number;          // FOV_SCALE milik story.ts, hanya untuk mengukur kecepatan; default FOV_SCALE (1.35). Tidak mengubah keluaran FOV
};

const DOF_BY_SIZE = { ecu: 14, cu: 13, ms: 10, ws: 0, vws: 0 } as const;
const ENERGY: Record<Beat, number> = {
  hook: 4, establish: 2, setup: 2, introduce: 2, escalate: 3.5, explain: 2, reveal: 3, impact: 5,
  aftermath: 2, punchline: 3, transition: 3, tension: 4, callback: 2,
};

const PENALTY = { sameAsPrev: 100, sameFamilyPrev: 5, sameSizePrev: 2.5, sameMotionPrev: 3, sameAnglePrev: 2, sameInLast3: 3.5, historyLast: 3, historyOlder: 1.2, usedBefore: 1.6 };

const beatNeighbor: Record<Beat, Beat[]> = {
  hook: ['reveal', 'impact'], establish: ['setup', 'reveal'], setup: ['introduce', 'establish'], introduce: ['setup', 'escalate'],
  escalate: ['tension', 'impact'], explain: ['reveal'], reveal: ['explain'], impact: ['tension', 'escalate'],
  aftermath: ['callback'], punchline: ['impact', 'callback'], transition: ['reveal', 'establish'], tension: ['escalate', 'impact'], callback: ['aftermath', 'punchline'],
};

export const direct = (briefs: ShotBrief[], opts: DirectOpts): { personality: Personality; shots: Directed[]; seed: number; report: string } => {
  const seed = typeof opts.seed === 'number' ? opts.seed : hashSeed(opts.seed);
  const master = mulberry32(seed);
  const pers = makePersonality(master, opts.personality);
  const hist = opts.history ?? [];
  const used = new Map<string, number>();
  const out: Directed[] = [];
  const recent: Preset[] = [];
  // "tanda tangan" video: satu preset distingtif yang diberi bonus, supaya tiap video punya satu gaya khas
  const sig = PRESETS.filter((p) => p.energy >= 3 && !(hist.at(-1) ?? []).includes(p.name))[Math.floor(master() * 8) % 8];
  const lines: string[] = [`seed=${seed} personality=${pers.name} fov=${pers.fov.toFixed(1)}->render ${renderFov(pers.fov, opts.fovScale ?? FOV_SCALE).toFixed(1)} (x${opts.fovScale ?? FOV_SCALE}) frame=${pers.frame.toFixed(2)} push=${pers.push.toFixed(4)} signature=${sig?.name ?? '-'}`];

  const total = briefs.length;
  briefs.forEach((br, i) => {
    const len = br.b - br.a;
    const rndPick = mulberry32(hashSeed(`${seed}:pick:${br.id}`));
    const rndShot = mulberry32(hashSeed(`${seed}:shot:${br.id}`));
    const cand = PRESETS.filter((p) => !(br.forbid ?? []).includes(p.name) && p.minFrames <= len &&
      (!p.maxUse || (used.get(p.name) ?? 0) < p.maxUse) && (p.name !== 'whip_pan' || (pers.whipOk && opts.allowWhip !== false)));
    let chosen: Preset | undefined, why = '';
    const forced = (br.need ?? []).map((n) => PRESETS.find((p) => p.name === n)).find(Boolean);
    if (forced) { chosen = forced; why = 'dipaksa storyboard'; }
    else {
      const prev = recent.at(-1);
      const target = ENERGY[br.beat] + (br.beat === 'escalate' ? (i / Math.max(1, total)) * 1 : 0);
      let best = -Infinity;
      for (const p of cand) {
        let s = 0;
        const beatHit = p.beats.includes(br.beat) ? 4 : p.beats.some((b) => beatNeighbor[br.beat].includes(b)) ? 1.5 : 0;
        const kindHit = p.kinds.includes(br.kind) ? 4 : 0;
        if (!kindHit) continue;           // preset yang tidak cocok dengan jenis subjek tidak dipertimbangkan
        s += beatHit + kindHit;
        s -= Math.abs(p.energy - target) * 1.1;
        const w = pers.weights;
        s += (w[p.motion] ?? 0) + (w[p.angle] ?? 0) + (w[p.size] ?? 0);
        if (sig && p.name === sig.name) s += 2.2;
        if (prev) {
          if (prev.name === p.name) s -= PENALTY.sameAsPrev;
          if (prev.family === p.family) s -= PENALTY.sameFamilyPrev;
          if (prev.size === p.size) s -= PENALTY.sameSizePrev;
          if (prev.motion === p.motion) s -= PENALTY.sameMotionPrev;
          if (prev.angle === p.angle) s -= PENALTY.sameAnglePrev;
        }
        if (recent.slice(-4, -1).some((q) => q.name === p.name)) s -= PENALTY.sameInLast3;
        s -= (used.get(p.name) ?? 0) * PENALTY.usedBefore;
        if (hist.length) {
          if ((hist.at(-1) ?? []).includes(p.name)) s -= PENALTY.historyLast;
          if (hist.slice(0, -1).some((h) => h.includes(p.name))) s -= PENALTY.historyOlder;
        }
        s += gumbel(rndPick) * 1.6;       // sampling acak ber-seed, bukan argmax
        if (s > best) { best = s; chosen = p; }
      }
      if (!chosen) { chosen = PRESETS.find((p) => p.name === 'ms_creep')!; why = 'fallback: tidak ada kandidat'; }
      else why = `skor ${best.toFixed(1)} dari ${cand.length} kandidat`;
    }
    const preset = chosen!;
    used.set(preset.name, (used.get(preset.name) ?? 0) + 1);
    recent.push(preset);

    const ctx: Ctx = {
      a: br.a, b: br.b, target: br.target, size: br.size, facing: br.facing ?? 0,
      side: rndShot() < 0.5 ? 1 : -1, rnd: rndShot, pers, kind: br.kind,
      emphasisF: br.emphasisF, impactF: br.impactF, groundY: br.groundY, fovScale: opts.fovScale ?? FOV_SCALE,
    };
    const plan = preset.plan(ctx);
    const { keys, marks } = compile(ctx, plan.segs);
    // DOF bawaan menurut ukuran shot (aturan skill: wide tajam, MS 10-12 px, CU 12-14, ECU 14-16); preset boleh menimpa
    const dofHints: DofHint[] = plan.dof ?? [{ at: 0, cInf: DOF_BY_SIZE[preset.size], focus: DOF_BY_SIZE[preset.size] ? 'target' : 'look' }];
    out.push({ id: br.id, a: br.a, b: br.b, preset: preset.name, family: preset.family, beat: br.beat, keys, marks,
      dof: dofHints.map((d) => ({ ...d, at: br.a + Math.round(d.at * len) })), fx: (plan.fx ?? []).map((x) => ({ ...x, at: br.a + Math.round(x.at * len) })), why });
    lines.push(`shot ${String(br.id).padStart(2)} [${br.beat}/${br.kind}] -> ${preset.name} (${preset.motion}, ${preset.angle}, ${preset.size}) ${why}`);
  });
  return { personality: pers, shots: out, seed, report: lines.join('\n') };
};

// ---------------------------------------------------------------- integrasi ke story.ts
/** CAMS siap pakai: `export const CAMS = camsFrom(result.shots)` menggantikan tabel tangan di story.ts */
export const camsFrom = (shots: Directed[]): Record<number, Key[]> => Object.fromEntries(shots.map((s) => [s.id, s.keys]));
/** pasangan [frame, gain] untuk KICKS di story.ts; frame diubah ke detik */
export const kicksFrom = (shots: Directed[]): [number, number][] =>
  shots.flatMap((s) => s.marks.filter((m) => m.kind === 'kick').map((m) => [m.f / FPS, m.g ?? 1] as [number, number]));
/** entri DOF untuk tabel DOF di story.ts. `focus` sudah berupa fungsi (f) => titik dunia, atau undefined = pakai titik look kamera.
 *  'target' = titik bingkai storyboard; 'near' = titik 35 % dari kamera menuju target (benda di depan lensa, untuk rack focus). */
export const dofFrom = (shots: Directed[], briefs: ShotBrief[]) =>
  shots.flatMap((s) => {
    const br = briefs.find((b) => b.id === s.id)!;
    return s.dof.map((d) => ({
      f: d.at, cInf: d.cInf, dur: d.dur,
      focus: d.focus === 'look' ? undefined
        : d.focus === 'target' ? (f: number): V3 => (typeof br.target === 'function' ? br.target(f) : br.target)
        : (f: number): V3 => { const c = evalKeys(s.keys, f), t = typeof br.target === 'function' ? br.target(f) : br.target;
            return [c.pos[0] + (t[0] - c.pos[0]) * 0.35, c.pos[1] + (t[1] - c.pos[1]) * 0.35, c.pos[2] + (t[2] - c.pos[2]) * 0.35]; },
    }));
  }).sort((a, b) => a.f - b.f);
/** frame yang butuh efek post (whip blur / iris) */
export const fxFrom = (shots: Directed[]) => ({
  whips: shots.flatMap((s) => s.marks.filter((m) => m.kind === 'whip').map((m) => ({ f: m.f, len: m.len ?? 8 }))),
  iris: shots.flatMap((s) => s.fx),
});

// ---------------------------------------------------------------- evaluasi kamera (dipakai uji dan QA)
export const evalKeys = (keys: Key[], f: number): Cam => {
  const full = (s: ReturnType<Key['s']>): Cam => ({ fov: 40, roll: 0, ...s } as Cam);
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) { const k = keys[i]; if (f < k.f) break; cur = full(k.s(f)); }
  return cur;
};
/** kamera seperti yang dirender setelah story.ts menerapkan FOV_SCALE (untuk QA dan uji) */
export const evalKeysScaled = (keys: Key[], f: number, k: number = FOV_SCALE): Cam => { const c = evalKeys(keys, f); return { ...c, fov: renderFov(c.fov, k) }; };
export { FOV_SCALE };
export type { V3 };
