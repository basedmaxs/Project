// Splits the render into frame chunks for the GitHub Actions matrix.   node ci/plan.mjs [chunk=100] [total]
// total defaults to `export const TOTAL = N` in src/story.ts. Prints the plan; in CI also writes `matrix` and `total` to $GITHUB_OUTPUT.
import fs from 'fs';
let chunk = Math.max(1, parseInt(process.argv[2] || '100', 10) || 100);
let total = parseInt(process.argv[3] || '0', 10);
if (!total) { const m = /export\s+const\s+TOTAL\s*=\s*(\d+)/.exec(fs.readFileSync('src/story.ts', 'utf8')); if (!m) { console.error('TOTAL not found in src/story.ts: pass it as the 2nd argument'); process.exit(1); } total = +m[1]; }
chunk = Math.max(chunk, Math.ceil(total / 256));            // a workflow matrix holds at most 256 jobs
const include = [];
for (let a = 0, i = 0; a < total; a += chunk, i++) include.push({ i, a, b: Math.min(total, a + chunk) - 1 });
const matrix = JSON.stringify({ include });
console.log(`total ${total} frames -> ${include.length} jobs of up to ${chunk} frames`);
if (process.env.GITHUB_OUTPUT) fs.appendFileSync(process.env.GITHUB_OUTPUT, `matrix=${matrix}\ntotal=${total}\n`); else console.log(matrix);
