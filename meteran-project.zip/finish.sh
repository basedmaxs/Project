#!/usr/bin/env bash
# Encode frames + mix -> mp4, then QA.   bash finish.sh "Title Of Short"
set -e; T="${1:-short}"; F="out/${T// /-}.mp4"
# mix_final.wav comes from audio_engine/make_audio.py: already -15 LUFS / <= -1.2 dBTP, used as-is (no second loudness change)
[ -f mix_final.wav ] || [ -f mix_final.flac ] || { echo "mix_final.wav (or mix_final.flac) missing: run the audio script in audio/"; exit 1; }
AUD=mix_final.wav; [ -f "$AUD" ] || AUD=mix_final.flac   # flac = the same audio, half the size (GitHub web upload limit)
# frame check: ffmpeg silently stops at the first missing frame, so refuse to encode if the sequence has gaps or empty files
N=$(python3 - <<'PY'
import os, re, sys
T = None
if os.path.exists("src/story.ts"):
    m = re.search(r"export const TOTAL = (\d+)", open("src/story.ts").read()); T = int(m.group(1)) if m else None
have = {int(m.group(1)) for n in os.listdir("frames") if (m := re.match(r"f(\d{4})\.jpg$", n)) and os.path.getsize("frames/" + n) > 0}
last = (T - 1) if T else (max(have) if have else -1)
missing = [f for f in range(0, last + 1) if f not in have]
if not have or missing:
    print(f"missing {len(missing)} frame(s) in 0-{last}: {','.join(map(str, missing[:30]))}{',...' if len(missing) > 30 else ''}", file=sys.stderr)
    print("re-render: RESUME=1 node render.mjs frames 0-%d  (or: bash render_bg.sh chunk)" % last, file=sys.stderr); sys.exit(1)
print(last + 1)
PY
) || exit 1
DUR=$(python3 -c "print($N/30)")
ffmpeg -v error -y -i "$AUD" -ar 48000 -ac 2 mix.wav
ffmpeg -v error -y -framerate 30 -i frames/f%04d.jpg -i mix.wav -map 0:v:0 -map 1:a:0 -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -c:a aac -b:a 256k -t "$DUR" -movflags +faststart "$F"
ffprobe -v error -show_entries format=duration -show_entries stream=width,height,r_frame_rate -of compact "$F"
echo "--- QA (empty = no black/frozen spans)"; ffmpeg -i "$F" -vf "freezedetect=n=0.0005:d=0.4,blackdetect=d=0.05" -an -f null - 2>&1 | grep -E "freeze_start|black_start" || true
ffmpeg -i "$F" -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1
ffmpeg -v error -y -i "$F" -vf "fps=2,scale=180:-1,tile=10x4" -frames:v 1 out/qa_sheet.jpg; echo "$F"
# upload-size copy: delivery channels can limit file size (e.g. 30 MB). Keep the master, make a lighter copy next to it when needed.
if [ "$(stat -c %s "$F")" -gt 28000000 ]; then
  K="${F%.mp4}-kirim.mp4"
  ffmpeg -v error -y -i "$F" -c:v libx264 -b:v 2.7M -maxrate 3.5M -bufsize 7M -preset slow -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "$K" && echo "upload copy: $K"
fi

# subtitles (optional layer, never in the frames): work/subs.srt + work/subs.ass come from `python3 subtitles.py` (docs/subtitles.md).
# The clean master above is kept; with subtitles the user also gets <Title>.srt and a burned-in <Title>-sub.mp4.
if [ -f work/subs.ass ]; then
  cp work/subs.srt "${F%.mp4}.srt" 2>/dev/null || true
  S="${F%.mp4}-sub.mp4"
  ffmpeg -v error -y -i "$F" -vf "ass=filename=work/subs.ass:fontsdir=fonts" -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -c:a copy -movflags +faststart "$S" && echo "subtitled: $S (+ ${F%.mp4}.srt)"
  if [ "$(stat -c %s "$S")" -gt 28000000 ]; then
    ffmpeg -v error -y -i "$S" -c:v libx264 -b:v 2.7M -maxrate 3.5M -bufsize 7M -preset slow -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "${S%.mp4}-kirim.mp4" && echo "upload copy: ${S%.mp4}-kirim.mp4"
  fi
fi
