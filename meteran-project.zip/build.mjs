// Turns the TypeScript look + story sources into the browser ES modules.   node build.mjs [projectDir]
//   src/*.ts  ->  web/*.js   (types stripped with Node 22 module.stripTypeScriptTypes; relative imports get ".js")
// Run it after every edit of a .ts file, before render.mjs. No bundler, no network.
import fs from 'fs'; import path from 'path'; import mod from 'node:module';
process.removeAllListeners('warning');
const P = path.resolve(process.argv[2] || '.');
const src = path.join(P, 'src'), web = path.join(P, 'web');
fs.mkdirSync(web, { recursive: true });
let n = 0;
const files = fs.readdirSync(src).filter((f) => f.endsWith('.ts'));
// type-only exports (export type X / export interface X): the stripper keeps them in import lists, the browser would reject them
const TYPES = new Set();
for (const f of files) for (const m of fs.readFileSync(path.join(src, f), 'utf8').matchAll(/export\s+(?:type|interface)\s+(\w+)/g)) TYPES.add(m[1]);
const dropTypeImports = (code) => code.replace(/import\s*\{([^}]*)\}\s*from\s*(["'][^"']+["']);?/g, (m, list, from) => {
  const keep = list.split(',').map((x) => x.trim()).filter((x) => x && !TYPES.has(x.split(/\s+as\s+/)[0].trim()));
  return keep.length ? `import { ${keep.join(', ')} } from ${from};` : '';
});
for (const f of files) {
  let js = dropTypeImports(mod.stripTypeScriptTypes(fs.readFileSync(path.join(src, f), 'utf8'), { mode: 'transform' }));
  js = js.replace(/(from\s+)(["'])(\.{1,2}\/[^"']+?)\2/g, (m, a, q, p) => (/\.m?js$/.test(p) ? m : `${a}${q}${p}.js${q}`));
  fs.writeFileSync(path.join(web, f.replace(/\.ts$/, '.js')), js); n++;
}
console.log(`built ${n} modules -> ${web}`);
