#!/usr/bin/env bash
# Offline frame render (no GPU, no network): three.js in Chromium via Playwright, software GL (SwiftShader). Resolution 1080x1920.
# Frames are pure functions of the frame number, so any run can be stopped and repeated: finished frames are skipped (RESUME) and
# frames are written atomically (.part -> rename), so a killed run never leaves a half frame.
#
#   bash render_bg.sh chunk [TOTAL]   # OPTION A (sandbox): foreground run of at most CHUNK_SECONDS (default 540 = 9 min) per call.
#                                     # Background processes can be killed when the chat reply ends, so call this again and again
#                                     # (same command) until `status` says DONE.
#   bash render_bg.sh start [TOTAL]   # detached background run (own computer / server where background jobs survive)
#   bash render_bg.sh status          # frames done / TOTAL, missing, s/frame, ETA
#   bash render_bg.sh missing         # list missing frame numbers (empty = none)
#   bash render_bg.sh stop
# TOTAL defaults to `export const TOTAL = N` in src/story.ts. Workers = min(CPU cores, free RAM / 1.1 GB), at least 1
# (each worker is one Chromium: ~1 core, ~1 GB RAM). JOBS=n overrides; never use more workers than cores. GPU=1 uses a real GPU.
set -uo pipefail
cd "$(dirname "$0")"; mkdir -p work frames
cmd="${1:-status}"
total() { [ -n "${1:-}" ] && echo "$1" || grep -oE 'export const TOTAL = [0-9]+' src/story.ts 2>/dev/null | grep -oE '[0-9]+$'; }
workers() {
  local c m n; c=$(nproc); m=$(( $(awk '/MemAvailable/ {print $2}' /proc/meminfo) / 1126400 )) # MemAvailable kB / 1.1 GB
  n=${JOBS:-$(( c < m ? c : m ))}; [ "$n" -ge 1 ] && echo "$n" || echo 1
}
have() { find frames -maxdepth 1 -name 'f*.jpg' -size +0c 2>/dev/null | wc -l; }
launch() { # $1 = "fg" or "bg"; frames are dealt round-robin: worker i renders i, i+N, i+2N, ...
  local T=$1 N=$2 mode=$3 i
  echo "$T" > work/render.total; echo "$N" > work/render.workers; [ -f work/render.t0 ] || date +%s > work/render.t0; : > work/render.pids
  for ((i = 0; i < N; i++)); do
    if [ "$mode" = bg ]; then
      RESUME=1 setsid nohup node render.mjs frames "$i-$((T - 1))" "$N" > "work/render_$i.log" 2>&1 < /dev/null &
    else
      RESUME=1 timeout --kill-after=15 "${CHUNK_SECONDS:-540}" node render.mjs frames "$i-$((T - 1))" "$N" > "work/render_$i.log" 2>&1 &
    fi
    echo $! >> work/render.pids
  done
}
case "$cmd" in
  chunk)
    T=$(total "${2:-}"); [ -n "$T" ] || { echo "TOTAL not found: pass it as 2nd argument"; exit 1; }
    N=$(workers); echo "chunk: $N worker(s), up to ${CHUNK_SECONDS:-540}s, frames done before: $(have)/$T"
    launch "$T" "$N" fg; wait
    pkill -f "[c]hrome-headless-shell|[c]hromium.*--headless" 2>/dev/null || true   # no orphan browsers after a timeout
    bash "$0" status; [ "$(have)" -ge "$T" ] || echo "NOT FINISHED: run the same command again (it continues where it stopped)."
    ;;
  start)
    T=$(total "${2:-}"); [ -n "$T" ] || { echo "TOTAL not found: pass it as 2nd argument"; exit 1; }
    N=$(workers); launch "$T" "$N" bg; echo "started $N detached worker(s) for $T frames. Check: bash render_bg.sh status"
    ;;
  status)
    T=$(cat work/render.total 2>/dev/null || true); [ -n "$T" ] || { echo "no render started"; exit 0; }
    D=$(have); N=$(cat work/render.workers 2>/dev/null || echo 1); R=0
    for p in $(cat work/render.pids 2>/dev/null); do kill -0 "$p" 2>/dev/null && R=$((R + 1)); done
    echo "frames $D/$T ($(( 100 * D / T )) %), missing $((T - D)), workers running: $R"
    S=$(cat work/render_*.log 2>/dev/null | grep -oE '[0-9.]+ s/frame' | tail -4 | awk '{s+=$1; n++} END {if (n) printf "%.1f", s/n}')
    if [ -n "$S" ] && [ "$D" -lt "$T" ]; then echo "~$S s/frame per worker, ETA ~$(awk -v r=$((T - D)) -v s="$S" -v n="$N" 'BEGIN {printf "%d", r * s / n / 60}') min"; fi
    [ "$D" -ge "$T" ] && echo "DONE: next -> python3 audio/mix.py (if not done), then bash finish.sh \"Title\""
    grep -l -E "page error|^ERR" work/render_*.log 2>/dev/null && echo "WARNING: errors in the logs above"
    exit 0
    ;;
  missing)
    T=${2:-$(cat work/render.total 2>/dev/null || total)}; [ -n "$T" ] || { echo "TOTAL not found"; exit 1; }
    for ((f = 0; f < T; f++)); do [ -s "$(printf 'frames/f%04d.jpg' "$f")" ] || printf '%d ' "$f"; done; echo
    ;;
  stop) pkill -f "node render.mjs frames" 2>/dev/null; echo stopped; exit 0 ;;
  *) echo "usage: bash render_bg.sh chunk|start [TOTAL] | status | missing | stop"; exit 1 ;;
esac
