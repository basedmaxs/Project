import * as THREE from "three";
export const TONE = {
    uLitCol: {
        value: new THREE.Vector3(1.5, 1.44, 1.32)
    },
    uShadeCol: {
        value: new THREE.Vector3(0.6, 0.58, 0.86)
    },
    uShadeLift: {
        value: new THREE.Vector3()
    },
    uLambert: {
        value: 0.35
    },
    uSideK: {
        value: 0.84
    },
    uTerm: {
        value: 0.2
    },
    uBounce: {
        value: new THREE.Vector3()
    },
    uSat: {
        value: 1
    }
};
export const CHAR = {
    uCharTint: {
        value: new THREE.Vector3(1, 0.94, 0.92)
    },
    uCharShade: {
        value: 0.86
    },
    uGrad: {
        value: 0.07
    },
    uBodyGrad: {
        value: 0.2
    },
    uSideTint: {
        value: new THREE.Vector3(0.92, 0.9, 0.96)
    }
};
export const LFB = THREE.ShaderChunk.lights_fragment_begin.replace("directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ]", "sunVis = ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ]").replace("vDirectionalShadowCoord[ i ] ) : 1.0;", "vDirectionalShadowCoord[ i ] ) : 1.0;\n\t\tdirectLight.color *= sunVis;");
if (!LFB.includes("directLight.color *= sunVis")) throw new Error("shade.ts: three lights_fragment_begin changed");
const TWO_TONE = `
#if NUM_DIR_LIGHTS > 0
{
  vec3 sunV = directionalLights[ 0 ].direction;                               // view space, towards the sun
  vec3 upV = normalize( ( viewMatrix * vec4( 0.0, 1.0, 0.0, 0.0 ) ).xyz );
  float ndl = max( dot( geometryNormal, sunV ), 0.0 );
  float sunTerm = sunVis * smoothstep( 0.0, uTerm, ndl );                     // 0 = cast/form shadow, 1 = lit
  float skyK = mix( uSideK, 1.0, 0.5 + 0.5 * dot( geometryNormal, upV ) );    // up-facing a bit brighter
  vec3 lit = uLitCol * mix( 1.0, ndl, uLambert );                             // keep some cosine modelling
  float facing = max( dot( geometryNormal, geometryViewDir ), 0.0 );        // 1 = faces the lens
  vec3 alb = max( mix( vec3( dot( diffuseColor.rgb, vec3( 0.2126, 0.7152, 0.0722 ) ) ), diffuseColor.rgb, uSat ), 0.0 );
  reflectedLight.directDiffuse = alb * ( mix( uShadeCol, lit, sunTerm ) * skyK + uBounce * facing * clamp( 1.0 - dot( geometryNormal, upV ), 0.0, 1.0 ) * ( 1.0 - sunTerm ) )
    + uShadeLift * LIFT_K * ( 1.0 - sunTerm );
  reflectedLight.indirectDiffuse = vec3( 0.0 );                               // hemisphere/fill no longer used here
}
#endif
`;
const DECL = "#include <common>\nuniform vec3 uLitCol; uniform vec3 uShadeCol; uniform vec3 uShadeLift; uniform float uLambert; uniform float uSideK; uniform float uTerm; uniform vec3 uBounce; uniform float uSat;";
export function twoTone(m, liftK = 1) {
    m.onBeforeCompile = (sh)=>{
        Object.assign(sh.uniforms, TONE);
        sh.fragmentShader = sh.fragmentShader.replace("#include <common>", DECL + `\n#define LIFT_K ${liftK.toFixed(3)}`).replace("#include <lights_fragment_begin>", "float sunVis = 1.0;\n" + LFB).replace("#include <lights_fragment_end>", "#include <lights_fragment_end>\n" + TWO_TONE);
    };
    m.customProgramCacheKey = ()=>"twoTone5_" + liftK.toFixed(3);
    return m;
}
const neutral = (c)=>{
    const x = Math.min(c[0], c[1], c[2]), off = x < 0.08 ? x - 6.25 * x * x : 0.04;
    const v = c.map((k)=>k - off), peak = Math.max(v[0], v[1], v[2]), S = 0.76;
    if (peak < S) return v;
    const d = 1 - S, np = 1 - d * d / (peak + d - S), g = 1 - 1 / (0.15 * (peak - np) + 1);
    return v.map((k)=>k * np / peak * (1 - g) + np * g);
};
export const untone = (target, out = new THREE.Color())=>{
    const t = new THREE.Color(target);
    const tt = [
        t.r,
        t.g,
        t.b
    ].map((k)=>Math.min(k, 0.985));
    let c = tt.slice();
    for(let i = 0; i < 60; i++){
        const y = neutral(c);
        c = c.map((k, j)=>Math.max(0, k + (tt[j] - y[j])));
    }
    return out.setRGB(c[0], c[1], c[2]);
};
