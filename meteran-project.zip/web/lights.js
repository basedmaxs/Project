export const LIGHTS = {
    day: {
        az: 75,
        el: 48,
        lit: [
            1.58,
            1.5,
            1.33
        ],
        shade: [
            0.3,
            0.29,
            0.36
        ],
        lift: [
            0.05,
            0.06,
            0.11
        ],
        lambert: 0.35,
        sideK: 0.84,
        term: 0.2,
        charTint: [
            1.0,
            0.94,
            0.92
        ],
        charShade: 0.86,
        charGrad: 0.07,
        bodyGrad: 0.2,
        sideTint: [
            0.92,
            0.90,
            0.96
        ],
        blob: [
            0.62,
            0.58,
            0.58
        ],
        actorShadow: false,
        top: "#3e7fd2",
        hor: "#b8d0ec",
        skyCurve: [
            0.0,
            0.5,
            0.6
        ],
        fog: "#b8d0ec",
        fogNear: 25,
        fogFar: 300,
        sunDisc: "#000000",
        sunCol: "#fff3e0",
        sunI: 2.8,
        sky: "#dcecff",
        ground: "#b49a78",
        hemiI: 0.55,
        bias: -0.00025,
        normalBias: 0.015
    },
    golden: {
        az: 6,
        el: 7,
        lit: [
            1.5,
            0.68,
            0.24
        ],
        shade: [
            0.15,
            0.15,
            0.3
        ],
        lift: [
            0.04,
            0.06,
            0.17
        ],
        lambert: 0.35,
        sideK: 0.82,
        term: 0.07,
        charTint: [
            1.0,
            0.78,
            0.56
        ],
        charShade: 0.88,
        charGrad: 0.1,
        bodyGrad: 0.25,
        sideTint: [
            0.85,
            0.80,
            0.95
        ],
        blob: [
            0.75,
            0.74,
            0.9
        ],
        actorShadow: true,
        top: "#6a4f8c",
        hor: "#ffd08a",
        skyCurve: [
            0.05,
            0.6,
            1.0
        ],
        fog: "#efb489",
        fogNear: 50,
        fogFar: 380,
        sunDisc: "#ffcf9e",
        sunCol: "#ffab5e",
        sunI: 5.5,
        sky: "#d8b0b8",
        ground: "#8a6a60",
        hemiI: 0.5,
        bias: -0.0006,
        normalBias: 0.03
    },
    night: {
        az: 150,
        el: 38,
        lit: [
            0.62,
            0.78,
            1.35
        ],
        shade: [
            0.13,
            0.16,
            0.3
        ],
        lift: [
            0.03,
            0.05,
            0.12
        ],
        lambert: 0.3,
        sideK: 0.86,
        term: 0.25,
        charTint: [
            0.82,
            0.9,
            1.0
        ],
        charShade: 0.8,
        charGrad: 0.08,
        bodyGrad: 0.2,
        sideTint: [
            0.78,
            0.84,
            1.0
        ],
        blob: [
            0.4,
            0.42,
            0.62
        ],
        actorShadow: false,
        top: "#0a1230",
        hor: "#1b2a58",
        skyCurve: [
            0.0,
            0.5,
            0.6
        ],
        fog: "#0d1630",
        fogNear: 14,
        fogFar: 90,
        sunDisc: "#000000",
        sunCol: "#a9c0ff",
        sunI: 1.9,
        sky: "#2a3a78",
        ground: "#1c1a36",
        hemiI: 0.5,
        bias: -0.0004,
        normalBias: 0.02
    }
};
export const LOOK = {
    day: {
        sky: {
            c: [
                "#b8d0ec",
                "#9cbfea",
                "#6a9fe0",
                "#4f8cdb",
                "#3373cc"
            ],
            e: [
                0,
                3,
                8,
                16,
                40
            ]
        },
        water: {
            near: "#22a7b6",
            mid: "#167fb2",
            far: "#1a5596",
            crest: "#7ddfe8",
            trough: "#0e4a80",
            glint: "#ffffff",
            shade: [
                0.5,
                0.56,
                0.72
            ]
        },
        cloud: {
            lit: "#fbf8f1",
            mid: "#e1e5f3",
            shade: "#c3cbe9"
        },
        bounce: [
            0,
            0,
            0
        ],
        sat: 1.08
    },
    golden: {
        sky: {
            c: [
                "#ffc47c",
                "#f7ae78",
                "#e8967c",
                "#c4848e",
                "#8a6f8a"
            ],
            e: [
                0,
                4,
                10,
                20,
                40
            ]
        },
        water: {
            near: "#1e3a6e",
            mid: "#355f96",
            far: "#d4a48e",
            crest: "#d9a088",
            trough: "#16294f",
            glint: "#ffe2b0",
            shade: [
                0.42,
                0.46,
                0.72
            ]
        },
        cloud: {
            lit: "#ffd2a8",
            mid: "#f2a08f",
            shade: "#a98fc4"
        },
        bounce: [
            0.04,
            0.02,
            0.0
        ],
        sat: 1.1
    },
    night: {
        sky: {
            c: [
                "#1b2a58",
                "#142048",
                "#0f1a3c",
                "#0c1432",
                "#0a1230"
            ],
            e: [
                0,
                4,
                12,
                24,
                50
            ]
        },
        water: {
            near: "#16294f",
            mid: "#1b3563",
            far: "#223d70",
            crest: "#4a6aa8",
            trough: "#0e1a36",
            glint: "#bcd0ff",
            shade: [
                0.4,
                0.46,
                0.7
            ]
        },
        cloud: {
            lit: "#8fa2d8",
            mid: "#566aa8",
            shade: "#2a3868"
        },
        bounce: [
            0,
            0,
            0.02
        ],
        sat: 1.0
    }
};
