import * as THREE from "three";
import { Batch, boxGeo, V, lam } from "./build.js";
import { ctex, rep } from "./paint.js";
import { LIGHTS, LOOK } from "./lights.js";
import { TONE, CHAR, twoTone, untone } from "./shade.js";
import { NOINK } from "./ink.js";
import { Pool, Actor, Fx, stage, setSun } from "./cast.js";
import { paintPropText } from "./proptext.js";
import { SHOTS, camAt, meterRev, meterKwh, ledAt, heatAt, noteVisible, METER, CLOCK, SOCKET, GLASS, FAN, FPS, smooth } from "./story.js";
export const loadKit = async ()=>({});
const HDR = (r, g, b)=>new THREE.Color(r, g, b);
const glowTex = ()=>ctex("glow", 128, 128, (g)=>{
        const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
        gr.addColorStop(0, "rgba(255,255,255,1)");
        gr.addColorStop(0.25, "rgba(255,255,255,0.45)");
        gr.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 128, 128);
    });
const glow = (col, size)=>{
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTex(),
        color: col,
        blending: THREE.AdditiveBlending,
        transparent: true,
        depthWrite: false,
        fog: false
    }));
    s.scale.setScalar(size);
    s.layers.set(NOINK);
    return s;
};
const plaster = (key, col)=>ctex(key, 256, 256, (g, r)=>{
        g.fillStyle = col;
        g.fillRect(0, 0, 256, 256);
        for(let i = 0; i < 700; i++){
            g.fillStyle = r() < 0.5 ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.035)";
            const s = 2 + r() * 9;
            g.beginPath();
            g.ellipse(r() * 256, r() * 256, s, s * (0.5 + r()), r() * 3, 0, 6.3);
            g.fill();
        }
    });
const floorTex = (key, col, seam, plank)=>ctex(key, 256, 256, (g, r)=>{
        g.fillStyle = col;
        g.fillRect(0, 0, 256, 256);
        for(let y = 0; y < 256; y += 256 / plank){
            g.fillStyle = `rgba(255,255,255,${0.03 + r() * 0.05})`;
            g.fillRect(0, y, 256, 256 / plank);
            g.fillStyle = seam;
            g.fillRect(0, y, 256, 2.5);
        }
        for(let i = 0; i < 300; i++){
            g.fillStyle = "rgba(0,0,0,0.06)";
            g.fillRect(r() * 256, r() * 256, 10 + r() * 40, 1);
        }
    });
const clockTex = ()=>ctex("clock", 256, 256, (g)=>{
        g.fillStyle = "#e9e4d6";
        g.beginPath();
        g.arc(128, 128, 124, 0, 6.3);
        g.fill();
        g.strokeStyle = "#2a2a30";
        g.lineWidth = 6;
        g.beginPath();
        g.arc(128, 128, 120, 0, 6.3);
        g.stroke();
        for(let i = 0; i < 12; i++){
            const a = i / 12 * 6.283;
            g.lineWidth = i % 3 ? 4 : 8;
            g.beginPath();
            g.moveTo(128 + Math.sin(a) * 100, 128 - Math.cos(a) * 100);
            g.lineTo(128 + Math.sin(a) * 114, 128 - Math.cos(a) * 114);
            g.stroke();
        }
        g.lineWidth = 9;
        g.beginPath();
        g.moveTo(128, 128);
        g.lineTo(128, 52);
        g.stroke();
        g.lineWidth = 6;
        g.beginPath();
        g.moveTo(128, 128);
        g.lineTo(128, 28);
        g.stroke();
        g.fillStyle = "#2a2a30";
        g.beginPath();
        g.arc(128, 128, 9, 0, 6.3);
        g.fill();
    });
const windowTex = ()=>ctex("window", 256, 256, (g, r)=>{
        const gr = g.createLinearGradient(0, 0, 0, 256);
        gr.addColorStop(0, "#3a5aa8");
        gr.addColorStop(1, "#1d2c62");
        g.fillStyle = gr;
        g.fillRect(0, 0, 256, 256);
        for(let i = 0; i < 40; i++){
            g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.6})`;
            g.fillRect(r() * 256, r() * 150, 2, 2);
        }
        g.fillStyle = "#f3f0d8";
        g.beginPath();
        g.arc(178, 70, 22, 0, 6.3);
        g.fill();
        g.fillStyle = "#141a30";
        g.fillRect(0, 232, 256, 24);
        g.fillRect(36, 204, 22, 52);
        g.fillRect(150, 214, 50, 42);
        g.strokeStyle = "#20242c";
        g.lineWidth = 9;
        g.strokeRect(4, 4, 248, 248);
        g.beginPath();
        g.moveTo(128, 0);
        g.lineTo(128, 256);
        g.moveTo(0, 128);
        g.lineTo(256, 128);
        g.stroke();
    });
const fanTex = ()=>ctex("fanblades", 256, 256, (g)=>{
        g.fillStyle = "#15191e";
        g.fillRect(0, 0, 256, 256);
        g.fillStyle = "#5d6a78";
        for(let i = 0; i < 7; i++){
            g.save();
            g.translate(128, 128);
            g.rotate(i / 7 * 6.283);
            g.beginPath();
            g.moveTo(8, -10);
            g.quadraticCurveTo(70, -52, 112, -22);
            g.lineTo(112, 6);
            g.quadraticCurveTo(66, -16, 8, 14);
            g.closePath();
            g.fill();
            g.restore();
        }
        g.fillStyle = "#2c333b";
        g.beginPath();
        g.arc(128, 128, 22, 0, 6.3);
        g.fill();
    });
const lcd = (n)=>paintPropText(THREE, {
        title: "kWh",
        number: String(Math.max(0, Math.round(n))).padStart(5, "0"),
        style: "mono",
        paper: "lcd_green"
    }, {
        progress: 1
    });
export class World {
    root = new THREE.Group();
    pool = new Pool();
    actors = [];
    fxs = [];
    hemi;
    sun;
    skyMat;
    sky;
    fog = new THREE.Fog("#0d1630", 14, 90);
    sunCache = new Map();
    shells = [];
    disc;
    lcdMat;
    lcdKey = "";
    led;
    ledGlow;
    note;
    heatMat;
    heatGlow;
    feet = [];
    fans = [];
    rackLeds = [];
    glassWater;
    m4 = new THREE.Matrix4();
    constructor(_kit){
        const R = this.root;
        this.skyMat = new THREE.ShaderMaterial({
            uniforms: {
                c0: {
                    value: new THREE.Color()
                },
                c1: {
                    value: new THREE.Color()
                },
                c2: {
                    value: new THREE.Color()
                },
                c3: {
                    value: new THREE.Color()
                },
                c4: {
                    value: new THREE.Color()
                },
                e: {
                    value: new THREE.Vector4()
                }
            },
            vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
            fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0)); vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el)); c = mix(c, c3, smoothstep(e.y, e.z, el)); c = mix(c, c4, smoothstep(e.z, e.w, el)); gl_FragColor = vec4(c, 1.0); }`,
            side: THREE.BackSide,
            depthWrite: false,
            fog: false
        });
        this.sky = new THREE.Mesh(new THREE.SphereGeometry(300, 24, 12), this.skyMat);
        this.sky.renderOrder = -1;
        this.sky.frustumCulled = false;
        this.sky.layers.set(NOINK);
        R.add(this.sky);
        this.hemi = new THREE.HemisphereLight("#2a3a78", "#1c1a36", 0.5);
        this.sun = new THREE.DirectionalLight("#a9c0ff", 1.9);
        this.sun.castShadow = true;
        this.sun.shadow.mapSize.set(2048, 2048);
        R.add(this.hemi, this.sun, this.sun.target);
        const M = {
            wallA: lam("wallA", ()=>({
                    map: rep(plaster("plasterA", "#6f878d"), 1, 1),
                    side: THREE.DoubleSide
                })),
            wallB: lam("wallB", ()=>({
                    map: plaster("plasterB", "#5c6470"),
                    side: THREE.DoubleSide
                })),
            wallH: lam("wallH", ()=>({
                    map: plaster("plasterH", "#a29780"),
                    side: THREE.DoubleSide
                })),
            ceil: lam("ceil", ()=>({
                    color: "#7e878c",
                    side: THREE.DoubleSide
                })),
            floorA: lam("floorA", ()=>({
                    map: floorTex("floorA", "#6b4b37", "rgba(30,18,12,0.7)", 5),
                    side: THREE.DoubleSide
                })),
            floorB: lam("floorB", ()=>({
                    map: floorTex("floorB", "#4a4d55", "rgba(20,20,26,0.6)", 2),
                    side: THREE.DoubleSide
                })),
            floorH: lam("floorH", ()=>({
                    map: floorTex("floorH", "#8c8576", "rgba(50,44,36,0.6)", 4),
                    side: THREE.DoubleSide
                })),
            wood: lam("woodF", ()=>({
                    color: "#7a573c"
                })),
            woodD: lam("woodD", ()=>({
                    color: "#5a3f2d"
                })),
            door: lam("doorA", ()=>({
                    color: "#86613f"
                })),
            doorB: lam("doorB", ()=>({
                    color: "#6c6a58"
                })),
            mattress: lam("mattress", ()=>({
                    color: "#d9d0c0"
                })),
            blanket: lam("blanket", ()=>({
                    color: "#33507c"
                })),
            pillow: lam("pillow", ()=>({
                    color: "#e7e1d6"
                })),
            plate: lam("plate", ()=>({
                    color: "#d8d4c8"
                })),
            black: lam("blackP", ()=>({
                    color: "#15151a"
                })),
            cream: lam("cream", ()=>({
                    color: "#d6cdb8"
                })),
            rack: lam("rack", ()=>({
                    color: "#2b3138"
                })),
            cable: lam("cable", ()=>({
                    color: "#0f1114"
                })),
            steel: twoTone(new THREE.MeshPhongMaterial({
                color: "#58626d",
                specular: "#9aa4ae",
                shininess: 50
            }), 0.2),
            copper: twoTone(new THREE.MeshPhongMaterial({
                color: "#a76a3a",
                specular: "#d8a070",
                shininess: 60
            }), 0.2),
            brass: twoTone(new THREE.MeshPhongMaterial({
                color: "#b79a4a",
                specular: "#e8d890",
                shininess: 70
            }), 0.2),
            meter: twoTone(new THREE.MeshPhongMaterial({
                color: "#b3bbc2",
                specular: "#e0e6ea",
                shininess: 35
            }), 0.2),
            silver: twoTone(new THREE.MeshPhongMaterial({
                color: "#d3d8dc",
                specular: "#ffffff",
                shininess: 60
            }), 0.2),
            glassDk: new THREE.MeshBasicMaterial({
                color: "#1b232b"
            }),
            warm: new THREE.MeshBasicMaterial({
                color: HDR(2.4, 1.5, 0.6)
            }),
            cyan: new THREE.MeshBasicMaterial({
                color: HDR(0.5, 2.2, 2.6)
            }),
            bulb: new THREE.MeshBasicMaterial({
                color: HDR(2.6, 2.0, 1.1)
            })
        };
        const b = new Batch();
        const box = (x0, y0, z0, x1, y1, z1, m, tile = 0)=>b.add(boxGeo(V(x0, y0, z0), V(x1, y1, z1), tile, true), m);
        const shell = (x0, y0, z0, x1, y1, z1, m, hide, tile = 1.5)=>{
            const mesh = new THREE.Mesh(boxGeo(V(x0, y0, z0), V(x1, y1, z1), tile, true), m);
            mesh.castShadow = false;
            mesh.receiveShadow = true;
            R.add(mesh);
            this.shells.push({
                m: mesh,
                hide
            });
        };
        const T = 0.12;
        shell(-2.5, -T, -2.1, 2.5, 0, 2.1, M.floorA, ()=>false, 1);
        shell(-2.5, 2.7, -2.1, 2.5, 2.7 + T, 2.1, M.ceil, (c)=>c.y > 2.7);
        shell(-2.3 - T, 0, -2.1, -2.3, 2.7, 2.1, M.wallA, (c)=>c.x < -2.3);
        shell(2.3, 0, -2.1, 2.3 + 0.3, 2.7, 2.1, M.wallA, (c)=>c.x > 2.6 && c.z < 2.0);
        shell(-2.5, 0, -2 - T, 2.5, 2.7, -2, M.wallA, (c)=>c.z < -2 - T);
        shell(-2.5, 0, 2, 2.5, 2.7, 2 + T, M.wallA, ()=>false);
        shell(2.6, -T, -2.1, 6.7, 0, 2.1, M.floorB, ()=>false, 1);
        shell(2.6, 2.7, -2.1, 6.7, 2.7 + T, 2.1, M.ceil, (c)=>c.y > 2.7);
        shell(6.5, 0, -2.1, 6.5 + T, 2.7, 2.1, M.wallB, (c)=>c.x > 6.5 + T);
        shell(2.6, 0, -2 - T, 6.7, 2.7, -2, M.wallB, (c)=>c.z < -2 - T);
        shell(2.6, 0, 2, 6.7, 2.7, 2 + T, M.wallB, ()=>false);
        shell(-2.5, -T, 2.1, 6.7, 0, 3.7, M.floorH, ()=>false, 1);
        shell(-2.5, 2.7, 2.1, 6.7, 2.7 + T, 3.7, M.ceil, (c)=>c.y > 2.7);
        shell(-2.5, 0, 3.6, 6.7, 2.7, 3.6 + T, M.wallH, (c)=>c.z > 3.6 + T);
        shell(-2.5 - T, 0, 2.1, -2.5, 2.7, 3.7, M.wallH, (c)=>c.x < -2.5);
        shell(6.7, 0, 2.1, 6.7 + T, 2.7, 3.7, M.wallH, (c)=>c.x > 6.7 + T);
        box(-2.28, 0.1, -1.96, -1.26, 0.45, 0.06, M.woodD);
        box(-2.28, 0.0, -1.96, -2.2, 0.1, -1.88, M.woodD);
        box(-1.34, 0, -1.96, -1.26, 0.1, -1.88, M.woodD);
        box(-2.28, 0, -0.02, -2.2, 0.1, 0.06, M.woodD);
        box(-1.34, 0, -0.02, -1.26, 0.1, 0.06, M.woodD);
        box(-2.28, 0.1, -1.99, -1.26, 1.05, -1.93, M.woodD);
        box(-2.26, 0.45, -1.94, -1.28, 0.56, 0.04, M.mattress);
        box(-2.2, 0.56, -1.92, -1.34, 0.66, -1.42, M.pillow);
        box(-2.27, 0.56, -1.24, -1.27, 0.72, 0.05, M.blanket);
        box(-2.27, 0.72, -1.2, -1.31, 0.74, 0.0, M.blanket);
        box(-1.2, 0.0, -1.95, -0.74, 0.5, -1.5, M.wood);
        this.glassWater = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.03, 0.1, 16), new THREE.MeshBasicMaterial({
            color: "#9fc0d8",
            transparent: true,
            opacity: 0.55
        }));
        this.glassWater.position.set(GLASS[0], GLASS[1] + 0.04, GLASS[2]);
        R.add(this.glassWater);
        box(-0.9, 0.0, 1.2, -0.4, 0.66, 1.6, M.wood);
        const fanBase = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.04, 16), M.black);
        fanBase.position.set(FAN[0], 0.68, FAN[2]);
        R.add(fanBase);
        const fanNeck = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, 0.17, 8), M.black);
        fanNeck.position.set(FAN[0], 0.77, FAN[2]);
        R.add(fanNeck);
        const fanHead = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.05, 24), M.cream);
        fanHead.rotation.x = Math.PI / 2;
        fanHead.position.set(FAN[0], 0.92, FAN[2]);
        R.add(fanHead);
        const fanFace = new THREE.Mesh(new THREE.CircleGeometry(0.12, 24), new THREE.MeshBasicMaterial({
            map: fanTex(),
            color: 0x9a9a9a
        }));
        fanFace.position.set(FAN[0], 0.92, FAN[2] - 0.027);
        fanFace.rotation.y = Math.PI;
        R.add(fanFace);
        box(1.05, 0.06, -1.35, 1.78, 2.1, -0.05, M.woodD);
        box(1.03, 0.0, -1.33, 1.1, 0.06, -1.25, M.woodD);
        box(1.03, 0, -0.15, 1.1, 0.06, -0.07, M.woodD);
        box(1.03, 0.12, -0.72, 1.05, 2.04, -0.68, M.black);
        box(1.02, 1.0, -0.8, 1.05, 1.2, -0.77, M.brass);
        box(1.02, 1.0, -0.62, 1.05, 1.2, -0.59, M.brass);
        box(2.285, SOCKET[1] - 0.05, SOCKET[2] - 0.05, 2.3, SOCKET[1] + 0.05, SOCKET[2] + 0.05, M.plate);
        box(2.275, SOCKET[1] + 0.012, SOCKET[2] - 0.022, 2.285, SOCKET[1] + 0.03, SOCKET[2] - 0.012, M.black);
        box(2.275, SOCKET[1] + 0.012, SOCKET[2] + 0.012, 2.285, SOCKET[1] + 0.03, SOCKET[2] + 0.022, M.black);
        const heatTex = ctex("heat", 128, 256, (g)=>{
            const gr = g.createRadialGradient(64, 150, 5, 64, 150, 110);
            gr.addColorStop(0, "rgba(255,150,40,0.95)");
            gr.addColorStop(0.5, "rgba(255,90,20,0.4)");
            gr.addColorStop(1, "rgba(255,60,10,0)");
            g.fillStyle = gr;
            g.fillRect(0, 0, 128, 256);
        });
        this.heatMat = new THREE.MeshBasicMaterial({
            map: heatTex,
            transparent: true,
            depthWrite: false,
            color: HDR(1.8, 1.2, 0.8),
            opacity: 0
        });
        const heat = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.7), this.heatMat);
        heat.position.set(2.29, 0.85, -0.7);
        heat.rotation.y = -Math.PI / 2;
        heat.layers.set(NOINK);
        R.add(heat);
        this.heatGlow = glow(HDR(1.6, 0.6, 0.18), 1.0);
        this.heatGlow.position.set(2.2, 0.5, -0.7);
        R.add(this.heatGlow);
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 1.0), new THREE.MeshBasicMaterial({
            map: windowTex(),
            color: HDR(1.2, 1.4, 2.1)
        }));
        win.position.set(-1.02, 1.55, -1.985);
        R.add(win);
        box(-1.62, 1.0, -1.99, -1.5, 2.15, -1.9, M.woodD);
        box(-0.55, 1.0, -1.99, -0.43, 2.15, -1.9, M.woodD);
        const moonGlow = glow(HDR(0.5, 0.7, 1.3), 2.2);
        moonGlow.position.set(-1.02, 1.55, -1.8);
        R.add(moonGlow);
        box(-0.03, 2.62, -0.03, 0.03, 2.7, 0.03, M.black);
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 10), M.glassDk);
        bulb.position.set(0, 2.5, 0);
        R.add(bulb);
        box(0.7, 1.15, 1.93, 0.8, 1.3, 1.99, M.plate);
        box(0.73, 1.16, 1.9, 0.77, 1.2, 1.93, M.black);
        box(-0.45, 0.0, 1.9, 0.55, 2.08, 1.97, M.door);
        box(0.4, 0.95, 1.86, 0.46, 1.05, 1.9, M.brass);
        const strip = new THREE.Mesh(new THREE.PlaneGeometry(0.98, 0.03), M.warm);
        strip.position.set(0.05, 0.02, 1.896);
        strip.rotation.y = Math.PI;
        R.add(strip);
        const spill = glow(HDR(1.1, 0.7, 0.3), 1.6);
        spill.position.set(0.05, 0.06, 1.7);
        spill.scale.set(1.8, 0.5, 1);
        R.add(spill);
        for (const x of [
            -0.12,
            0.2
        ]){
            const ft = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.034, 0.02), M.black);
            ft.position.set(x, 0.02, 1.888);
            ft.visible = false;
            this.feet.push(ft);
            R.add(ft);
        }
        const clk = new THREE.Mesh(new THREE.CircleGeometry(0.2, 32), new THREE.MeshBasicMaterial({
            map: clockTex(),
            color: 0xc8c8c8
        }));
        clk.position.set(CLOCK[0], CLOCK[1], CLOCK[2]);
        R.add(clk);
        box(CLOCK[0] - 0.21, CLOCK[1] - 0.21, CLOCK[2] - 0.02, CLOCK[0] + 0.21, CLOCK[1] + 0.21, CLOCK[2] - 0.005, M.black);
        const mg = new THREE.Group();
        mg.position.set(METER[0], METER[1], METER[2]);
        R.add(mg);
        const body = new THREE.Mesh(boxGeo(V(-0.17, -0.23, 0), V(0.17, 0.23, 0.1)), M.meter);
        mg.add(body);
        const back = new THREE.Mesh(boxGeo(V(-0.2, -0.26, -0.02), V(0.2, 0.26, 0.0)), M.black);
        mg.add(back);
        this.lcdMat = new THREE.MeshBasicMaterial({
            color: 0xdadada
        });
        const lcdMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.2), this.lcdMat);
        lcdMesh.position.set(0, 0.09, 0.102);
        mg.add(lcdMesh);
        const dial = new THREE.Mesh(new THREE.CircleGeometry(0.085, 32), M.glassDk);
        dial.position.set(0, -0.12, 0.102);
        mg.add(dial);
        this.disc = new THREE.Group();
        this.disc.position.set(0, -0.12, 0.108);
        mg.add(this.disc);
        const dm = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.006, 32), M.silver);
        dm.rotation.x = Math.PI / 2;
        this.disc.add(dm);
        const mark = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.05, 0.005), new THREE.MeshBasicMaterial({
            color: HDR(1.6, 0.1, 0.1)
        }));
        mark.position.set(0, 0.04, 0.005);
        this.disc.add(mark);
        this.led = new THREE.MeshBasicMaterial({
            color: HDR(0.1, 0.1, 0.1)
        });
        const ledM = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.045, 0.02), this.led);
        ledM.position.set(0.11, 0.2, 0.108);
        mg.add(ledM);
        this.ledGlow = glow(HDR(1.5, 0.1, 0.06), 0.13);
        this.ledGlow.position.set(0.11, 0.2, 0.14);
        mg.add(this.ledGlow);
        const noteTex = paintPropText(THREE, {
            title: "Catatan",
            number: "200",
            style: "handwritten",
            paper: "white"
        }, {
            progress: 1
        });
        this.note = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.15), new THREE.MeshBasicMaterial({
            map: noteTex,
            color: 0xd8d6c8
        }));
        this.note.position.set(METER[0] + 0.02, METER[1] - 0.42, METER[2] + 0.012);
        this.note.rotation.z = 0.06;
        R.add(this.note);
        box(-0.45, 0.0, 2.12, 0.55, 2.08, 2.18, M.door);
        box(0.38, 0.95, 2.18, 0.44, 1.05, 2.24, M.brass);
        box(-0.1, 1.55, 2.18, 0.2, 1.7, 2.2, M.plate);
        box(3.9, 0.0, 2.12, 4.8, 2.08, 2.18, M.doorB);
        box(4.62, 0.94, 2.18, 4.78, 1.1, 2.2, M.steel);
        box(4.66, 0.82, 2.2, 4.76, 0.96, 2.25, M.brass);
        const shackle = new THREE.Mesh(new THREE.TorusGeometry(0.032, 0.01, 8, 16, Math.PI), M.steel);
        shackle.position.set(4.71, 0.96, 2.225);
        R.add(shackle);
        const notice = paintPropText(THREE, {
            title: "KAMAR KOSONG",
            lines: [
                "Tidak disewakan",
                "sejak dua bulan lalu"
            ],
            style: "modern",
            paper: "white"
        }, {
            progress: 1
        });
        const nm = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.32), new THREE.MeshBasicMaterial({
            map: notice,
            color: 0xd8d6c8
        }));
        nm.position.set(4.3, 1.5, 2.186);
        R.add(nm);
        for (const x of [
            1.2,
            5.6
        ]){
            const bb = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), M.bulb);
            bb.position.set(x, 2.5, 2.9);
            R.add(bb);
            const g2 = glow(HDR(1.6, 1.1, 0.5), 1.4);
            g2.position.set(x, 2.5, 2.9);
            R.add(g2);
            box(x - 0.02, 2.56, 2.88, x + 0.02, 2.7, 2.92, M.black);
        }
        for (const x of [
            -1.2,
            2.6,
            6.0
        ])box(x - 0.2, 0, 2.12, x + 0.2, 2.0, 2.15, M.doorB);
        box(2.64, 0.04, -1.3, 3.5, 1.9, 0.3, M.steel);
        for (const yy of [
            0.55,
            1.35
        ]){
            const fm = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.02, 28), new THREE.MeshBasicMaterial({
                map: fanTex(),
                color: 0xb0b0b0
            }));
            fm.rotation.z = Math.PI / 2;
            fm.position.set(3.51, yy, -0.5);
            R.add(fm);
            this.fans.push(fm);
            box(3.5, yy - 0.34, -0.86, 3.54, yy + 0.34, -0.82, M.black);
            box(3.5, yy - 0.34, -0.18, 3.54, yy + 0.34, -0.14, M.black);
        }
        box(3.5, 1.78, -1.2, 3.53, 1.85, 0.2, M.cyan);
        box(3.5, 0.1, -1.2, 3.53, 0.16, 0.2, M.cyan);
        for (const z of [
            -1.1,
            -0.2
        ]){
            const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.9, 12), M.copper);
            pipe.position.set(3.0, 2.3, z);
            R.add(pipe);
        }
        const cg = glow(HDR(0.2, 1.1, 1.3), 2.6);
        cg.position.set(3.7, 1.0, -0.5);
        R.add(cg);
        for(let i = 0; i < 3; i++){
            const x0 = 3.95 + i * 0.85;
            box(x0, 0, -1.95, x0 + 0.6, 1.95, -1.3, M.rack);
            for(let r = 0; r < 9; r++)for(let c = 0; c < 4; c++){
                const lm = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.01), new THREE.MeshBasicMaterial({
                    color: HDR(0.1, 1.8, 0.4)
                }));
                lm.position.set(x0 + 0.08 + c * 0.14, 0.4 + r * 0.17, -1.295);
                R.add(lm);
                this.rackLeds.push({
                    m: lm,
                    k: i * 36 + r * 4 + c
                });
            }
        }
        for (const [z, y] of [
            [
                -0.9,
                0.04
            ],
            [
                -0.7,
                0.04
            ],
            [
                -1.1,
                0.04
            ]
        ])box(3.5, y, z - 0.03, 5.0, y + 0.05, z + 0.03, M.cable);
        b.build(R, true);
    }
    shotSun(id, s, L) {
        let v = this.sunCache.get(id);
        if (v) return v;
        let fx = 0, fz = 0;
        for(let f = s.a; f < s.b; f += 3){
            const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
            fx += x / n;
            fz += z / n;
        }
        const n = Math.hypot(fx, fz) || 1;
        fx /= n;
        fz /= n;
        const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
        const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
        v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
        this.sunCache.set(id, v);
        return v;
    }
    actor(i) {
        while(this.actors.length <= i)this.actors.push(new Actor(this.root));
        return this.actors[i];
    }
    fx(i) {
        while(this.fxs.length <= i)this.fxs.push(new Fx(this.root));
        return this.fxs[i];
    }
    update(id, f, cam, scene) {
        const t = f / FPS, s = SHOTS[id - 1], L = LIGHTS[s.light], K = LOOK[s.light];
        const c = camAt(id, f);
        cam.position.set(...c.pos);
        cam.up.set(0, 1, 0);
        cam.lookAt(...c.look);
        cam.rotateZ(c.roll);
        cam.fov = c.fov;
        cam.near = 0.05;
        cam.far = 400;
        cam.updateProjectionMatrix();
        cam.updateMatrixWorld();
        const focus = V(...c.look), dist = cam.position.distanceTo(focus);
        cam.layers.enable(NOINK);
        for (const sh of this.shells)sh.m.visible = !sh.hide(cam.position);
        const sunDir = this.shotSun(id, s, L);
        this.hemi.color.set(L.sky);
        this.hemi.groundColor.set(L.ground);
        this.hemi.intensity = L.hemiI;
        this.sun.color.set(L.sunCol);
        this.sun.intensity = L.sunI;
        const Rr = THREE.MathUtils.clamp(dist * 1.2 + 2.5, 4, 12);
        this.sun.position.copy(focus).addScaledVector(sunDir, 30);
        this.sun.target.position.copy(focus);
        const sc = this.sun.shadow.camera;
        sc.left = -Rr;
        sc.right = Rr;
        sc.top = Rr;
        sc.bottom = -Rr;
        sc.near = 1;
        sc.far = 70;
        sc.updateProjectionMatrix();
        this.sun.shadow.bias = L.bias;
        this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
        TONE.uLitCol.value.set(...L.lit);
        TONE.uShadeCol.value.set(...L.shade);
        TONE.uShadeLift.value.set(...L.lift);
        TONE.uLambert.value = L.lambert;
        TONE.uSideK.value = L.sideK;
        TONE.uTerm.value = L.term;
        TONE.uBounce.value.set(...K.bounce);
        TONE.uSat.value = K.sat;
        CHAR.uCharTint.value.set(...L.charTint);
        CHAR.uCharShade.value = L.charShade;
        CHAR.uGrad.value = L.charGrad;
        CHAR.uBodyGrad.value = L.bodyGrad;
        CHAR.uSideTint.value.set(...L.sideTint);
        const su = this.skyMat.uniforms;
        K.sky.c.forEach((h, i)=>untone(h, su["c" + i].value));
        const e = K.sky.e.map((d)=>THREE.MathUtils.degToRad(d));
        su.e.value.set(e[1], e[2], e[3], e[4]);
        this.sky.position.copy(cam.position);
        untone(L.fog, this.fog.color);
        this.fog.near = L.fogNear;
        this.fog.far = L.fogFar;
        scene.fog = this.fog;
        scene.background = null;
        setSun(this.root);
        this.disc.rotation.z = -meterRev(t) * Math.PI * 2;
        const kwh = Math.round(meterKwh(t) / 1);
        const key = String(kwh);
        if (key !== this.lcdKey) {
            const old = this.lcdMat.map;
            this.lcdMat.map = lcd(kwh);
            this.lcdMat.needsUpdate = true;
            old?.dispose();
            this.lcdKey = key;
        }
        const led = ledAt(t);
        if (t < 26.9) {
            this.led.color.copy(HDR(0.08, 0.7, 0.2));
            this.ledGlow.visible = false;
        } else {
            this.led.color.copy(HDR(0.25 + 3.4 * led, 0.02 + 0.1 * led, 0.02 + 0.08 * led));
            this.ledGlow.visible = led > 0.5;
            this.ledGlow.material.color.copy(HDR(1.5 * led, 0.1, 0.06));
        }
        this.note.visible = noteVisible(t);
        const h = heatAt(t);
        this.heatMat.opacity = h * (0.85 + 0.15 * Math.sin(t * 5));
        this.heatGlow.visible = h > 0.05;
        this.heatGlow.material.color.copy(HDR(1.6 * h, 0.6 * h, 0.18 * h));
        for (const fm of this.fans)fm.rotation.x = t * 14;
        for (const r of this.rackLeds){
            const on = Math.sin(t * (3 + r.k % 5) + r.k * 1.7) > -0.2;
            r.m.material.color.copy(r.k % 7 === 0 ? HDR(2.2, 0.9, 0.1) : HDR(0.1, on ? 1.8 : 0.15, 0.4));
        }
        const fa = t > 25.4 && t < 27.4;
        this.feet.forEach((ft, i)=>{
            ft.visible = fa && (i === 0 || t > 25.9);
            ft.position.x = (i ? 0.2 : -0.12) + 0.01 * Math.sin(t * 9 + i);
        });
        this.glassWater.position.y = GLASS[1] + 0.04 + (id === 26 ? 0.0015 * Math.sin(t * 60) : 0);
        const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
        const st = stage(id, t, {
            pos: cam.position,
            right
        });
        let ai = 0;
        const used = [];
        for (const p of st.places){
            const sc2 = p.scale ?? 1, a = this.actor(ai++);
            const [w, hh, k] = p.size ?? [
                300,
                500,
                0.5
            ];
            a.r = this.pool.req(p.key, w, hh, k, p.draw);
            a.mesh.visible = true;
            a.mesh.position.set(p.x, p.y, p.z);
            a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
            a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
            a.mesh.castShadow = L.actorShadow;
            used.push(a);
        }
        for(let i = ai; i < this.actors.length; i++)this.actors[i].mesh.visible = false;
        let fi = 0;
        const fused = [];
        for (const p of st.fx){
            const e2 = this.fx(fi++);
            e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
            e2.use(!!p.soft);
            e2.mesh.visible = true;
            e2.mesh.position.set(p.x, p.y, p.z);
            if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
            else {
                e2.mesh.quaternion.copy(cam.quaternion);
                e2.mesh.rotateZ(p.rot ?? 0);
            }
            e2.mesh.scale.set(p.w, p.h, 1);
            fused.push(e2);
        }
        for(let i = fi; i < this.fxs.length; i++)this.fxs[i].mesh.visible = false;
        this.pool.flush();
        for (const a of used)a.bind();
        for (const e3 of fused)e3.bind();
        return focus;
    }
}
