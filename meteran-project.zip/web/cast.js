import * as THREE from "three";
import { Pen, bodyFront, bodySide, fxRing, fxContact } from "./toon.js";
import { FPS, dito, GLASS, hum, BED_HEAD } from "./story.js";
import { NOINK } from "./ink.js";
import { cardShade, blobMaterial, CARD_K } from "./cardshade.js";
const makeEntry = (w, h)=>{
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return {
        cv,
        tex,
        w,
        h
    };
};
export class Pool {
    live = new Map();
    free = [];
    reqs = [];
    req(key, w, h, k, draw) {
        const r = {
            key: `${w}x${h}|${key}`,
            w,
            h,
            k,
            draw
        };
        this.reqs.push(r);
        return r;
    }
    flush() {
        const want = new Map();
        for (const r of this.reqs){
            const l = want.get(r.key);
            if (l) l.push(r);
            else want.set(r.key, [
                r
            ]);
        }
        for (const [key, e] of this.live)if (!want.has(key)) {
            this.live.delete(key);
            this.free.push(e);
        }
        for (const [key, rs] of want){
            let e = this.live.get(key);
            if (!e) {
                const r = rs[0], i = this.free.findIndex((x)=>x.w === r.w && x.h === r.h);
                e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
                const g = e.cv.getContext("2d");
                g.setTransform(1, 0, 0, 1, 0, 0);
                g.clearRect(0, 0, e.w, e.h);
                g.setTransform(r.k, 0, 0, r.k, 0, 0);
                r.draw(new Pen(g));
                e.tex.needsUpdate = true;
                this.live.set(key, e);
            }
            for (const r of rs)r.tex = e.tex;
        }
        this.reqs = [];
    }
}
const blank = (()=>{
    const c = document.createElement("canvas");
    c.width = c.height = 2;
    return new THREE.CanvasTexture(c);
})();
export const SU = 0.00216;
export const SU_SWING = 2.3 / 1830;
const BODY = (()=>{
    const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU);
    g.translate(0, (975 - 500) * SU, 0);
    return g;
})();
const CARD = new THREE.PlaneGeometry(1, 1);
const ROOTS = new Set();
export class Actor {
    mesh;
    mat;
    dmat;
    r = null;
    constructor(parent, geo = BODY){
        this.mat = cardShade(new THREE.MeshLambertMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        }));
        this.mat.alphaToCoverage = false;
        this.dmat = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mesh = new THREE.Mesh(geo, this.mat);
        this.mesh.customDepthMaterial = this.dmat;
        this.mesh.onBeforeRender = (r)=>{
            const rt = r.getRenderTarget();
            CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920;
        };
        this.mesh.castShadow = false;
        this.mesh.receiveShadow = true;
        this.mesh.visible = false;
        this.mesh.rotation.order = "YXZ";
        this.mesh.renderOrder = 1;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
        ROOTS.add(parent);
    }
    bind() {
        const t = this.r?.tex;
        if (t) {
            this.mat.map = t;
            this.dmat.map = t;
        }
    }
}
export class Fx {
    mesh;
    mat;
    soft;
    blob;
    r = null;
    constructor(parent){
        this.mat = new THREE.MeshBasicMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mat.alphaToCoverage = false;
        this.soft = new THREE.MeshBasicMaterial({
            map: blank,
            transparent: true,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.blob = blobMaterial(blank);
        this.mesh = new THREE.Mesh(CARD, this.mat);
        this.mesh.visible = false;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
    }
    use(soft) {
        this.mesh.material = soft ? this.soft : this.mat;
    }
    bind() {
        const t = this.r?.tex;
        if (!t) return;
        if (this.r.key.includes("|blob|")) {
            if (t.generateMipmaps) {
                t.generateMipmaps = false;
                t.minFilter = THREE.LinearFilter;
                t.needsUpdate = true;
            }
            this.blob.map = t;
            this.mesh.material = this.blob;
            this.mesh.renderOrder = 0.5;
        } else {
            this.mat.map = t;
            this.soft.map = t;
            this.mesh.renderOrder = 0;
        }
    }
}
export { FPS };
const DITO = {
    jacket: "#7d9bd0",
    pants: "#43527c",
    boots: "#e8dfd0",
    hat: "hair",
    hair: "#2b1c15",
    build: "adult"
};
const q = (v, n = 120)=>Math.round(v * n) / n;
const fkey = (o)=>JSON.stringify(o, (_k, v)=>typeof v === "number" ? q(v) : v);
const tier = (d)=>d < 3.2 ? [
        1800,
        3000,
        3.0
    ] : d < 6.5 ? [
        1080,
        1800,
        1.8
    ] : [
        480,
        800,
        0.8
    ];
const SUN = new THREE.Vector3(0.3, 0.7, 0.5).normalize();
const light2D = (cam, mirror)=>{
    const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
    return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};
const sunOf = (root)=>{
    let s = null;
    root?.traverse((o)=>{
        if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o;
    });
    return s;
};
export const setSun = (root)=>{
    const s = sunOf(root);
    if (s) SUN.copy(s.position).sub(s.target.position).normalize();
};
export const stage = (id, t, cam)=>{
    const out = {
        places: [],
        fx: []
    };
    const d = dito(id, t);
    if (d.vis) {
        const dist = cam.pos.distanceTo(new THREE.Vector3(d.x, d.y + 1.0, d.z));
        const [w, h, k] = tier(dist);
        const dx = 1, dz = 0;
        const tx = cam.pos.x - d.x, tz = cam.pos.z - d.z, tl = Math.hypot(tx, tz) || 1;
        const c = (tx * dx + tz * dz) / tl;
        const side = d.mode === "side" && c < 0.57, mirror = side && dx * cam.right.x + dz * cam.right.z < 0;
        const light = light2D(cam, mirror);
        const expr = d.expr;
        const fo = {
            mode: d.mode === "stand" ? "stand" : "sit",
            expr,
            blink: d.lid,
            look: d.look,
            light,
            seed: 4,
            headTilt: d.mode === "sit" ? 0.05 : 0
        };
        const so = {
            mode: "stand",
            expr,
            blink: d.lid,
            light,
            seed: 4
        };
        const key = (side ? "S" : "F") + "|" + fkey(side ? so : fo) + "|" + w;
        out.places.push({
            key,
            x: d.x,
            y: d.y,
            z: d.z,
            mirror,
            roll: d.roll,
            scale: 1 + d.breathe,
            size: [
                w,
                h,
                k
            ],
            draw: (p)=>side ? bodySide(p, DITO, so) : bodyFront(p, DITO, fo)
        });
    }
    if (id === 26) {
        for(let i = 0; i < 3; i++){
            const ph = (t * 2.4 + i / 3) % 1;
            out.fx.push({
                key: `ripple|${Math.round(ph * 12)}`,
                cw: 600,
                ch: 600,
                draw: (p)=>fxRing(p, ph),
                x: GLASS[0],
                y: GLASS[1] + 0.088,
                z: GLASS[2],
                w: 0.1 + 0.05 * ph,
                h: 0.1 + 0.05 * ph,
                flat: true
            });
        }
    }
    return out;
};
