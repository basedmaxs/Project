// proptext.js: painter teks diegetic untuk prop (parchment, sign, price_list, kalkulator, dll.)
// Taruh di engine/ dan panggil dari world builder: const tex = paintPropText(THREE, prop.text, {progress});
// Input = objek "text" dari storyboard.schema.json. Teks TIDAK PERNAH kosong: judul wajib.
const FONTS = {
  medieval: 'bold {s}px "UnifrakturCook","Cinzel","DejaVu Serif",serif',
  modern: 'bold {s}px "Montserrat","DejaVu Sans",sans-serif',
  handwritten: '{s}px "Caveat","Comic Sans MS",cursive',
  mono: 'bold {s}px "DejaVu Sans Mono",monospace',
  stone: 'bold {s}px "DejaVu Serif",serif',
  chalk: '{s}px "Caveat","Comic Sans MS",cursive',
};
const PAPER = {
  parchment: { bg: '#f1e2b8', ink: '#2a1a0e', edge: 'rgba(120,80,30,.45)' },
  white:     { bg: '#f4f2ec', ink: '#1a1a1a', edge: 'rgba(0,0,0,.2)' },
  wood:      { bg: '#c9a06a', ink: '#3a1d0c', edge: 'rgba(60,30,10,.5)' },
  stone:     { bg: '#9a948a', ink: '#16120f', edge: 'rgba(0,0,0,.4)' },
  dark:      { bg: '#2b2730', ink: '#f0e8d8', edge: 'rgba(0,0,0,.6)' },
  lcd_green: { bg: '#a9c7a0', ink: '#1d2a1a', edge: 'rgba(0,0,0,.25)' },
  blue_sign: { bg: '#1f4f86', ink: '#ffffff', edge: 'rgba(0,0,0,.4)' },
};

const rng = (seed) => () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const hash = (str) => [...str].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);

// Kecilkan font sampai teks muat di lebar maksimum. Ini yang mencegah teks terpotong.
function fit(g, tpl, text, size, maxW) {
  let s = size;
  for (; s > 18; s -= 2) { g.font = tpl.replace('{s}', s); if (g.measureText(text).width <= maxW) break; }
  return s;
}

export function paintPropText(THREE, spec, opts = {}) {
  if (!spec || !spec.title) throw new Error('paintPropText: "title" wajib. Prop berteks tidak boleh kosong.');
  const W = opts.w || 1024, H = opts.h || 1024, progress = opts.progress ?? 1; // 0..1 untuk reveal
  const P = PAPER[spec.paper || 'parchment'], tpl = FONTS[spec.style || 'medieval'];
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'), r = rng(hash(spec.title));

  // kertas + noda + tepi gelap (supaya tidak terasa datar)
  g.fillStyle = P.bg; g.fillRect(0, 0, W, H);
  for (let i = 0; i < 70; i++) {
    g.fillStyle = `rgba(90,60,20,${0.03 + r() * 0.05})`;
    g.beginPath(); g.arc(r() * W, r() * H, 20 + r() * 90, 0, 7); g.fill();
  }
  const vg = g.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, P.edge);
  g.fillStyle = vg; g.fillRect(0, 0, W, H);

  g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = P.ink;
  const maxW = W * 0.82;
  const shown = (t) => (spec.reveal === 'typewriter' ? t.slice(0, Math.ceil(t.length * progress)) : t);
  g.globalAlpha = spec.reveal === 'fade' ? progress : 1;

  let y = H * 0.14;
  const ts = fit(g, tpl, spec.title, 130, maxW); g.font = tpl.replace('{s}', ts);
  g.fillText(shown(spec.title), W / 2, y); y += ts * 0.95;

  if (spec.number) {                                   // angka besar (kalkulator, harga)
    const ns = fit(g, FONTS.mono, spec.number, 150, maxW); g.font = FONTS.mono.replace('{s}', ns);
    g.fillText(shown(spec.number), W / 2, y + ns * 0.4); y += ns * 1.1;
  }
  for (const line of spec.lines || []) {               // baris isi
    const ls = fit(g, tpl, line, 70, maxW); g.font = tpl.replace('{s}', ls);
    g.fillText(shown(line), W / 2, y + ls * 0.4); y += ls * 1.25;
  }
  (spec.rows || []).forEach(([label, val], i) => {     // price_list / ledger
    const ry = y + 30 + i * 105; g.font = tpl.replace('{s}', 64);
    g.textAlign = 'left'; g.fillText(shown(label), W * 0.1, ry);
    g.textAlign = 'right'; g.fillText(shown(val), W * 0.9, ry);
    g.fillRect(W * 0.1, ry + 48, W * 0.8, 3);
  });
  g.globalAlpha = 1; g.textAlign = 'center';

  if (spec.stamp && (spec.reveal !== 'stamp_slam' || progress > 0)) {   // cap merah miring
    const k = spec.reveal === 'stamp_slam' ? 1 + 0.5 * (1 - Math.min(1, progress * 4)) : 1;
    g.save(); g.translate(W * 0.55, H * 0.84); g.rotate(-0.2); g.scale(k, k);
    const ss = fit(g, tpl, spec.stamp, 130, W * 0.7); g.font = tpl.replace('{s}', ss);
    g.strokeStyle = g.fillStyle = 'rgba(179,32,31,.92)'; g.lineWidth = 10;
    const w = g.measureText(spec.stamp).width + 50;
    g.strokeRect(-w / 2, -ss * 0.7, w, ss * 1.4); g.fillText(spec.stamp, 0, 0);
    g.restore();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return tex; // UV planar: cek hasilnya tidak terbalik (mirrored), lihat world.md 4.6
}
