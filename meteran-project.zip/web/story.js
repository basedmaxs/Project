import { direct, camsFrom, kicksFrom, dofFrom } from "./director.js";
export const FPS = 30;
export const TOTAL = 2421;
export const D0 = 0;
export const clamp01 = (x)=>Math.min(1, Math.max(0, x));
export const smooth = (x)=>{
    const t = clamp01(x);
    return t * t * t * (t * (6 * t - 15) + 10);
};
export const lerp = (a, b, k)=>a + (b - a) * k;
const S = [
    [
        0.0,
        "hall",
        "lorong"
    ],
    [
        1.85,
        "a",
        "meteran pagi"
    ],
    [
        4.77,
        "a",
        "lampu mati"
    ],
    [
        7.51,
        "a",
        "kipas mati"
    ],
    [
        9.41,
        "a",
        "dito janggal"
    ],
    [
        11.41,
        "a",
        "dito mencatat"
    ],
    [
        14.07,
        "a",
        "angka 200"
    ],
    [
        16.29,
        "a",
        "pura-pura tidur"
    ],
    [
        19.61,
        "a",
        "mata sedikit terbuka"
    ],
    [
        21.53,
        "a",
        "kamar padam"
    ],
    [
        23.79,
        "a",
        "tengah malam"
    ],
    [
        25.73,
        "a",
        "klik pintu"
    ],
    [
        26.95,
        "a",
        "meteran berputar"
    ],
    [
        29.89,
        "a",
        "led merah"
    ],
    [
        33.11,
        "a",
        "menahan napas"
    ],
    [
        36.55,
        "a",
        "mata terbuka"
    ],
    [
        38.49,
        "a",
        "melambat"
    ],
    [
        43.39,
        "a",
        "sunyi"
    ],
    [
        47.03,
        "a",
        "memejam lagi"
    ],
    [
        50.19,
        "a",
        "berputar lagi"
    ],
    [
        52.75,
        "a",
        "menyedot daya"
    ],
    [
        55.21,
        "a",
        "bangkit"
    ],
    [
        57.53,
        "a",
        "balik lemari"
    ],
    [
        60.31,
        "a",
        "colokan kosong"
    ],
    [
        63.07,
        "a",
        "dinding hangat"
    ],
    [
        66.09,
        "a",
        "getaran"
    ],
    [
        69.03,
        "a",
        "telinga ke dinding"
    ],
    [
        71.71,
        "b",
        "mesin pendingin"
    ],
    [
        75.61,
        "hall",
        "pintu kosong"
    ],
    [
        78.77,
        "hall",
        "gembok"
    ]
];
export const SHOTS = S.map(([s, place, name], i)=>({
        id: i + 1,
        a: Math.round(s * FPS),
        b: i + 1 < S.length ? Math.round(S[i + 1][0] * FPS) : TOTAL,
        light: "night",
        tau: (t)=>t,
        place,
        name
    }));
export const XFADE = {};
export const FLASH_AT = 99999;
export const shotAt = (f)=>SHOTS.find((s)=>f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f)=>[
        {
            id: shotAt(f).id,
            alpha: 1
        }
    ];
export const METER = [
    0.75,
    1.55,
    -1.93
];
export const CLOCK = [
    1.55,
    2.12,
    -1.96
];
export const SOCKET = [
    2.27,
    0.45,
    -0.7
];
export const GLASS = [
    -0.97,
    0.53,
    -1.72
];
export const FAN = [
    -0.65,
    0.78,
    1.4
];
export const DOOR_A = [
    0.05,
    0,
    1.99
];
export const DOOR_B = [
    4.35,
    0,
    1.99
];
export const BED_HEAD = [
    -1.78,
    0.62,
    -1.22
];
const rateAt = (t)=>t >= 1.85 && t < 4.77 ? 2.6 : t < 26.95 ? 0 : t < 38.49 ? 4 : t < 40.9 ? 4 - 3.7 * smooth((t - 38.49) / 2.2) : t < 49.9 ? 0.3 : t < 50.6 ? 0.3 + 3.7 * smooth((t - 49.9) / 0.7) : 4;
let revCache = null;
export const meterRev = (t)=>{
    if (!revCache) {
        revCache = [];
        let v = 0;
        for(let i = 0; i <= TOTAL + 30; i++){
            revCache.push({
                t: i / FPS,
                v
            });
            v += rateAt(i / FPS) / FPS;
        }
    }
    const i = Math.min(revCache.length - 1, Math.max(0, Math.floor(t * FPS)));
    const f = t * FPS - i;
    return revCache[i].v + (revCache[Math.min(revCache.length - 1, i + 1)].v - revCache[i].v) * f;
};
export const meterKwh = (t)=>t < 1.85 ? 200 : t < 4.77 ? 200 + 87 * smooth((t - 1.85) / 2.4) : t < 26.95 ? 200 : 200 + 16 * (meterRev(t) - meterRev(26.95));
export const ledAt = (t)=>{
    if (t >= 29.9 && t < 41.17) return Math.floor(t * 6) % 2 === 0 ? 1 : 0.12;
    if (t >= 41.17 && t < 50.19) return 0.08;
    if (t >= 50.19) return Math.floor(t * 8) % 2 === 0 ? 1 : 0.12;
    return 0;
};
export const heatAt = (t)=>clamp01((t - 59.5) / 3) * 0.7 + clamp01((t - 63.0) / 1.5) * 0.3;
export const hum = (t)=>t > 66.0 ? 1 : 0;
export const noteVisible = (t)=>t >= 13.0;
const BED = {
    x: -1.78,
    y: 0.5,
    z: -1.2
};
export const dito = (id, t)=>{
    const base = {
        vis: false,
        ...BED,
        mode: "sit",
        expr: "neutral",
        lid: 0,
        roll: -0.14,
        look: 0,
        breathe: 0
    };
    const lie = (expr, lid, roll = -0.14)=>({
            ...base,
            vis: true,
            expr,
            lid,
            roll,
            breathe: 0.012 * Math.sin(t * 2.2)
        });
    if (id === 5) return {
        ...base,
        vis: true,
        mode: "stand",
        x: 0.2,
        y: 0,
        z: -1.15,
        expr: t < 10.4 ? "nervous" : "stern",
        look: 1
    };
    if (id === 6) return {
        ...base,
        vis: true,
        mode: "stand",
        x: 0.62,
        y: 0,
        z: -1.35,
        expr: "stern",
        look: 1
    };
    if (id === 8) return lie("neutral", 1);
    if (id === 9) return lie("neutral", 0.78);
    if (id >= 10 && id <= 14) return lie("neutral", id === 10 ? 0.85 : 0.8);
    if (id === 15) return lie("nervous", 0.75);
    if (id === 16) return lie("shock", 0);
    if (id === 17) return lie(t < 41.2 ? "shock" : "nervous", 0);
    if (id === 18) return lie(t < 45.0 ? "nervous" : "stern", 0);
    if (id === 19) return lie("neutral", 1);
    if (id === 20 || id === 21) return lie("neutral", 1);
    if (id === 22) {
        const k = smooth((t - 55.6) / 1.4);
        return {
            ...lie("nervous", 0, -0.14 * (1 - k)),
            breathe: 0
        };
    }
    if (id === 23) return {
        ...base,
        vis: true,
        mode: "stand",
        x: 0.62,
        y: 0,
        z: -0.3,
        expr: "stern",
        look: 1
    };
    if (id === 25) return {
        ...base,
        vis: true,
        mode: "stand",
        x: 1.9,
        y: 0,
        z: 0.25,
        expr: "shock",
        look: 1
    };
    if (id === 27) return {
        ...base,
        vis: true,
        mode: "side",
        x: 2.12,
        y: 0,
        z: 0.75,
        expr: "neutral",
        look: 1
    };
    return base;
};
const mk = (id, beat, kind, target, size, extra = {})=>{
    const s = SHOTS[id - 1];
    return {
        id,
        a: s.a,
        b: s.b,
        beat,
        kind,
        target,
        size,
        forbid: [
            "whip_pan",
            "iris_reveal"
        ],
        ...extra
    };
};
const W = (s)=>Math.round(s * FPS);
export const BRIEFS = [
    mk(1, "hook", "interior", [
        1.0,
        1.25,
        2.8
    ], 4.5),
    mk(2, "reveal", "prop", METER, 0.55, {
        facing: 0
    }),
    mk(3, "setup", "interior", [
        0,
        1.1,
        0
    ], 4.6),
    mk(4, "explain", "prop", FAN, 0.5),
    mk(5, "introduce", "character", [
        0.2,
        1.0,
        -1.15
    ], 1.9),
    mk(6, "explain", "twoShot", [
        0.62,
        1.2,
        -1.5
    ], 1.4),
    mk(7, "reveal", "prop", METER, 0.4, {
        facing: 0,
        emphasisF: W(14.9)
    }),
    mk(8, "setup", "character", [
        -1.75,
        0.95,
        -1.15
    ], 1.4),
    mk(9, "tension", "character", [
        -1.7,
        1.33,
        -1.2
    ], 0.42),
    mk(10, "establish", "interior", [
        0,
        1.0,
        0
    ], 4.6),
    mk(11, "transition", "prop", CLOCK, 0.5, {
        facing: 0
    }),
    mk(12, "tension", "prop", [
        0.05,
        0.25,
        1.9
    ], 0.9, {
        facing: Math.PI
    }),
    mk(13, "escalate", "prop", METER, 0.55, {
        facing: 0
    }),
    mk(14, "tension", "prop", [
        0.75,
        1.74,
        -1.9
    ], 0.28, {
        facing: 0
    }),
    mk(15, "tension", "character", [
        -1.7,
        1.3,
        -1.2
    ], 0.6),
    mk(16, "impact", "character", [
        -1.7,
        1.33,
        -1.2
    ], 0.45, {
        impactF: W(36.6)
    }),
    mk(17, "aftermath", "prop", METER, 0.8, {
        facing: 0
    }),
    mk(18, "callback", "interior", [
        -0.8,
        0.95,
        -0.7
    ], 3.6),
    mk(19, "setup", "character", [
        -1.7,
        1.25,
        -1.2
    ], 1.1),
    mk(20, "escalate", "prop", METER, 0.55, {
        facing: 0
    }),
    mk(21, "tension", "interior", [
        0,
        1.2,
        -0.5
    ], 4.6),
    mk(22, "escalate", "character", [
        -1.75,
        1.0,
        -1.15
    ], 1.6),
    mk(23, "introduce", "prop", [
        1.9,
        0.9,
        -0.7
    ], 1.5, {
        facing: -Math.PI / 2
    }),
    mk(24, "reveal", "prop", SOCKET, 0.45, {
        facing: -Math.PI / 2
    }),
    mk(25, "reveal", "flat", [
        2.28,
        1.0,
        0.9
    ], 1.4, {
        facing: -Math.PI / 2
    }),
    mk(26, "tension", "prop", GLASS, 0.3, {
        facing: 0
    }),
    mk(27, "escalate", "character", [
        2.0,
        1.0,
        0.75
    ], 1.7, {
        facing: Math.PI / 2
    }),
    mk(28, "reveal", "interior", [
        3.6,
        0.95,
        -0.4
    ], 3.2),
    mk(29, "setup", "prop", [
        4.35,
        1.5,
        2.0
    ], 1.1, {
        facing: Math.PI
    }),
    mk(30, "punchline", "prop", [
        4.78,
        1.02,
        2.04
    ], 0.4, {
        facing: Math.PI
    })
];
const R = direct(BRIEFS, {
    seed: "meteran-malam",
    personality: "intimate",
    allowWhip: false,
    history: []
});
console.log(R.report);
export const glide = (u)=>smooth(u);
const mix = (a, b, k)=>({
        pos: a.pos.map((v, i)=>v + (b.pos[i] - v) * k),
        look: a.look.map((v, i)=>v + (b.look[i] - v) * k),
        fov: a.fov + (b.fov - a.fov) * k,
        roll: a.roll + (b.roll - a.roll) * k
    });
const full = (c)=>({
        fov: 40,
        roll: 0,
        ...c
    });
const run = (keys, f)=>{
    let cur = full(keys[0].s(f));
    for(let i = 1; i < keys.length; i++){
        const k = keys[i];
        if (f < k.f) break;
        cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
    }
    return cur;
};
export const CAMS = camsFrom(R.shots);
const HAND = {
    12: [
        [
            0.05,
            0.5,
            0.85
        ],
        [
            0.05,
            0.08,
            1.9
        ],
        [
            0.05,
            0.38,
            1.1
        ],
        [
            0.05,
            0.08,
            1.9
        ],
        38,
        5
    ],
    1: [
        [
            5.8,
            1.45,
            3.05
        ],
        [
            0.0,
            1.3,
            2.15
        ],
        [
            3.9,
            1.45,
            3.0
        ],
        [
            0.05,
            1.3,
            2.15
        ],
        38,
        0
    ],
    2: [
        [
            0.2,
            1.45,
            -0.85
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        [
            0.55,
            1.55,
            -1.15
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        38,
        9
    ],
    3: [
        [
            1.9,
            1.4,
            1.75
        ],
        [
            -0.3,
            1.3,
            -0.8
        ],
        [
            1.6,
            1.25,
            1.5
        ],
        [
            0.0,
            2.3,
            0.0
        ],
        40,
        0
    ],
    4: [
        [
            -0.25,
            0.95,
            0.4
        ],
        [
            -0.65,
            0.85,
            1.4
        ],
        [
            -0.4,
            0.95,
            0.75
        ],
        [
            -0.65,
            0.85,
            1.4
        ],
        36,
        9
    ],
    6: [
        [
            -0.5,
            1.5,
            0.3
        ],
        [
            0.65,
            1.3,
            -1.4
        ],
        [
            -0.1,
            1.45,
            -0.1
        ],
        [
            0.65,
            1.3,
            -1.4
        ],
        40,
        0
    ],
    7: [
        [
            0.72,
            1.68,
            -1.35
        ],
        [
            0.75,
            1.62,
            -1.93
        ],
        [
            0.74,
            1.66,
            -1.5
        ],
        [
            0.75,
            1.6,
            -1.93
        ],
        34,
        11
    ],
    8: [
        [
            -0.4,
            1.35,
            0.9
        ],
        [
            -1.75,
            1.05,
            -1.2
        ],
        [
            -0.8,
            1.3,
            0.5
        ],
        [
            -1.75,
            1.05,
            -1.2
        ],
        40,
        0
    ],
    10: [
        [
            1.9,
            1.6,
            1.8
        ],
        [
            -0.5,
            0.9,
            -0.9
        ],
        [
            1.5,
            1.45,
            1.4
        ],
        [
            -0.5,
            0.9,
            -0.9
        ],
        42,
        0
    ],
    13: [
        [
            0.5,
            1.5,
            -0.95
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        [
            0.64,
            1.55,
            -1.25
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        38,
        9
    ],
    14: [
        [
            0.95,
            1.7,
            -1.1
        ],
        [
            0.8,
            1.62,
            -1.93
        ],
        [
            0.9,
            1.68,
            -1.3
        ],
        [
            0.8,
            1.62,
            -1.93
        ],
        36,
        8
    ],
    17: [
        [
            1.4,
            1.5,
            -0.7
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        [
            1.15,
            1.5,
            -1.0
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        38,
        8
    ],
    18: [
        [
            1.9,
            1.5,
            1.6
        ],
        [
            -1.0,
            0.8,
            -0.8
        ],
        [
            1.2,
            1.3,
            1.0
        ],
        [
            -1.0,
            0.8,
            -0.8
        ],
        40,
        0
    ],
    20: [
        [
            0.1,
            1.5,
            -0.95
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        [
            0.4,
            1.52,
            -1.3
        ],
        [
            0.75,
            1.55,
            -1.93
        ],
        38,
        9
    ],
    21: [
        [
            -2.0,
            1.7,
            1.7
        ],
        [
            1.0,
            1.0,
            -0.6
        ],
        [
            -1.6,
            1.55,
            1.3
        ],
        [
            1.0,
            1.0,
            -0.6
        ],
        42,
        0
    ],
    22: [
        [
            -0.4,
            1.3,
            0.9
        ],
        [
            -1.7,
            1.15,
            -1.2
        ],
        [
            -0.5,
            1.35,
            0.8
        ],
        [
            -1.7,
            1.15,
            -1.2
        ],
        40,
        0
    ],
    23: [
        [
            -0.9,
            1.4,
            1.4
        ],
        [
            1.0,
            1.0,
            -0.4
        ],
        [
            -0.6,
            1.35,
            1.2
        ],
        [
            1.0,
            1.0,
            -0.4
        ],
        42,
        0
    ],
    24: [
        [
            2.05,
            0.62,
            0.5
        ],
        [
            2.27,
            0.45,
            -0.7
        ],
        [
            2.1,
            0.56,
            0.0
        ],
        [
            2.27,
            0.45,
            -0.7
        ],
        36,
        9
    ],
    25: [
        [
            0.9,
            1.2,
            1.0
        ],
        [
            2.0,
            1.0,
            -0.1
        ],
        [
            1.2,
            1.15,
            0.8
        ],
        [
            2.0,
            1.0,
            -0.1
        ],
        40,
        0
    ],
    26: [
        [
            -0.55,
            0.85,
            -1.15
        ],
        [
            -0.97,
            0.58,
            -1.72
        ],
        [
            -0.65,
            0.78,
            -1.3
        ],
        [
            -0.97,
            0.58,
            -1.72
        ],
        34,
        10
    ],
    27: [
        [
            0.2,
            1.2,
            1.9
        ],
        [
            2.1,
            0.95,
            0.75
        ],
        [
            0.5,
            1.15,
            1.7
        ],
        [
            2.1,
            0.95,
            0.75
        ],
        40,
        0
    ],
    28: [
        [
            5.9,
            1.5,
            1.6
        ],
        [
            3.2,
            0.95,
            -0.5
        ],
        [
            5.3,
            1.35,
            1.2
        ],
        [
            3.2,
            0.95,
            -0.5
        ],
        42,
        0
    ],
    29: [
        [
            4.2,
            1.6,
            3.3
        ],
        [
            4.35,
            1.5,
            2.15
        ],
        [
            4.3,
            1.55,
            3.0
        ],
        [
            4.35,
            1.5,
            2.15
        ],
        38,
        0
    ],
    30: [
        [
            4.5,
            1.1,
            3.0
        ],
        [
            4.72,
            0.95,
            2.25
        ],
        [
            4.62,
            1.0,
            2.7
        ],
        [
            4.72,
            0.95,
            2.25
        ],
        34,
        10
    ]
};
for (const [k, [pa, la, pb, lb, fov]] of Object.entries(HAND)){
    const sh = SHOTS[+k - 1];
    CAMS[+k] = [
        {
            f: sh.a,
            s: ()=>({
                    pos: pa,
                    look: la,
                    fov
                })
        },
        {
            f: sh.a,
            dur: sh.b - sh.a,
            s: ()=>({
                    pos: pb,
                    look: lb,
                    fov
                })
        }
    ];
}
const KICKS = kicksFrom(R.shots);
export const kickAt = (t)=>{
    let a = 0;
    for (const [t0, g] of KICKS){
        const n = Math.floor((t - t0) * FPS + 1e-6);
        if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
    }
    return a;
};
export const FOV_SCALE = 1.35;
const FOV_MAX = 78;
const shake = (id, f)=>id === 26 || id === 27 || id === 28 ? [
        Math.sin(f * 2.9) * 0.0035,
        Math.sin(f * 3.7 + 1) * 0.0035,
        0
    ] : [
        0,
        0,
        0
    ];
export const camAt = (id, f)=>{
    const c0 = run(CAMS[id], f), a = kickAt(f / FPS);
    const c = {
        ...c0,
        fov: Math.min(FOV_MAX, c0.fov * FOV_SCALE)
    };
    const sk = shake(id, f);
    const look = [
        c.look[0] + sk[0],
        c.look[1] + sk[1],
        c.look[2] + sk[2]
    ];
    if (!a) return {
        ...c,
        look
    };
    const d = [
        look[0] - c.pos[0],
        look[1] - c.pos[1],
        look[2] - c.pos[2]
    ];
    const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
    const m = 3 / 640 * Math.tan(c.fov * Math.PI / 360) * L * a;
    return {
        ...c,
        look: [
            look[0] - d[2] / h * m,
            look[1] + 0.6 * m,
            look[2] + d[0] / h * m
        ],
        roll: c.roll + a * 0.004
    };
};
export const DOF = dofFrom(R.shots, BRIEFS).filter((d)=>!SHOTS.some((s)=>HAND[s.id] && d.f >= s.a && d.f < s.b));
for (const s of SHOTS)if (HAND[s.id]) DOF.push({
    f: s.a,
    cInf: HAND[s.id][5] ?? 0
});
DOF.sort((a, b)=>a.f - b.f);
if (!DOF.length || DOF[0].f > 0) DOF.unshift({
    f: 0,
    cInf: 0
});
export const dofAt = (f)=>{
    let i = 0;
    while(i + 1 < DOF.length && f >= DOF[i + 1].f)i++;
    const d = DOF[i], p = DOF[Math.max(0, i - 1)];
    const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
    return {
        cInf: p.cInf + (d.cInf - p.cInf) * k,
        focus: d.focus
    };
};
export const FOREGROUND = [];
