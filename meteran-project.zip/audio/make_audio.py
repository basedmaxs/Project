# Sound of "Meteran": original, synthesized in numpy/scipy (dsp.py / instruments.py / sfx_gen.py).
# voice (gain only) + dark ambient score (ducked under speech) + sound effects on the frames of the picture -> mix_final.wav
# (-15 LUFS integrated, <= -1.2 dBTP, 48 kHz stereo 24-bit, exact length). Uses mix.py's loader / ducking / limiter / meters.
import os, json, sys
import numpy as np
from dsp import SR, ns, tt, st, dbg, rng, lp, hp, bp, colored, smooth_noise, place, pan, write_wav, integrated, true_peak, fades, make_ir, convolve_st, modal, momentary
from instruments import musicbox, timpani, pad
from sfx_gen import crickets, breeze
import timeline as T
import mix as M

N = ns(T.DUR)
ROOT = M.ROOT
r = rng(2026)
TAU = 2 * np.pi
HAS = lambda t: min(max(int(t * SR), 0), N)


def noise_burst(dur, lo, hi, decay, gain=1.0, seed=1):
    x = bp(rng(seed).standard_normal(ns(dur)), lo, hi, 2) * np.exp(-tt(dur) / decay)
    return x * gain


def tone_hum(dur, f0, harm=(1, 2, 3, 4, 6), amps=(1, .6, .35, .25, .12), wob=0.0):
    t = tt(dur)
    y = np.zeros(len(t))
    for h, a in zip(harm, amps):
        y += a * np.sin(TAU * f0 * h * t + (wob * np.sin(TAU * 0.3 * t) if wob else 0))
    return y / sum(amps)


def env_window(t0, t1, fin=0.5, fout=0.5):
    e = np.zeros(N); a, b = HAS(t0), HAS(t1)
    if b <= a: return e
    e[a:b] = 1.0
    fi, fo = max(1, ns(fin)), max(1, ns(fout))
    e[a:min(b, a + fi)] *= np.linspace(0, 1, min(b, a + fi) - a)
    e[max(a, b - fo):b] *= np.linspace(1, 0, b - max(a, b - fo))
    return e


# ====================================================================== SFX
def build_sfx():
    S = np.zeros((2, N))
    cues = []
    def cue(t, what, g=1.0):
        cues.append((round(t, 2), what, g))

    # ---- room tone + night: low air, far crickets (rooms), corridor bulb buzz ----
    room = (lp(colored(N, r, 1.0), 220, 2) * 0.5 + 0.1 * bp(colored(N, r, 0.3), 800, 3000, 1)) * (0.25 + 0.1 * smooth_noise(N, r, 0.2))
    inroom = np.zeros(N)
    for i in range(1, 31):
        a, b = T.shot_t(i)
        if T.PLACE[i] != "hall": inroom[HAS(a):HAS(b)] = 1
    hall = 1 - inroom
    S += st(room) * 0.55
    cr = crickets(T.DUR, r, voices=4); S += pan(lp(cr, 5200, 2) * 0.030 * (0.35 + 0.65 * inroom), -0.35)
    buzz = tone_hum(T.DUR, 120, (1, 2, 3), (1, .5, .25)) * 0.020 * hall; S += st(buzz)
    cue(0, "bed: night room tone + far crickets, corridor bulb buzz (120 Hz) in the corridor")

    # ---- the meter: motor whirr that follows the disc speed, a tick on every revolution ----
    rate = np.array([T.rate(i / SR) for i in range(0, N, 480)])
    rt = np.interp(np.arange(N) / SR, np.arange(0, N, 480) / SR, rate)
    gain_meter = np.zeros(N)
    for i in range(1, 31):
        a, b = T.shot_t(i)
        near = i in (2, 7, 13, 14, 17, 20)
        gain_meter[HAS(a):HAS(b)] = 1.0 if near else (0.28 if T.PLACE[i] == "a" else 0.0)
    gain_meter = np.convolve(gain_meter, np.ones(2400) / 2400, mode="same")
    ph = np.cumsum(rt) / SR
    f = 95 + 70 * rt
    whirr = np.sin(TAU * np.cumsum(f) / SR) * 0.5 + 0.3 * np.sin(TAU * np.cumsum(2 * f) / SR) + 0.5 * bp(colored(N, r, 0.2), 500, 2400, 1) * (rt > 0.01)
    S += pan(whirr * np.minimum(rt, 4) / 4 * gain_meter * 0.20, 0.25)
    k = 1
    while True:                                           # tick per revolution
        tk = np.searchsorted(ph, k)
        if tk >= N: break
        t_ = tk / SR
        gi = gain_meter[tk]
        if gi > 0.05: place(S, noise_burst(0.03, 1500, 5000, 0.006, 0.5, seed=k % 50), t_, 0.22 * gi)
        k += 1
    cue(1.85, "meter motor whirr (pitch follows the disc speed 0 .. 4 rev/s), tick per revolution; loud in meter shots, quiet from across the room")

    # ---- LED blips ----
    for t_ in T.led_blinks():
        shot = T.shot_at(t_)
        g = 0.5 if shot in (13, 14, 17, 20) else 0.14 if T.PLACE[shot] == "a" else 0.0
        if g: place(S, np.sin(TAU * 2600 * tt(0.014)) * np.exp(-tt(0.014) / 0.004), t_, g * 0.45)
    cue(29.9, "LED blip (2.6 kHz, 14 ms) on every red flash, 29.9-41.2 and 50.2-71.7")

    # ---- clock ticks (shot 11) and a deep midnight note ----
    for k in range(int(23.79), 26):
        a = 23.8 + (k - 23) * 1.0
        if 23.79 <= a < 25.73:
            place(S, noise_burst(0.05, 900, 3500, 0.01, 1.0, seed=k) + 0.5 * np.sin(TAU * 1700 * tt(0.05)) * np.exp(-tt(0.05) / 0.008), a, 0.35)
    place(S, modal(2.6, [(98.0, 1.0, 1.6), (196.0, 0.4, 1.1), (294.0, 0.2, 0.8)], r) * 0.5, 23.85, 0.5)
    cue(23.85, "clock ticks 1/s + low bell at 'tengah malam' (G2)")

    # ---- door latch click (25.74) + shadow steps ----
    place(S, noise_burst(0.02, 1800, 7000, 0.003, 1.2, seed=3), 25.74, 0.55)
    place(S, modal(0.25, [(1900, 1, 0.05), (3100, .5, 0.03)], r), 25.74, 0.33)
    place(S, noise_burst(0.3, 300, 1400, 0.1, 0.5, seed=4), 26.05, 0.18)
    for t_, s_ in ((25.2, 5), (25.55, 6)):
        place(S, lp(rng(s_).standard_normal(ns(0.12)), 260, 2) * np.exp(-tt(0.12) / 0.03), t_, 0.5)
    cue(25.74, "door latch click, a slow scrape, two soft steps behind the door")

    # ---- breathing: pretending to sleep (16.3-23), 'napas teratur' (47-50) ----
    def breaths(t0, t1, period):
        t_ = t0
        while t_ + period < t1:
            d = period * 0.9
            e = np.sin(np.pi * np.linspace(0, 1, ns(d))) ** 1.6
            b_ = bp(rng(int(t_ * 10)).standard_normal(ns(d)), 350, 1800, 2) * e
            place(S, st(b_) * 0.8, t_, 0.10)
            t_ += period
    breaths(16.5, 23.5, 3.4); breaths(47.2, 50.1, 3.0)
    cue(16.5, "slow breathing (3.4 s), again 47.2-50.1")

    # ---- heartbeat while holding the breath (33.1-38.5) and when he rises ----
    t_ = 33.2
    while t_ < 38.4:
        bpm = 66 + 50 * (t_ - 33.2) / 5.2
        for dt, a in ((0, 1.0), (0.17, 0.7)):
            place(S, lp(rng(7).standard_normal(ns(0.2)), 90, 2) * np.exp(-tt(0.2) / 0.05) + 0.9 * np.sin(TAU * 52 * tt(0.2)) * np.exp(-tt(0.2) / 0.07), t_ + dt, 0.9 * a)
        t_ += 60 / bpm
    cue(33.2, "heartbeat 66 -> 116 bpm, ends when the meter slows")

    # ---- the meter slows (38.5) and the room goes silent: a soft downward sweep ----
    sw = np.sin(TAU * np.cumsum(np.linspace(520, 70, ns(2.2))) / SR) * np.hanning(ns(2.2)) * 0.5
    place(S, sw, 38.5, 0.18)
    cue(38.5, "winding-down sweep as the disc slows")

    # ---- power drain (52.75 - 55.2): rising rumble + electric crackle + descending pull ----
    t = tt(2.5)
    pull = np.sin(TAU * np.cumsum(np.linspace(900, 55, len(t))) / SR) * np.sin(np.pi * np.linspace(0, 1, len(t))) ** 1.5
    crack = bp(rng(11).standard_normal(len(t)), 2000, 7000, 2) * (rng(12).random(len(t)) > 0.985) * 6
    place(S, pan(pull * 0.5 + lp(crack, 6500, 1) * 0.35, 0), 52.8, 0.28)
    place(S, st(lp(colored(len(t), r, 1.0), 120, 2) * np.linspace(0.1, 1, len(t))), 52.8, 0.45)
    cue(52.8, "'menyedot daya': descending pull 900 -> 55 Hz, crackle, rising rumble")

    # ---- rise from bed (55.7), footsteps, wardrobe creak ----
    place(S, st(bp(rng(21).standard_normal(ns(1.0)), 700, 3500, 2) * np.hanning(ns(1.0))), 55.7, 0.12)
    for t_ in (57.0, 57.42, 57.85, 63.9, 64.3, 68.5):
        place(S, lp(rng(int(t_ * 7)).standard_normal(ns(0.14)), 240, 2) * np.exp(-tt(0.14) / 0.035) * 1.3, t_, 0.5)
    place(S, modal(0.9, [(310, 1, 0.5), (470, .5, 0.3), (700, .3, 0.2)], r, glide=-0.3, glide_tau=0.4) * 0.25, 58.6, 0.35)
    cue(57.0, "soft footsteps, wardrobe creak 58.6, rustle when he sits up 55.7")

    # ---- 'Kosong': dead-air thud + dust; hot wall: warm swell (63-66) ----
    place(S, st(lp(colored(ns(3.0), r, 1.0), 300, 2) * np.hanning(ns(3.0))), 63.1, 0.35)
    # ---- vibration and machine hum: grows 64.9 -> 71.7 -> full in the machine room, muffled in shots 26-27 ----
    hum = tone_hum(T.DUR, 50, (1, 2, 3, 4, 5, 6, 8), (1, .7, .5, .35, .25, .2, .12), wob=0.8)
    hum_env = env_window(64.9, 80.7, 3.0, 1.0) * (0.3 + 0.7 * np.clip((np.arange(N) / SR - 64.9) / 8, 0, 1))
    m_in = np.zeros(N)
    for i in range(1, 31):
        a, b = T.shot_t(i); m_in[HAS(a):HAS(b)] = {26: 0.6, 27: 0.9, 28: 1.0}.get(i, 0.5 if i in (25,) else (0.45 if T.PLACE[i] == "hall" and i >= 29 else 0.25))
    m_in = np.convolve(m_in, np.ones(4800) / 4800, mode="same")
    S += st(hum * hum_env * m_in * 0.55)
    fan = bp(colored(N, r, 0.4), 250, 1800, 1) * env_window(69.0, 75.6, 2.0, 1.0) * (1.0)
    fan_gain = np.zeros(N); a, b = T.shot_t(28); fan_gain[HAS(a):HAS(b)] = 1.0; fan_gain = np.convolve(fan_gain, np.ones(2400) / 2400, mode="same")
    S += pan(fan * fan_gain * 0.18, 0.3) + pan(fan * fan_gain * 0.12, -0.3)
    # rumble + glass tick (shot 26)
    rum = lp(colored(N, r, 1.5), 90, 2) * env_window(66.1, 69.0, 0.6, 0.4) * 1.2
    S += st(rum * 0.5)
    for k in range(int(66.5 * 2.4), int(69.0 * 2.4)):
        t_ = k / 2.4
        if 66.1 <= t_ < 69.0: place(S, np.sin(TAU * 2200 * tt(0.01)) * np.exp(-tt(0.01) / 0.003), t_, 0.12)
    cue(64.9, "machine hum 50 Hz + harmonics grows to full volume in the machine room; vibration rumble + glass ticks 66-69; fan air 69-75.6")

    # ---- padlock (79.2): metal clink + rattle; a final low hit on 'digembok' ----
    for dt, f in ((0.0, 2400), (0.07, 3400), (0.15, 2900), (0.5, 2600)):
        place(S, modal(0.5, [(f, 1.0, 0.12), (f * 2.4, 0.4, 0.06)], r) * 0.5, 79.25 + dt, 0.35)
    place(S, noise_burst(0.5, 900, 6000, 0.08, 0.6, seed=9), 79.3, 0.25)
    place(S, timpani(41.2, 0.9, r, 3.0), 78.78, 0.7)
    cue(78.78, "final low hit (E1) on 'Pintunya digembok'; padlock clink + rattle 79.25")
    return S, cues


# ====================================================================== MUSIC
def build_music():
    Mx = np.zeros((2, N))
    notes = {"D": 73.42, "A": 110.0, "F": 87.31, "E": 82.41, "Bb": 116.54, "C#": 69.30}
    # drone chords per section: (t0, t1, [freqs], vel)
    chords = [(0, 4.7, [73.42, 110.0], 0.45), (4.7, 16.3, [73.42, 87.31, 110.0], 0.40), (16.3, 26.9, [73.42, 110.0], 0.38), (26.9, 38.5, [73.42, 116.54, 174.6], 0.55),
              (38.5, 47.0, [73.42], 0.22), (47.0, 55.2, [73.42, 87.31, 138.6], 0.5), (55.2, 71.7, [73.42, 116.54, 146.8, 207.7], 0.55), (71.7, 75.6, [36.7, 73.42, 110.0, 146.8], 0.6),
              (75.6, 78.7, [73.42, 87.31], 0.4)]
    for t0, t1, fr, vel in chords:
        p = pad(fr, t1 - t0 - 1.0, vel, rng(int(t0 * 3)), att=1.6, rel=1.6, warm=520)
        place(Mx, p, t0, 0.9)
    # sparse music-box tune in the first half (a lullaby that is slightly wrong)
    tune = [(5.2, 587.3), (7.1, 698.5), (9.6, 659.3), (12.0, 554.4), (13.6, 587.3), (16.8, 440.0), (18.9, 523.3), (21.0, 466.2), (22.4, 440.0)]
    for t_, f in tune: place(Mx, pan(musicbox(f, 0.5, r, 2.4), -0.3 if f > 500 else 0.3), t_, 0.55)
    # tension pulse locked to the LED blink (3 Hz) while the meter runs, 4 Hz when it returns
    for t_ in T.led_blinks():
        if 29.9 <= t_ < 38.4 or 50.19 <= t_ < 71.0:
            g = 0.5 + 0.5 * min(1.0, (t_ - 29.9) / 8) if t_ < 40 else 0.6 + 0.4 * min(1.0, (t_ - 50.19) / 15)
            place(Mx, timpani(55.0, 0.4 * g, r, 0.5), t_, 0.5)
    # riser into the reveal and a swell on the last line
    t = tt(2.2); ris = bp(colored(len(t), r, 0.5), 400, 3000, 2) * np.linspace(0, 1, len(t)) ** 2
    place(Mx, st(ris) * 0.35, 69.0, 0.8)
    # music dead when the picture is dead: 38.5-47.0 nearly nothing (only the soft drone), and the last word
    gate = np.ones(N)
    gate[HAS(38.5):HAS(47.0)] *= 0.35
    gate[HAS(78.77):] *= 0.0
    fin = HAS(78.9); gate[HAS(78.4):HAS(78.77)] *= np.linspace(1, 0.2, HAS(78.77) - HAS(78.4))
    return Mx * gate[None, :]


# ====================================================================== MIX
def main():
    words = T.words(os.path.join(ROOT, "work", "words.json"))
    spans = M.speech_spans(words)
    v = M.load_voice()
    v_ref = integrated(v)
    print("voice", round(v_ref, 2), "LUFS")
    S, cues = build_sfx()
    Mx = build_music()
    # room-ish reverb on the music so it sits behind the voice
    ir = make_ir(2.2, 5, hf=0.5)
    Mx = 0.7 * Mx + 0.3 * convolve_st(Mx, ir)[:, :N]
    dk = M.duck_db(spans)
    Md = Mx * dbg(dk)[None, :]
    # music level relative to the voice: -11.5 LU overall, tension sections 1.5 LU louder, quiet part softer
    lv = M.lufs(v); lm = M.lufs(Md)
    Md *= dbg(lv - 11.5 - lm)
    Sg = S * dbg(lv - 10.0 - M.lufs(S))                   # sfx bed around -10 LU under the voice (events ride above it)
    end = ns(T.DUR - 0.03)
    Md[:, end:] *= np.linspace(1, 0, N - end)[None, :]
    mix0 = v + Md + Sg
    G = M.TARGET_LUFS - M.lufs(mix0)
    for it in range(5):
        y, g3 = M.limiter(mix0 * dbg(G))
        L = M.lufs(y); print(f"master iter {it}: gain {G:+.2f} dB -> {L:.2f} LUFS, TP {true_peak(y):.2f} dBTP")
        if abs(L - M.TARGET_LUFS) < 0.02: break
        G += M.TARGET_LUFS - L
    y = fades(y, 0.0, 0.03)
    assert y.shape == (2, N)
    write_wav(os.path.join(ROOT, "mix_final.wav"), y)
    write_wav(os.path.join(M.HERE, "stem_voice.wav"), v * dbg(G)); write_wav(os.path.join(M.HERE, "stem_music.wav"), Md * dbg(G)); write_wav(os.path.join(M.HERE, "stem_sfx.wav"), Sg * dbg(G))
    # report: speech margin
    gv, gb = v * dbg(G), (Md + Sg) * dbg(G)
    Mv, Mb = momentary(gv), momentary(gb); tc = np.arange(len(Mv)) * 0.01 + 0.2
    speak = np.zeros(len(tc), bool)
    for w in words: speak |= (tc >= float(w["s"]) + 0.03) & (tc <= float(w["e"]) - 0.03)
    speak &= Mv > M.lufs(gv) - 10; ok = speak & np.isfinite(Mb) & (Mb > -70)
    marg = Mv[ok] - Mb[ok]
    rep = {"I": round(M.lufs(y), 2), "TP": round(true_peak(y), 2), "voice_I": round(M.lufs(gv), 2), "music_I": round(M.lufs(Md * dbg(G)), 2), "sfx_I": round(M.lufs(Sg * dbg(G)), 2),
           "speech_margin_median": round(float(np.median(marg)), 1), "speech_margin_p10": round(float(np.percentile(marg, 10)), 1), "length_s": round(y.shape[1] / SR, 3)}
    print(json.dumps(rep))
    with open(os.path.join(M.HERE, "cues.md"), "w", encoding="utf-8") as f:
        f.write("# Cue sheet: Meteran\n\n" + json.dumps(rep, indent=1) + "\n\n| t (s) | what |\n|---|---|\n" + "\n".join(f"| {t_} | {w} |" for t_, w, g in cues) + "\n")


if __name__ == "__main__":
    main()
