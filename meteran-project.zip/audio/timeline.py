# Picture timeline of "Meteran" (mirrors src/story.ts): shot starts, the meter's disc speed, LED, etc.
import json
import numpy as np

FPS = 30
TOTAL = 2421
DUR = TOTAL / FPS                       # 80.70 s
STARTS = [0.0, 1.85, 4.77, 7.51, 9.41, 11.41, 14.07, 16.29, 19.61, 21.53, 23.79, 25.73, 26.95, 29.89, 33.11, 36.55, 38.49, 43.39, 47.03, 50.19,
          52.75, 55.21, 57.53, 60.31, 63.07, 66.09, 69.03, 71.71, 75.61, 78.77]
PLACE = {i + 1: ("hall" if i in (0, 28, 29) else "b" if i == 27 else "a") for i in range(30)}


def shot_t(i):
    a = STARTS[i - 1]
    b = STARTS[i] if i < len(STARTS) else DUR
    return a, b


def shot_at(t):
    return max(i for i in range(1, 31) if STARTS[i - 1] <= t)


def smooth(x):
    x = min(1.0, max(0.0, x))
    return x * x * x * (x * (6 * x - 15) + 10)


def rate(t):
    """disc revolutions per second (same function as story.ts)"""
    if 1.85 <= t < 4.77: return 2.6
    if t < 26.95: return 0.0
    if t < 38.49: return 4.0
    if t < 40.9: return 4 - 3.7 * smooth((t - 38.49) / 2.2)
    if t < 49.9: return 0.3
    if t < 50.6: return 0.3 + 3.7 * smooth((t - 49.9) / 0.7)
    return 4.0


def led_blinks():
    """times at which the red LED switches on"""
    out = []
    for a, b, hz in ((29.9, 41.17, 3.0), (50.19, 71.7, 4.0)):
        k = 0
        while a + k / hz < b:
            out.append(a + k / hz); k += 1
    return out


def words(path):
    return json.load(open(path, encoding="utf-8"))
