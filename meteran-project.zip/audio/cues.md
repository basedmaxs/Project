# Cue sheet: Meteran

{
 "I": -15.01,
 "TP": -1.2,
 "voice_I": -14.91,
 "music_I": -26.39,
 "sfx_I": -24.89,
 "speech_margin_median": 8.6,
 "speech_margin_p10": 2.8,
 "length_s": 80.7
}

| t (s) | what |
|---|---|
| 0 | bed: night room tone + far crickets, corridor bulb buzz (120 Hz) in the corridor |
| 1.85 | meter motor whirr (pitch follows the disc speed 0 .. 4 rev/s), tick per revolution; loud in meter shots, quiet from across the room |
| 29.9 | LED blip (2.6 kHz, 14 ms) on every red flash, 29.9-41.2 and 50.2-71.7 |
| 23.85 | clock ticks 1/s + low bell at 'tengah malam' (G2) |
| 25.74 | door latch click, a slow scrape, two soft steps behind the door |
| 16.5 | slow breathing (3.4 s), again 47.2-50.1 |
| 33.2 | heartbeat 66 -> 116 bpm, ends when the meter slows |
| 38.5 | winding-down sweep as the disc slows |
| 52.8 | 'menyedot daya': descending pull 900 -> 55 Hz, crackle, rising rumble |
| 57.0 | soft footsteps, wardrobe creak 58.6, rustle when he sits up 55.7 |
| 64.9 | machine hum 50 Hz + harmonics grows to full volume in the machine room; vibration rumble + glass ticks 66-69; fan air 69-75.6 |
| 78.78 | final low hit (E1) on 'Pintunya digembok'; padlock clink + rattle 79.25 |
