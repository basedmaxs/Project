# Prop text rules (portable, for any video skill)

Use this file in any skill that builds scenes from a script (three.js, canvas, Blender, image/video generators with text overlays). It tells the model how to fill the `text` of in-world props so they are never empty, gibberish or unreadable.

## Scope
- This is **diegetic text**: text that exists inside the scene (signs, papers, chalkboards, screens, price lists, carved stone).
- It is **not** captions or subtitles. If the host skill forbids subtitles, nothing here conflicts with that.

## Flow
1. From the narration (and word timing, if the skill has it), write `storyboard.json` that follows `schema/storyboard.schema.json`. For props only, `schema/proptext.schema.json` is enough.
2. Validate before building anything: `python3 tools/validate_storyboard.py storyboard.json`.
3. The renderer reads the JSON. It never hard-codes story content. For three.js use `engine/proptext.js` (`paintPropText`). For other engines, follow the same fields.

## Rules
1. **A text-bearing prop is never empty.** Types parchment, sign, banner, board, ledger, calculator, screen, map, carved_stone, poster and price_list require `text`. No wavy placeholder lines, no gibberish letters. If an image generator cannot write text, paint the text yourself (canvas/overlay) on a blank prop.
2. **Hierarchy:** big `title` (max 24 chars, about 3 words), 1-4 short `lines` (max 28 chars each), then a `number`, `stamp` or price `rows`.
3. **Derive text from the narration.** Use the key noun, number or phrase spoken at that moment. If the narration gives no wording, invent short in-world wording that fits the story (e.g. "Pardon / One Crime / Next Week").
4. **Style matches the object:** medieval for scrolls and boards, mono + `lcd_green` for calculators and screens, `blue_sign` for road signs, stone for carvings, handwritten for notes.
5. **Readable on a phone (9:16):** short text, large size, camera close when the text is the point. Check contrast against the paper.
6. **Reveal in sync with the voice:** `reveal_frame` is 0-3 frames before the triggering word. `typewriter` for lists, `stamp_slam` for verdicts, `fade` for quiet reveals.
7. **Not mirrored.** Check planar UVs on every text prop.
8. **Language:** write prop text in `storyboard.language`. Make sure the font has the glyphs, and load fonts before painting.

## Checklist before showing the user
- Every text-type prop has `title` plus `lines`, `rows`, `number` or `stamp`.
- No line longer than 28 chars (the schema rejects it).
- Every `reveal_frame` lies inside its shot's `a`..`b`.
- Shot frames are contiguous and the last `b` equals `total_frames - 1`.
- `tools/validate_storyboard.py` passes.
