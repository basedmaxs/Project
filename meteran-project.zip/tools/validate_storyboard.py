#!/usr/bin/env python3
"""Validasi storyboard.json: schema + pemeriksaan tambahan.
Pakai: python3 validate_storyboard.py storyboard.json [schema.json]
Butuh: pip install jsonschema (opsional; tanpa itu hanya pemeriksaan tambahan yang jalan)."""
import json, sys, os

TEXT_TYPES = {"parchment","sign","banner","board","ledger","calculator","screen","map","carved_stone","poster","price_list"}
here = os.path.dirname(os.path.abspath(__file__))
path = sys.argv[1] if len(sys.argv) > 1 else "storyboard.json"
schema_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "..", "schema", "storyboard.schema.json")
data = json.load(open(path, encoding="utf-8"))
errors = []

try:
    import jsonschema
    schema = json.load(open(schema_path, encoding="utf-8"))
    for e in sorted(jsonschema.Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path)):
        errors.append("schema: /" + "/".join(map(str, e.path)) + ": " + e.message)
except ImportError:
    print("(jsonschema tidak terpasang: hanya pemeriksaan tambahan)", file=sys.stderr)

shots = data.get("shots", [])
cast_ids = {c.get("id") for c in data.get("cast", [])}
prev_b = -1
for s in shots:
    sid = s.get("id", "?")
    a, b = s.get("a"), s.get("b")
    if isinstance(a, int) and isinstance(b, int):
        if b < a: errors.append(f"shot {sid}: b < a")
        if a != prev_b + 1: errors.append(f"shot {sid}: mulai di {a}, seharusnya {prev_b + 1} (frame harus berurutan tanpa celah)")
        prev_b = b
    for ch in s.get("characters", []):
        if cast_ids and ch.get("id") not in cast_ids:
            errors.append(f"shot {sid}: karakter '{ch.get('id')}' tidak ada di cast")
        rf = ch.get("react_frame")
        if isinstance(rf, int) and isinstance(a, int) and not (a <= rf <= b):
            errors.append(f"shot {sid}: react_frame {rf} di luar {a}..{b}")
    cb = s.get("camera_brief") or {}
    for k in ("emphasis_frame", "impact_frame"):
        v = cb.get(k)
        if isinstance(v, int) and isinstance(a, int) and isinstance(b, int) and not (a <= v <= b):
            errors.append(f"shot {sid}: camera_brief.{k} {v} di luar {a}..{b}")
    for p in s.get("props", []):
        t = p.get("text")
        if p.get("type") in TEXT_TYPES:
            if not t: errors.append(f"shot {sid}: prop '{p.get('id')}' bertipe {p.get('type')} tanpa text")
            elif not (t.get("lines") or t.get("rows") or t.get("number") or t.get("stamp")):
                errors.append(f"shot {sid}: prop '{p.get('id')}' hanya punya title (tambahkan lines/rows/number/stamp supaya tidak terlihat kosong)")
        if t and isinstance(t.get("reveal_frame"), int) and isinstance(a, int) and not (a <= t["reveal_frame"] <= b):
            errors.append(f"shot {sid}: reveal_frame prop '{p.get('id')}' di luar {a}..{b}")
total = data.get("total_frames")
if shots and isinstance(total, int) and prev_b != total - 1:
    errors.append(f"frame terakhir {prev_b} tidak sama dengan total_frames-1 ({total - 1})")

if errors:
    print("GAGAL:"); [print(" -", e) for e in errors]; sys.exit(1)
print("OK: storyboard valid")
