# Picture timeline of "Benang Merah (Wanasari)" mirrored (read-only) from src/story.ts + src/cast.ts so every sound lands on
# its frame: shots, the word-timed thread events, footsteps of Laras, the dead stop of the music before "memerlukanmu".
import json
import numpy as np

FPS = 30
TOTAL = 2506
DUR = TOTAL / FPS            # 83.533 s
fr = lambda f: f / FPS

# id: (first frame, end frame, light)
SHOTS = {
    1: (0, 75, "day"), 2: (75, 225, "day"), 3: (225, 310, "day"), 4: (310, 436, "day"), 5: (436, 690, "day"), 6: (690, 744, "day"),
    7: (744, 1010, "day"), 8: (1010, 1294, "day"), 9: (1294, 1419, "day"), 10: (1419, 1853, "day"), 11: (1853, 2151, "day"),
    12: (2151, 2336, "golden"), 13: (2336, TOTAL, "golden"),
}
XFADE = {12: 8}


def shot_t(i):
    a, b = SHOTS[i][:2]
    return fr(a), fr(b)


# key events (frames from story.ts / cast.ts; word onsets from work/words.json)
THREAD_ON = [147, 911, 1090, 1118, 1150]          # a red thread grows on a helper's wrist
THREAD_ALL = [1225, 1240, 1255]                   # "benang selalu tumbuh di tangan penolong"
THREAD_OFF = 276                                  # "dibalas": the thread vanishes
THREAD_WRAP = (2171, 2240)                        # Laras winds the sewing thread round her own wrist
BOWS = (575, 613)                                 # folks bow to Laras, then drift away (640-690)
LEDGER = [1440, 1529]                             # ledger opens / page shown
LEDGER_FILL = (1581, 1630)                        # threads fill the list ("bertangan penuh benang")
STING = 2092                                      # "...pernah memerlukanmu": music dead stop begins before it
POINTER = [1312, 1324, 1338]                      # teacher's pointer taps the blackboard
CHILD_POINT = 2415
MOTHER_PULL = 2460
END_THUD = 2487
HARD = [69.0, 71.45]                              # music switches kept hard (dead stop in, golden theme in)


def words(path):
    return json.load(open(path, encoding="utf-8"))
