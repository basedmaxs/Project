# Original score for "Benang Merah (Wanasari)", composed and synthesized here (A minor / pentatonic, 84 bpm, quarter = 0.714 s).
# Theme "the thread": A C E D C ... (rising, then settling) on music box / vibes. It returns in every mood of the story:
# curious plucks over the hook, a lonely music box for Laras, a ticking pulse for the tests, a dry school jingle, a swelling
# climb to the twist, a DEAD STOP before "...memerlukanmu", then the theme again in C major (warm, golden hour) and a last
# unresolved note on the final pull-away.
import numpy as np
from dsp import SR, ns, rng, pan, place, fades, dbg, make_ir, convolve_st, integrated, lp, hp
import instruments as I
import timeline as T

N = ns(T.DUR)
BPM = 84.0
Q = 60.0 / BPM
BAR = 4 * Q
F = I.m2f

DEAD = (69.0, 71.45)      # picture: the realisation lands, then "Sore itu" in golden light

SECTIONS = [
    ("hook", 0.0, 10.33), ("bare", 10.33, 23.0), ("proud", 23.0, 24.8), ("pasar", 24.8, 33.7), ("tests", 33.7, 43.1),
    ("school", 43.1, 47.3), ("office", 47.3, 61.8), ("realize", 61.8, DEAD[0]), ("dropout", DEAD[0], DEAD[1]),
    ("golden", DEAD[1], 80.6), ("outro", 80.6, T.DUR),
]

CH = {  # chord -> (bass midi, voicing)
    "Am": (45, [57, 60, 64, 67]), "F": (41, [53, 57, 60, 64]), "C": (48, [55, 60, 64, 67]), "G": (43, [55, 59, 62, 67]),
    "Dm": (50, [53, 57, 62, 65]), "Em": (40, [55, 59, 64, 67]),
}
PROG = ["Am", "F", "C", "G"]

# theme (beat offset, length in beats, midi): two phrases
THEME = [(0, 1, 69), (1, 1, 72), (2, 1, 76), (3, 2, 74), (5, 1, 72), (6, 2, 69),
         (8, 1, 67), (9, 1, 69), (10, 1, 72), (11, 2, 71), (13, 1, 69), (14, 2, 64)]
THEME_MAJ = [(0, 1, 72), (1, 1, 76), (2, 1, 79), (3, 2, 77), (5, 1, 76), (6, 2, 72),
             (8, 1, 71), (9, 1, 72), (10, 1, 76), (11, 2, 74), (13, 1, 72), (14, 3, 67)]


class Band:
    def __init__(self):
        self.tr, self.send, self.cues = {}, {}, []

    def track(self, name, send):
        if name not in self.tr:
            self.tr[name] = np.zeros((2, N))
            self.send[name] = send
        return self.tr[name]

    def add(self, name, x, t, p=0.0, g=1.0, send=0.15):
        buf = self.track(name, send)
        if t < 0 or t >= T.DUR:
            return
        place(buf, pan(x, p) if np.ndim(x) == 1 else x, t, g)


R = rng(2611)


def _r():
    return rng(int(R.integers(1 << 30)))


def musicbox_line(b, line, t0, vel, shift=0, p=0.1, fn="musicbox", tmax=1e9):
    for (bt, ln, m) in line:
        t = t0 + bt * Q
        if t >= tmax:
            continue
        m += shift
        if fn == "musicbox":
            x = I.musicbox(F(m + 12), vel * R.uniform(0.92, 1.05), _r())
        elif fn == "vibes":
            x = I.vibes(F(m), vel * R.uniform(0.92, 1.05), _r(), dur=max(1.2, ln * Q + 0.8), damp=ln * Q + 0.35)
        else:
            x = I.glock(F(m + 12), vel * R.uniform(0.9, 1.0), _r())
        b.add(fn, x, t, p)


def padchord(b, name, t, dur, vel, att=0.7, rel=1.0, warm=900.0):
    bass, v = CH[name]
    b.add("pad", I.pad([F(m) for m in v] + [F(bass)], dur, vel, _r(), att=att, rel=rel, warm=warm), t, 0.0)


def pluck_arp(b, name, t0, bars, vel, step=0.5, pattern=(0, 1, 2, 3, 2, 1), octave=0, tmax=1e9, tmin=0.0):
    bass, v = CH[name]
    n = int(bars * 4 / step)
    for k in range(n):
        t = t0 + k * step * Q
        if t >= tmax or t < tmin:
            continue
        m = v[pattern[k % len(pattern)] % len(v)] + octave
        b.add("pluck", I.pluck(F(m + 12), vel * R.uniform(0.85, 1.05), _r(), dur=0.7), t, 0.25 * np.sin(k * 1.3))


def pulse(b, t0, t1, step, vel):
    t = t0
    k = 0
    while t < t1:
        b.add("triangle", I.triangle(vel * (1.0 if k % 4 == 0 else 0.55), _r(), dur=0.5, f=1900 if k % 4 else 2500), t, 0.4 * (-1) ** k)
        t += step
        k += 1


def shaker(b, t0, t1, step, vel, off=0.0):
    t = t0 + off
    k = 0
    while t < t1:
        b.add("brush", I.brush(vel * (1.0 if k % 2 == 0 else 0.6), _r(), dur=0.3, swish=(k % 4 == 3)), t, 0.2 * (-1) ** k)
        t += step
        k += 1


def build():
    b = Band()
    for name, send in [("musicbox", 0.26), ("vibes", 0.26), ("glock", 0.22), ("pluck", 0.18), ("pad", 0.28), ("brush", 0.10), ("triangle", 0.22)]:
        b.track(name, send)
    note = b.cues.append

    # ============ HOOK 0 - 10.33: curious plucks over Am | F | Am | F, vibes carry the theme, shaker keeps time
    for k, ch in enumerate(["Am", "F", "Am", "F"]):
        pluck_arp(b, ch, k * BAR, 1, 0.55, tmax=DEAD[0])
        padchord(b, ch, k * BAR, BAR + 0.4, 0.28)
    musicbox_line(b, THEME, 0.0, 0.5, 0, 0.0, "vibes", tmax=10.33)
    shaker(b, 0.0, 10.33, Q / 2, 0.30)
    note((0.0, "hook: plucked arpeggio Am|F|Am|F, vibes play the thread theme, soft shaker, warm pad"))

    # ============ BARE 10.33 - 23.0: Laras alone: a lone music box and one held pad, long gaps
    t = 10.33
    padchord(b, "Am", t, 5.0, 0.30, att=1.2, rel=1.6)
    for (bt, ln, m) in [(0.6, 1, 69), (2.0, 1, 72), (3.6, 2, 76), (6.0, 1, 74), (8.0, 1, 72)]:
        b.add("musicbox", I.musicbox(F(m + 12), 0.55 * R.uniform(0.92, 1.05), _r()), t + bt * Q, 0.1)
    padchord(b, "F", 15.3, 5.5, 0.30, att=1.2, rel=1.6)
    for (bt, ln, m) in [(0.4, 1, 67), (2.0, 1, 69), (3.4, 2, 72), (6.4, 1, 71)]:
        b.add("musicbox", I.musicbox(F(m + 12), 0.5 * R.uniform(0.92, 1.05), _r()), 15.3 + bt * Q, -0.1)
    # two slow notes while the warung people bow (the "respect" without warmth): hollow fifths
    for tt_, m in [(19.4, 57), (20.8, 64), (22.0, 55)]:
        b.add("vibes", I.vibes(F(m), 0.4, _r(), dur=1.8, damp=1.4), tt_, 0.0)
    note((10.33, "bare: held Am pad, lone music box notes with long gaps; hollow vibes fifths under the bows"))

    # ============ PROUD 23.0 - 24.8: a self-satisfied warm swell
    padchord(b, "F", 23.0, 2.2, 0.34, att=0.5, rel=0.9, warm=1100)
    for k, m in enumerate([69, 72, 76, 81]):
        b.add("glock", I.glock(F(m + 12), 0.45, _r()), 23.2 + k * 0.28, 0.2)
    note((23.0, "proud: F pad swell + a rising glock arpeggio (smug)"))

    # ============ PASAR 24.8 - 33.7: playful staccato plucks, curious
    for k, ch in enumerate(["C", "G", "Am", "F", "C", "G", "Am", "G"]):
        t = 24.8 + k * BAR
        if t < 33.7:
            pluck_arp(b, ch, t, 1, 0.6, step=0.5, pattern=(0, 2, 1, 3, 2, 1), octave=0, tmax=33.7)
            padchord(b, ch, t, BAR + 0.3, 0.24)
    shaker(b, 24.8, 33.7, Q, 0.28, off=Q / 2)
    musicbox_line(b, [(0, 1, 76), (1, 1, 72), (2, 1, 69), (3, 1, 72)], 28.5, 0.45, 0, 0.3, "musicbox")
    note((24.8, "pasar: staccato pluck arpeggios C|G|Am|F, off-beat shaker; a curious music-box question at 28.5"))

    # ============ TESTS 33.7 - 43.1: ticking pulse, rising pad (three tries, same result)
    for k in range(3):
        t = 33.7 + k * 3.15
        padchord(b, ["Am", "Dm", "Em"][k], t, 3.4, 0.26, att=0.4, rel=0.6)
    pulse(b, 33.7, 43.1, Q / 2, 0.36)
    for k, m in enumerate([69, 72, 76]):
        b.add("vibes", I.vibes(F(m + 12), 0.5, _r(), dur=1.4, damp=1.0), 36.1 + k * 3.15, 0.0)
    for k, m in enumerate([76, 79, 81, 84]):
        b.add("glock", I.glock(F(m), 0.4 + 0.08 * k, _r()), 40.4 + k * 0.33, 0.2)
    note((33.7, "tests: pulse on triangle, pad Am|Dm|Em climbing; vibes answer each try; glock run up under 'Benang selalu tumbuh'"))

    # ============ SCHOOL 43.1 - 47.3: dry, flat lesson jingle (muted pluck, no reverb tail feel)
    for k, m in enumerate([67, 67, 69, 67, 72, 71]):
        b.add("pluck", I.pluck(F(m + 12), 0.55, _r(), dur=0.4, bright=0.3), 43.2 + k * Q * 0.75, 0.0)
    for k, m in enumerate([67, 67, 69, 67, 74, 72]):
        b.add("pluck", I.pluck(F(m + 12), 0.5, _r(), dur=0.4, bright=0.3), 45.4 + k * Q * 0.75 if 45.4 + k * Q * 0.75 < 47.3 else 99.0, 0.0)
    note((43.1, "school: dry two-bar chalkboard jingle on muted plucks"))

    # ============ OFFICE 47.3 - 61.8: thoughtful; the thread theme on music box over a slow minor pad; brighter at 59.1
    padchord(b, "Am", 47.3, 6.0, 0.30, att=1.0, rel=1.2)
    padchord(b, "F", 53.0, 6.0, 0.30, att=1.0, rel=1.2)
    musicbox_line(b, THEME[:6], 50.9, 0.5, 0, -0.1, "musicbox")
    musicbox_line(b, THEME[6:], 57.2, 0.5, 0, 0.1, "musicbox", tmax=61.8)
    pulse(b, 55.0, 59.0, Q, 0.22)
    padchord(b, "C", 59.1, 3.2, 0.34, att=0.4, rel=1.0, warm=1200)            # "Mereka tak pernah sendirian": a brighter major chord
    for k, m in enumerate([72, 76, 79, 84]):
        b.add("vibes", I.vibes(F(m), 0.45, _r(), dur=1.4, damp=1.0), 59.2 + k * 0.3, 0.1)
    note((47.3, "office: Am/F pads, the thread theme on music box (50.9, 57.2), soft pulse, C major bloom on 'tak pernah sendirian'"))

    # ============ REALIZE 61.8 - 69.0: the climb. Theme in vibes, pad swell, pulse; cut dead at 69.0
    padchord(b, "Am", 61.8, 3.6, 0.30, att=0.6, rel=0.8)
    padchord(b, "F", 65.4, 3.7, 0.36, att=0.9, rel=0.4)
    musicbox_line(b, [(0, 1, 69), (1, 1, 72), (2, 1, 76), (3, 2, 74), (5, 1, 72)], 62.3, 0.55, 0, 0.0, "vibes")
    pulse(b, 64.0, 69.0, Q / 2, 0.30)
    for k, m in enumerate([57, 60, 64, 67, 69, 72, 76]):
        b.add("glock", I.glock(F(m + 12), 0.35 + 0.07 * k, _r()), 66.0 + k * 0.42, 0.2)
    note((61.8, "realise: Am->F pads swell, theme on vibes, pulse and glock climb; everything stops dead at 69.0 (before 'memerlukanmu')"))

    # ============ GOLDEN 71.45 - 80.6: the theme in C major, warm; Laras's own thread
    padchord(b, "C", 71.45, 4.2, 0.34, att=0.9, rel=1.2, warm=1100)
    padchord(b, "F", 75.65, 4.3, 0.34, att=0.9, rel=1.2, warm=1100)
    musicbox_line(b, THEME_MAJ, 71.9, 0.55, 0, 0.0, "musicbox", tmax=80.6)
    shaker(b, 75.0, 80.6, Q, 0.2, off=Q / 2)
    for k, m in enumerate([67, 72, 76, 79]):
        b.add("vibes", I.vibes(F(m), 0.4, _r(), dur=1.6, damp=1.2), 76.2 + k * 0.5, -0.1)
    note((71.45, "golden: the thread theme in C major on music box, warm C/F pads, light shaker; vibes arpeggio when she walks"))

    # ============ OUTRO 80.6 - end: unresolved. The theme's first two notes, then the third hangs and fades with the pull-away
    padchord(b, "Am", 80.6, 3.2, 0.26, att=0.4, rel=1.4)
    b.add("musicbox", I.musicbox(F(69 + 12), 0.5, _r()), 81.4, 0.0)
    b.add("musicbox", I.musicbox(F(72 + 12), 0.5, _r()), 82.1, 0.0)
    b.add("musicbox", I.musicbox(F(76 + 12), 0.45, _r(), dur=2.4), 82.85, 0.0)
    note((80.6, "outro: Am pad, music box A - C - E (callback of the theme), the E left hanging"))

    # ---- dead stop + end fade
    t = np.arange(N) / SR
    mask = np.ones(N)
    a, e = DEAD
    mask[(t >= a) & (t < e)] = 0.0
    k = ns(0.012)
    ia = ns(a)
    mask[ia - k: ia] = np.linspace(1, 0, k)
    end = np.ones(N)
    ie = ns(T.DUR - 1.2)
    end[ie:] = np.linspace(1, 0, N - ie) ** 1.5
    for key in b.tr:
        b.tr[key] = b.tr[key] * mask[None, :] * end[None, :]
    return b


TARGET = {"musicbox": -1.5, "vibes": -2.0, "glock": -6.0, "pluck": -4.0, "pad": -3.5, "brush": -13.0, "triangle": -13.0}


def render(b, ref=-20.0):
    hall = make_ir(1.5, 7, pre=0.018, hf=1.4)
    dry = np.zeros((2, N))
    wet = np.zeros((2, N))
    levels = {}
    for k, x in b.tr.items():
        if not np.any(x):
            continue
        L = integrated(x)
        g = dbg(ref + TARGET.get(k, -6) - L)
        levels[k] = (round(L, 1), round(ref + TARGET.get(k, -6), 1))
        x = x * g
        b.tr[k] = x
        dry += x
        wet += b.send[k] * x
    out = dry + 0.8 * convolve_st(wet.mean(0), hall)
    out = hp(out, 30, 2)
    return out, levels
