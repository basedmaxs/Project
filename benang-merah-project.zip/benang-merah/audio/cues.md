# The Bridge That Fell for a Song - soundtrack cue sheet

All sound is original: synthesized in numpy/scipy by `sfx_gen.py` / `instruments.py`, placed by `sfx.py` / `music.py`, mixed by `mix.py`.
Voice = `voice/voice.wav`, gain only (no EQ, no compression, no pitch).

## Files
| file | content |
|---|---|
| `mix.wav` | final mix, 48 kHz, stereo, 24-bit, 3,240,000 samples = 67.500 s |
| `stem_voice.wav` / `stem_music.wav` / `stem_sfx.wav` | stems at mix gain (they sum to the mix before the master limiter) |

## Master loudness (own BS.1770-4 meter)
- Integrated **-15.0 LUFS**, true peak **-1.2 dBTP**, LRA 3.4 LU, max momentary -9.0 LUFS, max short-term -11.9 LUFS
- Stems: voice -14.3 LUFS, music -25.3 LUFS, sfx -39.3 LUFS (voice gain +19.67 dB, same gain on every stem)
- Master limiter (4x oversampled look-ahead, ceiling -1.2 dBTP): max gain reduction 5.23 dB, active (>0.1 dB) on 28.12 % of samples, >0.5 dB on 14.14 %

ffmpeg ebur128 cross-check:
```
Summary:
  Integrated loudness:
    I:         -15.0 LUFS
    Threshold: -25.3 LUFS
  Loudness range:
    LRA:         3.4 LU
    Threshold: -35.3 LUFS
    LRA low:   -16.8 LUFS
    LRA high:  -13.4 LUFS
  True peak:
    Peak:       -1.2 dBFS
```

## Voice on top: per-section loudness (LUFS, integrated per stem, at mix gain)
bed = music + sfx. margin = voice - bed (integrated over the section). speech median / p10 = median and 10th percentile of the 400 ms momentary margin (voice - bed) over windows centred on spoken words.

| section (shots) | time s | voice | music | sfx | bed | margin LU | speech median LU | speech p10 LU |
|---|---|---|---|---|---|---|---|---|
| hook (1-3) | 0.00-10.33 | -12.5 | -22.6 | -39.8 | -22.5 | 10.1 | 9.6 | 7.1 |
| Laras bare (4) | 10.33-14.53 | -12.2 | -24.2 | -42.6 | -24.2 | 12.0 | 10.8 | 8.2 |
| warung (5-6) | 14.53-24.80 | -14.2 | -25.5 | -41.5 | -25.4 | 11.1 | 10.3 | 7.9 |
| pasar (7) | 24.80-33.67 | -14.8 | -24.8 | -38.1 | -24.6 | 9.8 | 8.7 | 4.3 |
| tests (8) | 33.67-43.13 | -16.4 | -26.9 | -35.7 | -26.4 | 10.0 | 10.0 | 6.4 |
| school (9) | 43.13-47.30 | -14.8 | -27.0 | -44.2 | -26.9 | 12.1 | 11.6 | 7.1 |
| kelurahan (10) | 47.30-61.77 | -14.9 | -26.4 | -40.6 | -26.3 | 11.3 | 12.0 | 7.3 |
| realise (11) | 61.77-71.70 | -14.7 | -25.4 | -40.4 | -25.4 | 10.7 | 12.9 | 7.4 |
| golden (12-13) | 71.70-83.53 | -14.8 | -26.6 | -39.2 | -26.4 | 11.6 | 11.3 | 7.9 |

## Music map (original score: slendro-flavoured music box / vibes theme, 84 bpm)
Music target per section, LU under the voice (after a -3 dB speech duck keyed from words.json): hook -10.0, bare -11.5, proud -11.0, pasar -10.0, tests -10.5, school -12.0, office -11.5, realize -10.5, golden -12.0, outro -11.5. Applied section gains (dB): hook -22.1, bare -22.7, proud -21.0, pasar -22.1, tests -23.4, school -19.3, office -23.6, realize -24.3, golden -26.1, outro -23.0, dropout -24.3.

Rides (music only, dB): 7.90-8.60 s -2.5, 23.00-23.60 s -3.0, 68.30-69.00 s -4.0 - so quiet sentence-final words stay on top and the band blooms in the gaps after them. 

| time s | frame | music |
|---|---|---|
| 0.00 | 0 | hook: plucked arpeggio Am|F|Am|F, vibes play the thread theme, soft shaker, warm pad |
| 10.33 | 310 | bare: held Am pad, lone music box notes with long gaps; hollow vibes fifths under the bows |
| 23.00 | 690 | proud: F pad swell + a rising glock arpeggio (smug) |
| 24.80 | 744 | pasar: staccato pluck arpeggios C|G|Am|F, off-beat shaker; a curious music-box question at 28.5 |
| 33.70 | 1011 | tests: pulse on triangle, pad Am|Dm|Em climbing; vibes answer each try; glock run up under 'Benang selalu tumbuh' |
| 43.10 | 1293 | school: dry two-bar chalkboard jingle on muted plucks |
| 47.30 | 1419 | office: Am/F pads, the thread theme on music box (50.9, 57.2), soft pulse, C major bloom on 'tak pernah sendirian' |
| 61.80 | 1854 | realise: Am->F pads swell, theme on vibes, pulse and glock climb; everything stops dead at 69.0 (before 'memerlukanmu') |
| 71.45 | 2144 | golden: the thread theme in C major on music box, warm C/F pads, light shaker; vibes arpeggio when she walks |
| 80.60 | 2418 | outro: Am pad, music box A - C - E (callback of the theme), the E left hanging |

## SFX events
Level convention: every EVENT has a naive level (LU vs the voice stem, as the event's max momentary loudness); applied = naive - 6 dB (standard mix rule) + distance/intensity offsets. BEDS are integrated loudness, not reduced. 'mix LUFS' = the event's max momentary loudness in the final mix (voice stem = -14.3 LUFS integrated). Column sounds also get the camera-distance low-pass and more valley reverb.

| # | time s | frame | cue | what | naive LU | applied LU | mix LUFS | pan |
|---|---|---|---|---|---|---|---|---|
| 1 | 0.000 | 0.0 | amb_plaza (bed, integrated) | daytime kampung plaza: breeze, sparrows, far-off chatter (shots 1-5) | -29 | -29.0 | -43.3 | +0.00 |
| 2 | 4.850 | 145.5 | thread_on | a red thread grows around a helper's wrist (chime run) | -12 | -18.0 | -32.3 | +0.10 |
| 3 | 9.200 | 276.0 | thread_off | 'dibalas': the thread unwinds and vanishes | -11 | -17.0 | -31.3 | +0.00 |
| 4 | 19.167 | 575.0 | bow_cloth | the folk bow: cloth rustle | -22 | -28.0 | -42.3 | -0.50 |
| 5 | 19.633 | 589.0 | bow_cloth | the folk bow: cloth rustle | -22 | -28.0 | -42.3 | +0.00 |
| 6 | 20.100 | 603.0 | bow_cloth | the folk bow: cloth rustle | -22 | -28.0 | -42.3 | +0.50 |
| 7 | 21.333 | 640.0 | step_away | the folk walk away from Laras | -24 | -30.0 | -44.3 | +0.60 |
| 8 | 21.733 | 652.0 | step_away | the folk walk away from Laras | -24 | -30.0 | -44.3 | -0.60 |
| 9 | 22.133 | 664.0 | step_away | the folk walk away from Laras | -24 | -30.0 | -44.3 | +0.60 |
| 10 | 22.533 | 676.0 | step_away | the folk walk away from Laras | -24 | -30.0 | -44.3 | -0.60 |
| 11 | 22.933 | 688.0 | step_away | the folk walk away from Laras | -24 | -30.0 | -44.3 | +0.60 |
| 12 | 23.000 | 690.0 | amb_pasar (bed, integrated) | pasar lane: crowd murmur, sparrows, breeze (shots 6-8) | -25 | -25.0 | -39.3 | +0.00 |
| 13 | 25.000 | 750.0 | laras_step | Laras walks into the pasar | -23 | -29.0 | -43.3 | -0.10 |
| 14 | 25.467 | 764.0 | laras_step | Laras walks into the pasar | -23 | -29.0 | -43.3 | +0.00 |
| 15 | 25.933 | 778.0 | laras_step | Laras walks into the pasar | -23 | -29.0 | -43.3 | +0.10 |
| 16 | 26.400 | 792.0 | laras_step | Laras walks into the pasar | -23 | -29.0 | -43.3 | -0.10 |
| 17 | 27.533 | 826.0 | seller_step | the seller leads the buyer across the lane | -24 | -30.0 | -44.3 | -0.20 |
| 18 | 28.000 | 840.0 | seller_step | the seller leads the buyer across the lane | -24 | -30.0 | -44.3 | -0.10 |
| 19 | 28.467 | 854.0 | seller_step | the seller leads the buyer across the lane | -24 | -30.0 | -44.3 | +0.00 |
| 20 | 28.933 | 868.0 | seller_step | the seller leads the buyer across the lane | -24 | -30.0 | -44.3 | +0.10 |
| 21 | 29.400 | 882.0 | seller_step | the seller leads the buyer across the lane | -24 | -30.0 | -44.3 | +0.20 |
| 22 | 30.317 | 909.5 | thread_on | a red thread grows around a helper's wrist (chime run) | -12 | -18.0 | -32.3 | +0.10 |
| 23 | 36.283 | 1088.5 | thread_on | test 1: the thread grows on the helper's wrist | -12 | -18.0 | -32.3 | -0.20 |
| 24 | 37.217 | 1116.5 | thread_on | test 2: the thread grows on the helper's wrist | -12 | -18.0 | -32.3 | +0.00 |
| 25 | 38.283 | 1148.5 | thread_on | test 3: the thread grows on the helper's wrist | -12 | -18.0 | -32.3 | +0.20 |
| 26 | 40.833 | 1225.0 | thread_more | 'Benang selalu tumbuh di tangan penolong': another ring on each helper | -14 | -20.0 | -34.3 | -0.50 |
| 27 | 41.333 | 1240.0 | thread_more | 'Benang selalu tumbuh di tangan penolong': another ring on each helper | -14 | -20.0 | -34.3 | +0.00 |
| 28 | 41.833 | 1255.0 | thread_more | 'Benang selalu tumbuh di tangan penolong': another ring on each helper | -14 | -20.0 | -34.3 | +0.50 |
| 29 | 43.100 | 1293.0 | amb_school (bed, integrated) | classroom: soft room tone, a far-off playground (shot 9) | -33 | -33.0 | -47.1 | +0.00 |
| 30 | 43.733 | 1312.0 | pointer | teacher's pointer taps the blackboard | -22 | -28.0 | -42.3 | +0.20 |
| 31 | 44.133 | 1324.0 | pointer | teacher's pointer taps the blackboard | -22 | -28.0 | -42.3 | +0.20 |
| 32 | 44.600 | 1338.0 | pointer | teacher's pointer taps the blackboard | -22 | -28.0 | -42.3 | +0.20 |
| 33 | 47.300 | 1419.0 | amb_office (bed, integrated) | kelurahan office: quiet room tone and a wall clock (shot 10a-b) | -34 | -34.0 | -47.9 | +0.00 |
| 34 | 48.000 | 1440.0 | page | ledger page turn | -22 | -28.0 | -42.3 | +0.00 |
| 35 | 50.967 | 1529.0 | page | ledger page turn | -22 | -28.0 | -42.3 | +0.00 |
| 36 | 52.700 | 1581.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | -0.30 |
| 37 | 52.933 | 1588.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | -0.20 |
| 38 | 53.167 | 1595.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | -0.10 |
| 39 | 53.400 | 1602.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | +0.00 |
| 40 | 53.633 | 1609.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | +0.10 |
| 41 | 53.867 | 1616.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | +0.20 |
| 42 | 54.100 | 1623.0 | ledger_tick | a thread ring appears in the ledger | -22 | -28.0 | -42.3 | +0.30 |
| 43 | 55.000 | 1650.0 | amb_plaza2 (bed, integrated) | plaza again with the busy folk: chatter, laughter, breeze (shots 10c-11) | -26 | -26.0 | -40.3 | +0.00 |
| 44 | 55.000 | 1650.0 | tug | someone tugs a threaded sleeve | -22 | -28.0 | -42.3 | -0.50 |
| 45 | 56.800 | 1704.0 | call | 'dipanggil kapan saja': a far shout | -20 | -26.0 | -40.3 | +0.60 |
| 46 | 59.100 | 1773.0 | laughs | the crowd around the helper: warm laughter and chatter | -20 | -26.0 | -40.3 | +0.00 |
| 47 | 61.767 | 1853.0 | gasp | Laras understands | -22 | -28.0 | -42.3 | +0.00 |
| 48 | 69.833 | 2095.0 | sting | the twist lands: a low hit under 'memerlukanmu' | -16 | -22.0 | -36.3 | +0.00 |
| 49 | 71.450 | 2143.5 | amb_golden (bed, integrated) | golden-hour calm: soft breeze, blackbirds, faint crickets, distant market (shots 12-13) | -29 | -29.0 | -43.2 | +0.00 |
| 50 | 72.367 | 2171.0 | wrap | Laras winds the red sewing thread (soft whoosh, tiny ticks) | -16 | -22.0 | -36.3 | +0.00 |
| 51 | 74.547 | 2236.4 | tie | the thread is tied: a bright chime on her wrist | -11 | -17.0 | -31.3 | +0.20 |
| 52 | 75.200 | 2256.0 | walk_up | Laras walks to the pasar with her arm up | -22 | -28.0 | -42.3 | -0.05 |
| 53 | 75.767 | 2273.0 | walk_up | Laras walks to the pasar with her arm up | -22 | -28.0 | -42.3 | +0.00 |
| 54 | 76.333 | 2290.0 | walk_up | Laras walks to the pasar with her arm up | -22 | -28.0 | -42.3 | +0.05 |
| 55 | 76.900 | 2307.0 | walk_up | Laras walks to the pasar with her arm up | -22 | -28.0 | -42.3 | -0.05 |
| 56 | 77.467 | 2324.0 | walk_up | Laras walks to the pasar with her arm up | -22 | -28.0 | -42.3 | +0.00 |
| 57 | 78.367 | 2351.0 | stares | the pasar goes quiet: low murmur | -24 | -30.0 | -44.3 | +0.00 |
| 58 | 80.450 | 2413.5 | kid_oh | a child's curious 'oh!' | -19 | -25.0 | -39.3 | +0.40 |
| 59 | 82.000 | 2460.0 | pull | the mother pulls the child away: cloth + quick steps | -20 | -26.0 | -40.3 | +0.50 |
| 60 | 82.200 | 2466.0 | pull_step | quick steps away | -23 | -29.0 | -43.3 | +0.60 |
| 61 | 82.467 | 2474.0 | pull_step | quick steps away | -23 | -29.0 | -43.3 | +0.60 |
| 62 | 82.733 | 2482.0 | pull_step | quick steps away | -23 | -29.0 | -43.3 | +0.60 |
| 63 | 82.900 | 2487.0 | end_thud | the last beat: a soft muted thud on the final word | -20 | -26.0 | -40.3 | +0.00 |
