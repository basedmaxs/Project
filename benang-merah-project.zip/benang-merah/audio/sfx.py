# Every sound effect + ambience bed of the Benang Merah short as a cue list timed to the picture (timeline.py), rendered
# into one stereo SFX stem. Levels follow the user's standard mix: each EVENT has a "naive" level (LU relative to the
# voice stem, measured as the event's max momentary loudness) and is placed SFX_DB = -6 dB under it; ambience BEDS
# (integrated loudness) are not reduced. Distance to the camera adds gain, a low-pass and more valley reverb.
import math
import numpy as np
from dsp import (SR, ns, tt, rng, dbg, lp, hp, bp, peq, shelf, pan, st, place, fades, widen, make_ir, convolve_st,
                 momentary_max, integrated, colored, smooth_noise, modal)
import sfx_gen as G
import timeline as T

N = ns(T.DUR)
SFX_DB = -6.0


class Cue:
    def __init__(self, t, name, desc, gen, naive, kind="event", p=0.0, extra=0.0, lpf=None, send=0.12, group=None, cut=None):
        self.t, self.name, self.desc, self.gen, self.naive = t, name, desc, gen, naive
        self.kind, self.p, self.extra, self.lpf, self.send, self.cut = kind, p, extra, lpf, send, cut
        self.group = group or name
        self.applied = naive + (SFX_DB if kind == "event" else 0.0) + extra
        self.measured = None



def cues():
    C = []
    R = rng(2611)
    rr = lambda: rng(int(R.integers(1 << 30)))
    add = C.append

    # ------------------------------------------------ small sound generators for this story
    def shimmer(r, n=6, up=True):
        """the red thread appearing: a rising little chime run (modal bells) + airy sparkle"""
        d = 1.4
        y = np.zeros(ns(d))
        base = r.uniform(1500, 1800)
        for k in range(n):
            f = base * (1.0 + 0.26 * k) if up else base * (2.2 - 0.26 * k)
            b = modal(0.9, [(f, 1.0, 0.18), (f * 2.76, 0.4, 0.09), (f * 5.4, 0.15, 0.04)], r)
            y[ns(k * 0.055): ns(k * 0.055) + len(b)] += (b * (0.85 ** k))[: len(y) - ns(k * 0.055)]
        sp = bp(r.standard_normal(len(y)), 4500, 9000, 1) * np.exp(-tt(d) / 0.25) * 0.05
        return fades(y + sp, 0.0, 0.2)

    def pop_vanish(r):
        """'dibalas': a soft pop and a falling sparkle as the thread unwinds"""
        d = 1.0
        t = tt(d)
        pop = np.exp(-t / 0.03) * np.sin(2 * np.pi * 260 * (1 + 0.6 * np.exp(-t / 0.02)) * t) * 0.9
        return fades(pop * 0.8 + shimmer(r, 5, False)[: len(t)] * 0.6, 0.0, 0.2)

    def page(r):
        d = 0.35
        return G.whoosh(d, r, 0.45, 1200, 6000, 0.6, 0.1, 0.1) * 0.6

    def tick(r):
        return G.clink(r, r.uniform(2400, 3000), 0.1) * 0.6

    def chalk(r):
        return G.hammer_hit(r, 0.28)

    def low_hit(r):
        d = 1.4
        t = tt(d)
        y = np.exp(-t / 0.35) * np.sin(2 * np.pi * 52 * (1 + 0.4 * np.exp(-t / 0.06)) * t) * 1.2
        y += lp(r.standard_normal(len(t)), 300, 2) * np.exp(-t / 0.06) * 0.6
        return fades(widen(y, r, 10, 0.8), 0.0, 0.3)

    def voices(r, kind, base, scale):
        return G.oof(r, kind, base=base, scale=scale)

    # ------------------------------------------------ ambience beds (not reduced by the -6 dB event rule)
    def amb_town(dur, babble=0.4, birds=0.3, seed=1):
        def g():
            r = rng(seed)
            n = ns(dur)
            x = G.breeze(dur, r, 0.9, 0.15, 800)
            x += pan(G.bird_chirps(dur, r, birds, "sparrow") * 0.07, 0.5)
            x += pan(G.bird_chirps(dur, r, birds * 0.7, "sparrow") * 0.05, -0.6)
            x += _murmur(dur, r, 3, False) * babble * 0.18
            return fades(x, 0.4, 0.6), 0.0
        return g
    add(Cue(0.0, "amb_plaza", "daytime kampung plaza: breeze, sparrows, far-off chatter (shots 1-5)", _cut(amb_town(23.2, 0.5, 0.3, 1), 23.2, 0.4, 0.4), -29, "bed", send=0.0))
    add(Cue(23.0, "amb_pasar", "pasar lane: crowd murmur, sparrows, breeze (shots 6-8)", _cut(amb_town(20.2, 2.4, 0.2, 2), 20.2, 0.5, 0.5), -25, "bed", send=0.0))
    def room(dur, seed):
        def g():
            r = rng(seed)
            n = ns(dur)
            x = G.breeze(dur, r, 0.35, 0.08, 500)
            x += st(lp(bp(colored(n, r, 0.8), 120, 900, 1), 700) * 0.18)
            return fades(x, 0.4, 0.5), 0.0
        return g
    add(Cue(43.1, "amb_school", "classroom: soft room tone, a far-off playground (shot 9)", _cut(room(4.4, 3), 4.4, 0.3, 0.3), -33, "bed", send=0.0))
    add(Cue(47.3, "amb_office", "kelurahan office: quiet room tone and a wall clock (shot 10a-b)", _cut(room(11.0, 4), 11.0, 0.3, 0.4), -34, "bed", send=0.0))
    add(Cue(55.0, "amb_plaza2", "plaza again with the busy folk: chatter, laughter, breeze (shots 10c-11)", _cut(amb_town(14.5, 2.2, 0.3, 5), 14.5, 0.3, 0.4), -26, "bed", send=0.0))
    add(Cue(71.45, "amb_golden", "golden-hour calm: soft breeze, blackbirds, faint crickets, distant market (shots 12-13)", _env(lambda: (_golden(12.1, rng(43)), 0.0), 12.1, 0.5, 0.5), -29, "bed", send=0.0))

    # ------------------------------------------------ the red thread
    for f in T.THREAD_ON[:1] + [T.THREAD_ON[1]]:
        add(Cue(f / T.FPS - 0.05, "thread_on", "a red thread grows around a helper's wrist (chime run)", (lambda r=rr(): (shimmer(r), 0.05)), -12, p=0.1, send=0.3))
    for f, p in zip(T.THREAD_ON[2:], (-0.2, 0.0, 0.2)):
        add(Cue(f / T.FPS - 0.05, "thread_on", "test %d: the thread grows on the helper's wrist" % (T.THREAD_ON.index(f) - 1), (lambda r=rr(): (shimmer(r), 0.05)), -12, p=p, send=0.3))
    for f, p in zip(T.THREAD_ALL, (-0.5, 0.0, 0.5)):
        add(Cue(f / T.FPS, "thread_more", "'Benang selalu tumbuh di tangan penolong': another ring on each helper", (lambda r=rr(): (shimmer(r, 5), 0.0)), -14, p=p, send=0.3))
    add(Cue(T.THREAD_OFF / T.FPS, "thread_off", "'dibalas': the thread unwinds and vanishes", (lambda r=rr(): (pop_vanish(r), 0.03)), -11, send=0.3))
    add(Cue(T.THREAD_WRAP[0] / T.FPS, "wrap", "Laras winds the red sewing thread (soft whoosh, tiny ticks)", (lambda r=rr(): (G.whoosh(1.7, r, 0.5, 900, 5200, 0.9, 0.3, 0.1) * 0.5, 0.2)), -16, send=0.1))
    add(Cue(T.THREAD_WRAP[1] / T.FPS - 0.12, "tie", "the thread is tied: a bright chime on her wrist", (lambda r=rr(): (shimmer(r, 4), 0.05)), -11, p=0.2, send=0.3))

    # ------------------------------------------------ people
    for k, tf in enumerate(range(T.BOWS[0], T.BOWS[1], 14)):
        add(Cue(tf / T.FPS, "bow_cloth", "the folk bow: cloth rustle", (lambda r=rr(): (G.whoosh(0.5, r, 0.4, 600, 3000, 0.6, 0.2, 0.1) * 0.5, 0.15)), -22, p=(-0.5, 0.0, 0.5)[k % 3], send=0.05))
    for k, f in enumerate([640, 652, 664, 676, 688]):
        add(Cue(f / T.FPS, "step_away", "the folk walk away from Laras", (lambda r=rr(): (G.stroll_step(r, 0.7), 0.04)), -24, p=-0.6 if k % 2 else 0.6, send=0.1))
    for k, f in enumerate(range(750, 800, 14)):
        add(Cue(f / T.FPS, "laras_step", "Laras walks into the pasar", (lambda r=rr(): (G.stroll_step(r, 0.6), 0.04)), -23, p=0.1 * (k % 3 - 1), send=0.08))
    for k, f in enumerate(range(826, 884, 14)):
        add(Cue(f / T.FPS, "seller_step", "the seller leads the buyer across the lane", (lambda r=rr(): (G.stroll_step(r, 0.7), 0.04)), -24, p=-0.2 + 0.1 * k, send=0.1))
    for k, f in enumerate(T.POINTER):
        add(Cue(f / T.FPS, "pointer", "teacher's pointer taps the blackboard", (lambda r=rr(): (chalk(r), 0.02)), -22, p=0.2, send=0.05))
    for f in T.LEDGER:
        add(Cue(f / T.FPS, "page", "ledger page turn", (lambda r=rr(): (page(r), 0.1)), -22, send=0.05))
    for k in range(7):
        add(Cue((T.LEDGER_FILL[0] + k * 7) / T.FPS, "ledger_tick", "a thread ring appears in the ledger", (lambda r=rr(): (tick(r), 0.0)), -22, p=-0.3 + 0.1 * k, send=0.1))
    # the three scenes of "dicari, ditunggu, dipanggil"
    add(Cue(1650 / 30, "tug", "someone tugs a threaded sleeve", (lambda r=rr(): (G.whoosh(0.4, r, 0.3, 500, 2500, 0.6, 0.2, 0.1) * 0.5, 0.1)), -22, p=-0.5, send=0.05))
    add(Cue(1704 / 30, "call", "'dipanggil kapan saja': a far shout", (lambda r=rr(): (voices(r, "oh", r.uniform(120, 150), 1.0), 0.1)), -20, p=0.6, send=0.35))
    add(Cue(1773 / 30, "laughs", "the crowd around the helper: warm laughter and chatter", (lambda r=rr(): (_murmur(2.5, r, 7, True), 0.2)), -20, send=0.25))
    # realisation
    add(Cue(1853 / 30, "gasp", "Laras understands", (lambda r=rr(): (G.oof(r, "oh", base=r.uniform(190, 230), scale=1.2), 0.1)), -22, p=0.0, send=0.2))
    add(Cue(T.STING / 30 + 0.1, "sting", "the twist lands: a low hit under 'memerlukanmu'", (lambda r=rr(): (low_hit(r), 0.05)), -16, send=0.3))
    for k, f in enumerate(range(2256, 2336, 17)):
        add(Cue(f / T.FPS, "walk_up", "Laras walks to the pasar with her arm up", (lambda r=rr(): (G.stroll_step(r, 0.6), 0.04)), -22, p=0.05 * (k % 3 - 1), send=0.1))
    add(Cue(2351 / 30, "stares", "the pasar goes quiet: low murmur", (lambda r=rr(): (_murmur(3.4, r, 6, False), 0.2)), -24, send=0.3))
    add(Cue(T.CHILD_POINT / 30 - 0.05, "kid_oh", "a child's curious 'oh!'", (lambda r=rr(): (G.oof(r, "oh", base=r.uniform(300, 330), scale=1.35), 0.1)), -19, p=0.4, send=0.2))
    add(Cue(T.MOTHER_PULL / 30, "pull", "the mother pulls the child away: cloth + quick steps", (lambda r=rr(): (G.whoosh(0.5, r, 0.45, 500, 3200, 0.6, 0.2, 0.1) * 0.6, 0.15)), -20, p=0.5, send=0.05))
    for k, f in enumerate([2466, 2474, 2482]):
        add(Cue(f / T.FPS, "pull_step", "quick steps away", (lambda r=rr(): (G.stroll_step(r, 0.5), 0.04)), -23, p=0.6, send=0.1))
    add(Cue(T.END_THUD / 30, "end_thud", "the last beat: a soft muted thud on the final word", (lambda r=rr(): (G.push_thump(r), 0.03)), -20, send=0.3))
    return C


def _cut(gen, dur, fin, fout):
    def g():
        x, a = gen()
        return fades(x, fin, fout), a
    return g


def _env(gen, dur, fin, fout):
    return _cut(gen, dur, fin, fout)


def _golden(dur, r):
    n = ns(dur)
    x = G.breeze(dur, r, 0.7, 0.1, 650)
    x += st(lp(bp(colored(n, r, 0.8), 150, 1400, 1), 1200) * 0.35)
    x += pan(G.bird_chirps(dur, r, 0.35, "blackbird") * 0.06, -0.5)
    x += pan(G.bird_chirps(dur, r, 0.25, "blackbird") * 0.04, 0.6)
    x += widen(G.crickets(dur, r, 3) * 0.008, r, 9, 1.0)
    return x




def _murmur(dur, r, voices, early=False):
    n = ns(dur)
    out = np.zeros((2, n))
    for v in range(voices):
        kind = r.uniform()
        base, scale = ((r.uniform(95, 140), r.uniform(0.95, 1.05)) if kind < 0.45 else
                       (r.uniform(175, 235), r.uniform(1.12, 1.2)) if kind < 0.85 else (r.uniform(260, 330), r.uniform(1.25, 1.35)))
        y = G.babble(dur, r, base, scale, r.uniform(3.6, 4.8), r.uniform(0.55, 0.8), fmax=3400)
        y = lp(y, r.uniform(2200, 3600), 1) * r.uniform(0.3, 1.0)
        out += pan(y, r.uniform(-0.85, 0.85))
    if early:
        for k in range(4):
            h = G.hurrah(r, r.uniform(110, 230), r.uniform(1.0, 1.18))
            place(out, pan(lp(h, 3000, 1) * 0.5, r.uniform(-0.8, 0.8)), r.uniform(0.2, 1.6))
    return fades(out, 0.25, 0.8)




def render(v_ref, on_event=None):
    """v_ref = integrated loudness of the voice stem (stereo). Returns (stereo stem, cue list with measured levels).
    on_event(cue, x, t0) is called with every placed (dry) event, for analysis."""
    C = cues()
    out = np.zeros((2, N))
    send = np.zeros(N)
    for c in C:
        x, anchor = c.gen()
        x = np.asarray(x, float)
        x = pan(x, c.p) if x.ndim == 1 else x
        if c.cut is not None:
            k = ns(c.cut - (c.t - anchor))
            if 0 < k < x.shape[1]:
                x = fades(x[:, :k], 0.0, 0.02)
        tgt = v_ref + c.applied
        cur = momentary_max(x) if c.kind == "event" else integrated(x)
        if np.isfinite(cur):
            x = x * dbg(tgt - cur)
        if c.lpf:
            x = lp(x, c.lpf, 1)
        c.measured = momentary_max(x) - v_ref if c.kind == "event" else integrated(x) - v_ref
        t0 = c.t - anchor
        place(out, x, t0)
        if on_event:
            on_event(c, x, t0)
        if c.send > 0:
            G._place_mono(send, c.send * x.mean(0), t0)
    valley = make_ir(1.1, 77, pre=0.01, hf=1.6, early=[(0.09, 0.45, -0.5), (0.14, 0.3, 0.6), (0.23, 0.2, -0.2)])
    out += 0.55 * convolve_st(send, valley)
    out = hp(out, 25, 2)
    end = ns(T.DUR - 0.12)
    out[:, end:] *= np.linspace(1, 0, N - end)[None, :] ** 2
    return out, C
