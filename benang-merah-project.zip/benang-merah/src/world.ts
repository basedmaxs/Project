// The whole place as one three.js scene: sky, plaza, houses of Wanasari, the warung with Laras's chair, the pasar lane,
// the school room and the kelurahan office, plus the cast. update(id, f, camera) poses everything for shot `id` at frame f
// (pure function of id + f).
import * as THREE from "three";
import { Batch, boxGeo, quad, V, lam, Kit, Ray, prop, setSight } from "./build";
import { house } from "./build";
import { ctex, planksHD, beam, stoneHD, grassHD, cloudHD } from "./paint";
import { LIGHTS, LOOK, LightPreset } from "./lights";
import { TONE, CHAR, twoTone, untone } from "./shade";
import { NOINK } from "./ink";
import { Pool, Actor, Fx, stage } from "./cast";
import { SHOTS, camAt, ShotDef, CHAIR, LANE_X, SCHOOL } from "./story";

// optional CC0 props are not used by this story (all scenery is built from boxes + painted textures)
export const loadKit = async (): Promise<Kit> => ({});

const discTex = () => ctex("sunDisc", 128, 128, (g) => {
  const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
});
const haloTex = () => ctex("sunHalo", 256, 256, (g) => {
  const im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const u = Math.hypot(x - 127.5, y - 127.5) / 128;
    const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
    const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
  }
  g.putImageData(im, 0, 0);
});

/** every lens position of the film looking at its subject: centre, sides and top of frame (houses there are left out) */
const sightLines = (): Ray[] => {
  const out: Ray[] = [];
  for (const s of SHOTS) for (let f = s.a - 8; f < s.b + 8; f += 2) {
    const c = camAt(s.id, Math.max(0, f)), o = V(...c.pos), look = V(...c.look);
    const fw = look.clone().sub(o), len = fw.length();
    fw.normalize();
    const rt = fw.clone().cross(V(0, 1, 0)).normalize(), up = rt.clone().cross(fw);
    const ty = Math.tan((c.fov * Math.PI) / 360), tx = ty * (9 / 16);
    for (const [sx, sy] of [[0, 0], [-0.6, 0], [0.6, 0], [0, 0.6], [0, -0.4]])
      out.push({ o, d: fw.clone().addScaledVector(rt, sx * tx).addScaledVector(up, sy * ty), len, core: sx === 0 && sy === 0 });
  }
  return out;
};

/** horizontal quad facing up at height y covering x0..x1, z0..z1 (z0 < z1) */
function quadUp(x0: number, x1: number, z0: number, z1: number, u: number, v: number, y = 0) {
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([x0, y, z1, x1, y, z1, x1, y, z0, x0, y, z1, x1, y, z0, x0, y, z0], 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute([0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute([0, 0, u, 0, u, v, 0, 0, u, v, 0, v], 2));
  return g;
}

// ---------------- painted pieces ----------------
const stripes = (key: string, a: string, b: string) => ctex(key, 256, 256, (g) => {
  for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? b : a; g.fillRect(i * 32, 0, 32, 256); }
  g.fillStyle = "rgba(0,0,0,0.10)"; g.fillRect(0, 236, 256, 20);
});
const chalkTex = () => ctex("blackboard", 1024, 384, (g) => {
  g.fillStyle = "#2f4a3d"; g.fillRect(0, 0, 1024, 384);
  g.fillStyle = "rgba(255,255,255,0.06)"; for (let i = 0; i < 6; i++) g.fillRect(40 + i * 150, 30 + (i % 3) * 90, 130, 12);
  g.fillStyle = "#f4f1e6"; g.textBaseline = "middle"; g.textAlign = "center";
  g.font = "bold 92px 'Comic Sans MS','Segoe Print',cursive,sans-serif";
  g.fillText("BENANG = UTANG", 512, 96);
  // a little arm with a red ring and an arrow: "the one who owes wears it"
  g.strokeStyle = "#f4f1e6"; g.lineWidth = 12; g.lineCap = "round";
  g.beginPath(); g.moveTo(260, 330); g.lineTo(300, 220); g.stroke();
  g.strokeStyle = "#e0463a"; g.lineWidth = 16; g.beginPath(); g.ellipse(292, 245, 22, 9, -0.25, 0, Math.PI * 2); g.stroke();
  g.strokeStyle = "#f4f1e6"; g.lineWidth = 8; g.beginPath(); g.moveTo(350, 270); g.lineTo(470, 270); g.lineTo(446, 248); g.moveTo(470, 270); g.lineTo(446, 292); g.stroke();
  g.font = "bold 56px 'Comic Sans MS','Segoe Print',cursive,sans-serif"; g.textAlign = "left";
  g.fillText("YANG BERUTANG", 490, 272);
});
const signTex = (key: string, text: string, bg: string, fg: string, w = 768, h = 192, size = 96) => ctex(key, w, h, (g) => {
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.strokeStyle = fg; g.lineWidth = 8; g.strokeRect(10, 10, w - 20, h - 20);
  g.fillStyle = fg; g.textAlign = "center"; g.textBaseline = "middle"; g.font = `bold ${size}px 'Trebuchet MS','Arial Black',sans-serif`;
  g.fillText(text, w / 2, h / 2 + 4);
});
/** unlit painted board (so side sun does not grey the lettering) */
const board = (parent: THREE.Object3D, tex: THREE.Texture, x: number, y: number, z: number, w: number, h: number, yaw = 0) => {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tex, color: 0xe6e6e6 }));
  m.layers.set(NOINK); m.position.set(x, y, z); m.rotation.y = yaw; parent.add(m);
};

export class World {
  root = new THREE.Group();
  private pool = new Pool();
  private actors: Actor[] = [];
  private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden", THREE.Texture[]>;
  private clouds: THREE.Mesh[] = [];
  private frustum = new THREE.Frustum();
  private m4 = new THREE.Matrix4(); private v = new THREE.Vector3(); private sph = new THREE.Sphere();

  constructor(kit: Kit) {
    const R = this.root;
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() },
        c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK);
    R.add(this.sky);
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: discTex(), color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true,
      transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(4096, 4096);
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = { day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)), golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)) };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30;
      m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1);
      m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }

    // ---------------- materials ----------------
    const b = new Batch();
    const M = {
      grass: lam("grassHD", () => ({ map: grassHD() })),
      plaza: lam("plazaHD", () => ({ map: stoneHD("plazaHD", ["#d8c8a8", "#ccba98", "#dfd0b2", "#c3b090"], "#a99478") })),
      dirt: lam("dirtLane", () => ({ color: "#b79f78" })),
      wood: lam("wood", () => ({ map: beam() })),
      floor: lam("planksHD", () => ({ map: planksHD() })),
      plaster: lam("plasterRoom", () => ({ color: "#e6d8b8" })),
      wains: lam("wainscot", () => ({ color: "#7a9a8a" })),
      cloth: lam("clothBack", () => ({ color: "#d8c9a4", side: THREE.DoubleSide })),
      orange: lam("orangeFruit", () => ({ color: "#f08a1c" })),
      banana: lam("bananaFruit", () => ({ color: "#e0c040" })),
      green: lam("greenVeg", () => ({ color: "#5aa83c" })),
      red: lam("redChili", () => ({ color: "#c8382c" })),
      tin: lam("tinRoof", () => ({ color: "#8a97a6", side: THREE.DoubleSide })),
      cushion: lam("cushion", () => ({ color: "#c0453a" })),
      paper: lam("paperBook", () => ({ color: "#f2e9cf" })),
      bolt1: lam("bolt1", () => ({ color: "#3f6fb5" })), bolt2: lam("bolt2", () => ({ color: "#c25a7a" })), bolt3: lam("bolt3", () => ({ color: "#d9a441" })), bolt4: lam("bolt4", () => ({ color: "#2f6a6a" })),
    };
    const awn = (key: string, a: string, c: string) => lam(key, () => ({ map: stripes(key, a, c), side: THREE.DoubleSide }));
    const AW = [awn("awnRed", "#c8382c", "#f3ead2"), awn("awnGreen", "#3f8a4f", "#f3ead2"), awn("awnBlue", "#3f6fb5", "#f3ead2"), awn("awnYellow", "#e0a62a", "#f3ead2")];

    // ---------------- ground ----------------
    b.add(quadUp(-900, 900, -900, 900, 450, 450, -0.02), M.grass);
    b.add(quadUp(-52, 82, -19, 42, 33.5, 15.25, 0.05), M.plaza);
    b.add(quadUp(35.5, 52.5, -19, 36, 4, 12, 0.06), M.dirt);          // the pasar lane

    // ---------------- helpers ----------------
    const at = (x: number, z: number, yaw: number) => new THREE.Matrix4().makeRotationY(yaw).setPosition(x, 0, z);
    const orangePile = (m: THREE.Matrix4, w: number) => {
      const sph = new THREE.SphereGeometry(0.115, 10, 8);
      for (let l = 0; l < 3; l++) for (let i = 0; i < Math.floor(w / 0.24) - l * 2; i++) for (let k = 0; k < 2 - (l > 1 ? 1 : 0); k++) {
        const x = (i - (Math.floor(w / 0.24) - l * 2 - 1) / 2) * 0.24, z = (k - 0.5) * 0.24 + 0.05;
        b.add(sph, M.orange, new THREE.Matrix4().multiplyMatrices(m, new THREE.Matrix4().makeTranslation(x, 0.99 + l * 0.17, z)));
      }
    };
    /** pasar stall: counter, posts, striped awning, cloth back; `kind` sets what lies on the counter */
    const stall = (x: number, z: number, yaw: number, w: number, aw: number, kind: "orange" | "cloth" | "banana" | "veg" | "chili") => {
      const m = at(x, z, yaw);
      b.add(boxGeo(V(-w / 2, 0, -0.45), V(w / 2, 0.9, 0.45), 1), M.wood, m);
      b.add(boxGeo(V(-w / 2 - 0.06, 0.9, -0.5), V(w / 2 + 0.06, 0.96, 0.5), 1), M.wood, m);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) b.add(boxGeo(V(sx * (w / 2 + 0.1) - 0.05, 0, sz * 0.75 - 0.05), V(sx * (w / 2 + 0.1) + 0.05, 2.6, sz * 0.75 + 0.05), 1), M.wood, m);
      b.add(quad(V(-w / 2 - 0.3, 2.65, -0.9), V(w / 2 + 0.3, 2.65, -0.9), V(w / 2 + 0.3, 2.15, 1.25), V(-w / 2 - 0.3, 2.15, 1.25), w / 1.3, 1), AW[aw], m);
      b.add(boxGeo(V(-w / 2, 0.96, -0.82), V(w / 2, 2.55, -0.78), 1), M.cloth, m);
      if (kind === "orange") { orangePile(m, w); b.add(boxGeo(V(-w / 2 + 0.1, 0.96, 0.18), V(-w / 2 + 0.6, 1.2, 0.48), 1), M.wood, m); }
      if (kind === "banana") for (let i = 0; i < 6; i++) b.add(new THREE.BoxGeometry(0.34, 0.1, 0.12), M.banana, new THREE.Matrix4().multiplyMatrices(m, new THREE.Matrix4().makeTranslation((i - 2.5) * 0.42, 1.05 + (i % 2) * 0.1, 0.05)));
      if (kind === "veg") for (let i = 0; i < 6; i++) b.add(new THREE.SphereGeometry(0.15, 10, 8), M.green, new THREE.Matrix4().multiplyMatrices(m, new THREE.Matrix4().makeTranslation((i - 2.5) * 0.4, 1.06, 0.05)));
      if (kind === "chili") for (let i = 0; i < 5; i++) b.add(boxGeo(V((i - 2) * 0.5 - 0.15, 0.96, -0.2), V((i - 2) * 0.5 + 0.15, 1.2, 0.2), 1), i % 2 ? M.red : M.green, m);
      if (kind === "cloth") ["bolt1", "bolt2", "bolt3", "bolt4", "bolt2", "bolt1"].forEach((k, i) =>
        b.add(boxGeo(V((i - 2.5) * 0.46 - 0.2, 0.96, -0.25), V((i - 2.5) * 0.46 + 0.2, 1.2 + (i % 3) * 0.08, 0.3), 1), (M as Record<string, THREE.Material>)[k], m));
    };

    // ---------------- houses of Wanasari (low kampung rows) ----------------
    setSight(sightLines());
    const hs = [7, 8.5, 6.5, 9, 7.5];
    let hi = 0;
    for (let x = -56; x < 96; x += 9.5) { house(b, x, -16.5 - (hi % 2) * 1.2, 0, hs[hi % 5], 6, 4.2 + (hi % 3) * 0.5, hi * 3 + 1, 0); hi++; }          // behind the plaza and lane, fronts toward +z
    for (let x = -52; x < 92; x += 10.5) { house(b, x, 25 + (hi % 3), Math.PI, hs[hi % 5], 6, 4.4 + (hi % 2) * 0.6, hi * 5 + 2, 0); hi++; }          // behind the cameras, fronts toward -z
    for (const z of [-3, 7, 14]) { house(b, -56, z, Math.PI / 2, 7, 6, 4.4, hi * 3 + 4, 0); house(b, 84, z, -Math.PI / 2, 7, 6, 4.4, hi * 3 + 5, 0); hi++; }
    for (let x = -60; x < 100; x += 12) { house(b, x, -34, 0, 8, 6, 4.6, hi * 2 + 7, 0); hi++; }                                                      // second row for depth
    // trees and bushes (cartoon vegetation built from simple shapes)
    for (const [x, z, h] of [[-36, -11, 6.5], [-10, -12, 5.8], [14, -12.5, 6.8], [30, -12, 6], [58, -12, 6.4], [-42, 8, 6], [-14, 17, 6.2], [20, 17, 6.8], [70, 16, 6]] as const) prop(b, kit, "tree_oak", x, 0, z, h, x * 0.1);
    for (const [x, z] of [[-30, -12.5], [-18, -12.6], [4, -12.7], [24, -12.6], [-6, 15], [34, 16], [60, 14]] as const) prop(b, kit, "plant_bushLarge", x, 0, z, 1.1, x);

    // ---------------- warung + the front chair ----------------
    house(b, -24, -9.5, 0, 7.6, 5, 3.4, 4, 0);
    b.add(quad(V(-28.2, 3.05, -6.8), V(-19.8, 3.05, -6.8), V(-19.8, 2.35, -4.2), V(-28.2, 2.35, -4.2), 6, 1), AW[3]);
    b.add(boxGeo(V(-27.4, 0, -6.6), V(-20.6, 0.95, -5.9), 1), M.wood);
    for (const dx of [-3.2, 3.2]) b.add(boxGeo(V(-24 + dx - 0.18, 0, -3.2 - 0.18 - 0.4), V(-24 + dx + 0.18, 0.42, -3.2 + 0.18 - 0.4), 1), M.wood);
    const [cx, , cz] = CHAIR;
    for (const [dx, dz] of [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3]]) b.add(boxGeo(V(cx + dx - 0.04, 0, cz + dz - 0.04), V(cx + dx + 0.04, 0.2, cz + dz + 0.04), 1), M.wood);
    b.add(boxGeo(V(cx - 0.36, 0.2, cz - 0.36), V(cx + 0.36, 0.26, cz + 0.36), 1), M.wood);
    b.add(boxGeo(V(cx - 0.32, 0.26, cz - 0.32), V(cx + 0.32, 0.3, cz + 0.32), 1), M.cushion);
    b.add(boxGeo(V(cx - 0.42, 0.26, cz - 0.5), V(cx + 0.42, 1.45, cz - 0.4), 1), M.wood);
    b.add(boxGeo(V(cx - 0.34, 0.5, cz - 0.42), V(cx + 0.34, 1.3, cz - 0.38), 1), M.cushion);

    // ---------------- pasar lane: stalls on both sides ----------------
    const zs = [-9, -4.5, 0, 4.5, 9];
    zs.forEach((z, i) => {
      stall(LANE_X - 5.8, z, Math.PI / 2, 3.2, i % 4, z === 0 ? "orange" : (["veg", "banana", "chili", "veg", "banana"] as const)[i]);
      stall(LANE_X + 5.8, z, -Math.PI / 2, 3.2, (i + 2) % 4, z === 0 ? "cloth" : (["banana", "veg", "chili", "banana", "veg"] as const)[i]);
    });

    // ---------------- rooms: kelurahan office (x 0) and school (x 40), open toward +z ----------------
    const room = (rx: number, rz: number) => {
      const W = 12, Dp = 10, H = 3.6;
      b.add(quadUp(rx - W / 2, rx + W / 2, rz - Dp / 2, rz + Dp / 2, 6, 5, 0.03), M.floor);
      b.add(boxGeo(V(rx - W / 2 - 0.2, 0, rz - Dp / 2 - 0.2), V(rx + W / 2 + 0.2, H, rz - Dp / 2), 3), M.plaster);
      b.add(boxGeo(V(rx - W / 2 - 0.2, 0, rz - Dp / 2), V(rx - W / 2, H, rz + Dp / 2), 3), M.plaster);
      b.add(boxGeo(V(rx + W / 2, 0, rz - Dp / 2), V(rx + W / 2 + 0.2, H, rz + Dp / 2), 3), M.plaster);
      b.add(boxGeo(V(rx - W / 2, 0, rz - Dp / 2 + 0.0), V(rx + W / 2, 1.0, rz - Dp / 2 + 0.06), 3), M.wains);
    };
    room(OFFICE_X, OFFICE_Z); room(SCHOOL[0], SCHOOL[2]);
    // desk of the kelurahan office
    const dz = -101.2;
    b.add(boxGeo(V(-1.3, 0.74, dz - 0.5), V(1.3, 0.8, dz + 0.5), 1), M.wood);
    b.add(boxGeo(V(-1.25, 0, dz - 0.45), V(-1.1, 0.74, dz + 0.45), 1), M.wood);
    b.add(boxGeo(V(1.1, 0, dz - 0.45), V(1.25, 0.74, dz + 0.45), 1), M.wood);
    b.add(boxGeo(V(-1.25, 0.1, dz + 0.42), V(1.25, 0.74, dz + 0.48), 1), M.wood);
    // filing shelf along the left wall (colourful binders)
    b.add(boxGeo(V(-5.7, 0, -104.2), V(-4.2, 2.4, -103.5), 1), M.wood);
    ["bolt1", "bolt2", "bolt3", "bolt4", "bolt1", "bolt2", "bolt3", "bolt4"].forEach((k, i) => b.add(boxGeo(V(-5.6 + i * 0.18, 0.2 + (i % 3) * 0.7, -103.62), V(-5.45 + i * 0.18, 0.8 + (i % 3) * 0.7, -103.45), 1), (M as Record<string, THREE.Material>)[k]));
    // school: a row of small desks near the camera side, teacher's table
    for (let i = 0; i < 4; i++) b.add(boxGeo(V(SCHOOL[0] - 3.3 + i * 1.9, 0, -97.4), V(SCHOOL[0] - 2.5 + i * 1.9, 0.62, -96.8), 1), M.wood);
    b.add(boxGeo(V(SCHOOL[0] - 3.9, 0, -103.6), V(SCHOOL[0] - 2.4, 0.9, -102.8), 1), M.wood);
    b.build(R);

    // boards (unlit painted lettering): blackboard, kelurahan sign, warung sign, pasar sign
    const bb = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 2.1), new THREE.MeshBasicMaterial({ map: chalkTex() }));
    bb.layers.set(NOINK); bb.position.set(SCHOOL[0] + 0.6, 1.9, SCHOOL[2] - 4.93); R.add(bb);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(5.8, 2.3, 0.06), M.wood); frame.position.set(SCHOOL[0] + 0.6, 1.9, SCHOOL[2] - 4.97); R.add(frame);
    board(R, signTex("kelSign", "KELURAHAN WANASARI", "#2f6a6a", "#f7efd8", 1024, 192, 92), 0, 2.85, -104.9, 3.4, 0.64);
    board(R, signTex("warSign", "WARUNG IBU TIN", "#9c2f3a", "#f7efd8", 768, 192, 92), -24, 3.0, -6.75, 2.6, 0.65);
    board(R, signTex("pasarSign", "PASAR WANASARI", "#e0a62a", "#3a2a20", 1024, 192, 92), LANE_X, 3.4, -19.3, 5.2, 1.0);
    this.root.updateMatrixWorld(true);
  }

  /** camera-relative sun, frozen per shot: the shot's mean view direction turned by az toward screen right, lifted by el */
  private shotSun(id: number, s: ShotDef, L: LightPreset) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }

  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene) {
    const t = f / 30, s = SHOTS[id - 1], L = LIGHTS[s.light];
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);
    const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (s.light === "golden") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...LOOK[s.light].bounce); TONE.uSat.value = LOOK[s.light].sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = L.fogNear; this.fog.far = L.fogFar;
    scene.fog = this.fog; scene.background = null;
    const showSun = s.light === "golden";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    if (showSun) {
      this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
      this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
      this.sunHalo.position.copy(this.sunDisc.position); this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
      (this.sunHalo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    }
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mat = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z);
      mat.map = this.cloudMaps[s.light][i % 4];
    }
    // ---- cast + effects ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const st = stage(id, t, { pos: cam.position, right });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    let ai = 0;
    const used: Actor[] = [];
    for (const p of st.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true;
      a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0;
    const fused: Fx[] = [];
    for (const p of st.fx) {
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const e2 = this.fx(fi++);
      e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      e2.use(!!p.soft);
      e2.mesh.visible = true;
      e2.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { e2.mesh.quaternion.copy(cam.quaternion); e2.mesh.rotateZ(p.rot ?? 0); }
      e2.mesh.scale.set(p.w, p.h, 1);
      fused.push(e2);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const e2 of fused) e2.bind();
    return focus;
  }
}
const OFFICE_X = 0, OFFICE_Z = -100;
