#!/usr/bin/env bash
# Join chunks/chunk_*.mp4 (no re-encode) + mix_final.wav -> out/<Title>.mp4, then the same QA as tools/finish.sh.
#   bash ci/stitch.sh "Title Of Short" [expected_total_frames]
set -e; T="${1:-short}"; EXP="${2:-}"; F="out/${T// /-}.mp4"; mkdir -p out
[ -f mix_final.wav ] || { echo "mix_final.wav missing: commit it to the repository (python3 audio/mix.py)"; exit 1; }
ls chunks/chunk_*.mp4 >/dev/null 2>&1 || { echo "no chunks found"; exit 1; }
for f in $(ls chunks/chunk_*.mp4 | sort); do echo "file '$PWD/$f'"; done > chunks/list.txt
ffmpeg -v error -y -i mix_final.wav -ar 48000 -ac 2 mix.wav
ffmpeg -v error -y -f concat -safe 0 -i chunks/list.txt -i mix.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart "$F"
N=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "$F")
echo "frames in output: $N"
if [ -n "$EXP" ] && [ "$N" != "$EXP" ]; then echo "FRAME COUNT MISMATCH: expected $EXP"; exit 1; fi
ffprobe -v error -show_entries format=duration -show_entries stream=width,height,r_frame_rate -of compact "$F"
echo "--- QA (empty = no black/frozen spans)"; ffmpeg -i "$F" -vf "freezedetect=n=0.0005:d=0.4,blackdetect=d=0.05" -an -f null - 2>&1 | grep -E "freeze_start|black_start" || true
ffmpeg -i "$F" -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1
ffmpeg -v error -y -i "$F" -vf "fps=2,scale=180:-1,tile=10x4" -frames:v 1 out/qa_sheet.jpg; echo "$F"
