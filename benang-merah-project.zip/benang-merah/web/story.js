export const FPS = 30;
export const TOTAL = 2506;
export const D0 = 0;
export const clamp01 = (x)=>Math.max(0, Math.min(1, x));
export const smooth = (x)=>{
    const u = clamp01(x);
    return u * u * (3 - 2 * u);
};
export const easeOut = (u)=>1 - (1 - clamp01(u)) ** 4;
export const ramp = (f, f0, f1)=>smooth((f - f0) / Math.max(1, f1 - f0));
export const PLAZA = [
    0,
    0,
    0
];
export const WARUNG = [
    -24,
    0,
    -9
];
export const CHAIR = [
    -24,
    0,
    -3.6
];
export const LANE_X = 44;
export const OFFICE = [
    0,
    0,
    -100
];
export const SCHOOL = [
    40,
    0,
    -100
];
export const DESK = [
    0,
    0,
    -101.2
];
export const SHOTS = [
    {
        id: 1,
        a: 0,
        b: 75,
        light: "day",
        name: "hook"
    },
    {
        id: 2,
        a: 75,
        b: 225,
        light: "day",
        name: "thread appears"
    },
    {
        id: 3,
        a: 225,
        b: 310,
        light: "day",
        name: "thread vanishes"
    },
    {
        id: 4,
        a: 310,
        b: 436,
        light: "day",
        name: "Laras bare wrist"
    },
    {
        id: 5,
        a: 436,
        b: 690,
        light: "day",
        name: "warung"
    },
    {
        id: 6,
        a: 690,
        b: 744,
        light: "day",
        name: "proud"
    },
    {
        id: 7,
        a: 744,
        b: 1010,
        light: "day",
        name: "pasar"
    },
    {
        id: 8,
        a: 1010,
        b: 1294,
        light: "day",
        name: "tests"
    },
    {
        id: 9,
        a: 1294,
        b: 1419,
        light: "day",
        name: "school"
    },
    {
        id: 10,
        a: 1419,
        b: 1853,
        light: "day",
        name: "kelurahan"
    },
    {
        id: 11,
        a: 1853,
        b: 2151,
        light: "day",
        name: "realisation"
    },
    {
        id: 12,
        a: 2151,
        b: 2336,
        light: "golden",
        name: "wrap + walk"
    },
    {
        id: 13,
        a: 2336,
        b: TOTAL,
        light: "golden",
        name: "stares"
    }
];
export const XFADE = {
    12: 8
};
export const FLASH_AT = 99999;
export const shotAt = (f)=>SHOTS.find((s)=>f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f)=>{
    for (const s of SHOTS){
        const x = XFADE[s.id];
        if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [
            {
                id: s.id - 1,
                alpha: 1
            },
            {
                id: s.id,
                alpha: (f - (s.a - x / 2) + 1) / (x + 1)
            }
        ];
    }
    return [
        {
            id: shotAt(f).id,
            alpha: 1
        }
    ];
};
export const glide = (u)=>{
    const x = clamp01(u);
    return x * x * x * (x * (6 * x - 15) + 10);
};
const mix = (a, b, k)=>({
        pos: a.pos.map((v, i)=>v + (b.pos[i] - v) * k),
        look: a.look.map((v, i)=>v + (b.look[i] - v) * k),
        fov: a.fov + (b.fov - a.fov) * k,
        roll: a.roll + (b.roll - a.roll) * k
    });
const full = (c)=>({
        fov: 40,
        roll: 0,
        ...c
    });
const run = (keys, f)=>{
    let cur = full(keys[0].s(f));
    for(let i = 1; i < keys.length; i++){
        const k = keys[i];
        if (f < k.f) break;
        cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
    }
    return cur;
};
const pushK = (f, f0, rate, punch = 0, n = 35)=>{
    const x = Math.max(0, f - f0);
    let s = rate * x;
    if (punch > rate) for(let i = 0; i < Math.min(x, n); i++)s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
    return Math.exp(-s);
};
const dolly = (pos, look, k, rest = {})=>({
        pos: [
            look[0] + (pos[0] - look[0]) * k,
            look[1] + (pos[1] - look[1]) * k,
            look[2] + (pos[2] - look[2]) * k
        ],
        look,
        ...rest
    });
const D = dolly;
export const HOOK_X = [
    -0.5,
    0.55
];
export const LARAS_X = 0, LARAS_Z = 0.4;
export const SELLER_X = (f)=>39.4 + 8.9 * ramp(f, 826, 884);
export const BUYER_X = (f)=>SELLER_X(f) - 0.95;
export const TEST_X = [
    -1.9,
    0.0,
    1.9
];
const S1a = (f)=>D([
        2.7,
        1.2,
        5.3
    ], [
        0.05,
        1.0,
        0
    ], pushK(f, 0, 0.003), {
        fov: 40
    });
const S2a = (f)=>D([
        1.4,
        1.15,
        4.4
    ], [
        0,
        1.0,
        0
    ], pushK(f, 75, 0.0025), {
        fov: 38
    });
const S2b = (f)=>D([
        -0.1,
        0.98,
        1.7
    ], [
        HOOK_X[0] + 0.2,
        0.74,
        0
    ], pushK(f, 136, 0.002), {
        fov: 36
    });
const S2c = (f)=>D([
        0.6,
        1.3,
        4.6
    ], [
        -0.35,
        1.2,
        0
    ], pushK(f, 204, 0.0025), {
        fov: 38,
        roll: 0.03
    });
const S3a = (f)=>D([
        -0.05,
        0.98,
        1.6
    ], [
        HOOK_X[0] + 0.26,
        0.74,
        0
    ], pushK(f, 225, 0.002), {
        fov: 36
    });
const S3b = (f)=>D([
        1.0,
        1.15,
        4.0
    ], [
        0,
        1.0,
        0
    ], pushK(f, 256, 0.003), {
        fov: 38
    });
const S3c = (f)=>D([
        -0.15,
        0.95,
        1.35
    ], [
        HOOK_X[0] + 0.28,
        0.75,
        0
    ], pushK(f, 270, 0.003), {
        fov: 34
    });
const S4a = (f)=>D([
        0.9,
        1.3,
        4.6
    ], [
        0.0,
        1.2,
        0
    ], pushK(f, 310, 0.0025), {
        fov: 38
    });
const S4b = (f)=>D([
        0.3,
        0.9,
        1.9
    ], [
        LARAS_X + 0.26,
        0.68,
        LARAS_Z
    ], pushK(f, 372, 0.002), {
        fov: 34,
        roll: -0.03
    });
const S4c = (f)=>D([
        1.1,
        1.3,
        4.4
    ], [
        0,
        1.15,
        0
    ], pushK(f, 418, 0.0025), {
        fov: 38
    });
const S5a = (f)=>D([
        -19.5,
        1.5,
        3.4
    ], [
        -24,
        1.05,
        -3.2
    ], pushK(f, 436, 0.002), {
        fov: 42
    });
const S5b = (f)=>D([
        -22.0,
        1.2,
        -0.2
    ], [
        -24,
        1.0,
        -3.6
    ], pushK(f, 500, 0.0025), {
        fov: 36
    });
const S5c = (f)=>D([
        -26.2,
        1.25,
        0.6
    ], [
        -24.4,
        1.1,
        -3.6
    ], pushK(f, 572, 0.002), {
        fov: 40,
        roll: 0.03
    });
const S5d = (f)=>D([
        -22.8,
        1.15,
        -0.4
    ], [
        -24,
        1.0,
        -3.6
    ], pushK(f, 637, 0.003), {
        fov: 36,
        roll: -0.035
    });
const S6a = (f)=>D([
        -23.3,
        1.1,
        -1.2
    ], [
        -24,
        1.12,
        -3.6
    ], pushK(f, 690, 0.003, 0.006, 28), {
        fov: 30
    });
const S7a = (f)=>D([
        LANE_X + 1.2,
        1.7,
        15
    ], [
        LANE_X,
        1.1,
        0
    ], pushK(f, 744, 0.002), {
        fov: 42
    });
const S7b = (f)=>({
        pos: [
            LANE_X - 0.6,
            1.25,
            6.3
        ],
        look: [
            SELLER_X(f) - 0.5,
            1.0,
            0.2
        ],
        fov: 38
    });
const S7c = (f)=>D([
        48.5,
        0.98,
        1.65
    ], [
        48.28 + 0.26,
        0.74,
        0.2
    ], pushK(f, 905, 0.002), {
        fov: 34
    });
const S7d = (f)=>D([
        47.7,
        0.9,
        1.9
    ], [
        47.35 + 0.27,
        0.68,
        0.25
    ], pushK(f, 964, 0.002), {
        fov: 34
    });
const S8a = (f)=>D([
        -1.8,
        1.25,
        4.9
    ], [
        -3.4,
        1.15,
        0
    ], pushK(f, 1010, 0.0025), {
        fov: 38
    });
const S8b = (f)=>D([
        -1.6,
        1.2,
        4.9
    ], [
        -3.0,
        1.1,
        0
    ], pushK(f, 1055, 0.0025), {
        fov: 40
    });
const S8c = (f)=>D([
        -0.8,
        1.2,
        4.9
    ], [
        -2.0,
        1.1,
        0
    ], pushK(f, 1107, 0.0025), {
        fov: 40
    });
const S8d = (f)=>D([
        0.4,
        1.2,
        4.9
    ], [
        -0.5,
        1.1,
        0
    ], pushK(f, 1138, 0.0025), {
        fov: 40
    });
const S8e = (f)=>D([
        0,
        1.1,
        7.6
    ], [
        0,
        0.95,
        0
    ], pushK(f, 1181, 0.002), {
        fov: 40
    });
const S8f = (f)=>D([
        0.1,
        0.82,
        3.4
    ], [
        0,
        0.8,
        0
    ], pushK(f, 1225, 0.0025), {
        fov: 38,
        roll: 0.035
    });
const S9a = (f)=>D([
        41.2,
        1.55,
        -91.5
    ], [
        41.2,
        1.6,
        -104.4
    ], pushK(f, 1294, 0.0025), {
        fov: 44
    });
const S9b = (f)=>D([
        41.4,
        1.5,
        -94.5
    ], [
        42.2,
        1.5,
        -104.4
    ], pushK(f, 1362, 0.003, 0.006, 30), {
        fov: 40,
        roll: -0.03
    });
const S10a = (f)=>D([
        0.5,
        1.4,
        -93.2
    ], [
        0.2,
        1.15,
        -101.6
    ], pushK(f, 1419, 0.0025), {
        fov: 40
    });
const S10b = (f)=>D([
        -0.3,
        1.25,
        -98.3
    ], [
        -0.35,
        1.2,
        -101.0
    ], pushK(f, 1529, 0.0025), {
        fov: 36
    });
const S10c = (f)=>D([
        -3.4,
        1.25,
        5.4
    ], [
        -4.6,
        1.1,
        0
    ], pushK(f, 1646, 0.003, 0.005, 26), {
        fov: 44
    });
const S10d = (f)=>D([
        -0.1,
        1.25,
        5.2
    ], [
        -0.5,
        1.1,
        0
    ], pushK(f, 1678, 0.003), {
        fov: 44
    });
const S10e = (f)=>D([
        4.4,
        1.25,
        6.6
    ], [
        5.0,
        1.1,
        0
    ], pushK(f, 1704, 0.003), {
        fov: 44,
        roll: 0.03
    });
const S10f = (f)=>D([
        2.0,
        1.5,
        8.5
    ], [
        0,
        1.0,
        0
    ], pushK(f, 1773, 0.002), {
        fov: 42
    });
const S11a = (f)=>D([
        0.6,
        1.25,
        3.4
    ], [
        0,
        1.2,
        0
    ], pushK(f, 1853, 0.003), {
        fov: 34
    });
const S11b = (f)=>D([
        2.6,
        1.3,
        7.0
    ], [
        0,
        1.1,
        0
    ], pushK(f, 1895, 0.002), {
        fov: 40,
        roll: -0.03
    });
const S11c = (f)=>D([
        0.2,
        1.3,
        5.6
    ], [
        0,
        1.15,
        0
    ], pushK(f, 2004, 0.0015, 0.006, 38), {
        fov: 40
    });
const S11d = (f)=>D([
        0.3,
        1.3,
        3.0
    ], [
        0,
        1.2,
        0
    ], pushK(f, 2100, 0.004), {
        fov: 34,
        roll: 0.05
    });
const S12a = (f)=>D([
        -0.1,
        1.0,
        1.5
    ], [
        0.27,
        0.78,
        0.4
    ], pushK(f, 2151, 0.002), {
        fov: 34
    });
const S12b = (f)=>({
        pos: [
            LANE_X + 0.4,
            1.2,
            4.5 + 5.5 * ramp(f, 2251, 2336)
        ],
        look: [
            LANE_X,
            1.1,
            -6 + 9.5 * ramp(f, 2251, 2336)
        ],
        fov: 40
    });
const S13a = (f)=>D([
        LANE_X + 1.6,
        1.35,
        6.2
    ], [
        LANE_X,
        1.15,
        0.8
    ], pushK(f, 2336, 0.002), {
        fov: 40
    });
const S13b = (f)=>D([
        LANE_X - 1.9,
        1.0,
        4.6
    ], [
        LANE_X + 0.2,
        1.0,
        0.8
    ], pushK(f, 2398, 0.0025), {
        fov: 36,
        roll: -0.03
    });
const S13c = (f)=>D([
        LANE_X + 0.3,
        1.15,
        6.4
    ], [
        LANE_X + 0.4,
        1.05,
        0.8
    ], pushK(f, 2446, 0.003, 0.006, 40), {
        fov: 40,
        roll: 0.035
    });
const CAMS = {
    1: [
        {
            f: 0,
            s: S1a
        }
    ],
    2: [
        {
            f: 75,
            s: S2a
        },
        {
            f: 136,
            cut: true,
            s: S2b
        },
        {
            f: 204,
            dur: 26,
            s: S2c
        }
    ],
    3: [
        {
            f: 225,
            s: S3a
        },
        {
            f: 256,
            cut: true,
            s: S3b
        },
        {
            f: 270,
            cut: true,
            s: S3c
        }
    ],
    4: [
        {
            f: 310,
            s: S4a
        },
        {
            f: 372,
            cut: true,
            s: S4b
        },
        {
            f: 418,
            dur: 28,
            s: S4c
        }
    ],
    5: [
        {
            f: 436,
            s: S5a
        },
        {
            f: 500,
            cut: true,
            s: S5b
        },
        {
            f: 572,
            cut: true,
            s: S5c
        },
        {
            f: 637,
            cut: true,
            s: S5d
        }
    ],
    6: [
        {
            f: 690,
            s: S6a
        }
    ],
    7: [
        {
            f: 744,
            s: S7a
        },
        {
            f: 820,
            cut: true,
            s: S7b
        },
        {
            f: 905,
            cut: true,
            s: S7c
        },
        {
            f: 940,
            dur: 26,
            s: S7d
        }
    ],
    8: [
        {
            f: 1010,
            s: S8a
        },
        {
            f: 1055,
            cut: true,
            s: S8b
        },
        {
            f: 1107,
            cut: true,
            s: S8c
        },
        {
            f: 1138,
            cut: true,
            s: S8d
        },
        {
            f: 1181,
            cut: true,
            s: S8e
        },
        {
            f: 1225,
            dur: 28,
            s: S8f
        }
    ],
    9: [
        {
            f: 1294,
            s: S9a
        },
        {
            f: 1362,
            dur: 26,
            s: S9b
        }
    ],
    10: [
        {
            f: 1419,
            s: S10a
        },
        {
            f: 1529,
            cut: true,
            s: S10b
        },
        {
            f: 1646,
            cut: true,
            s: S10c
        },
        {
            f: 1678,
            cut: true,
            s: S10d
        },
        {
            f: 1704,
            cut: true,
            s: S10e
        },
        {
            f: 1773,
            cut: true,
            s: S10f
        }
    ],
    11: [
        {
            f: 1853,
            s: S11a
        },
        {
            f: 1895,
            dur: 30,
            s: S11b
        },
        {
            f: 2004,
            dur: 30,
            s: S11c
        },
        {
            f: 2100,
            cut: true,
            s: S11d
        }
    ],
    12: [
        {
            f: 2151,
            s: S12a
        },
        {
            f: 2251,
            cut: true,
            s: S12b
        }
    ],
    13: [
        {
            f: 2336,
            s: S13a
        },
        {
            f: 2398,
            cut: true,
            s: S13b
        },
        {
            f: 2446,
            cut: true,
            s: S13c
        }
    ]
};
const KICKS = [
    [
        2105 / 30,
        0.9
    ],
    [
        2487 / 30,
        0.5
    ]
];
export const kickAt = (t)=>{
    let a = 0;
    for (const [t0, g] of KICKS){
        const n = Math.floor((t - t0) * FPS + 1e-6);
        if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
    }
    return a;
};
export const camAt = (id, f)=>{
    const c = run(CAMS[id], f), a = kickAt(f / FPS);
    if (!a) return c;
    const d = [
        c.look[0] - c.pos[0],
        c.look[1] - c.pos[1],
        c.look[2] - c.pos[2]
    ];
    const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
    const m = 3 / 640 * Math.tan(c.fov * Math.PI / 360) * L * a;
    return {
        ...c,
        look: [
            c.look[0] - d[2] / h * m,
            c.look[1] + 0.6 * m,
            c.look[2] + d[0] / h * m
        ],
        roll: c.roll + a * 0.004
    };
};
export const keyEnd = (id, f)=>{
    let e = 0;
    for (const k of CAMS[id])if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
    return Math.max(f, e);
};
export const DOF = [
    {
        f: 0,
        cInf: 8
    },
    {
        f: 75,
        cInf: 10
    },
    {
        f: 136,
        cInf: 14
    },
    {
        f: 204,
        dur: 26,
        cInf: 10
    },
    {
        f: 225,
        cInf: 14
    },
    {
        f: 256,
        cInf: 8
    },
    {
        f: 270,
        cInf: 14
    },
    {
        f: 310,
        cInf: 8
    },
    {
        f: 372,
        cInf: 14
    },
    {
        f: 418,
        dur: 28,
        cInf: 8
    },
    {
        f: 436,
        cInf: 0
    },
    {
        f: 500,
        cInf: 10
    },
    {
        f: 572,
        cInf: 8
    },
    {
        f: 637,
        cInf: 12
    },
    {
        f: 690,
        cInf: 14
    },
    {
        f: 744,
        cInf: 0
    },
    {
        f: 820,
        cInf: 8
    },
    {
        f: 905,
        cInf: 14
    },
    {
        f: 1010,
        cInf: 6
    },
    {
        f: 1055,
        cInf: 9
    },
    {
        f: 1181,
        cInf: 0
    },
    {
        f: 1225,
        cInf: 12
    },
    {
        f: 1294,
        cInf: 8
    },
    {
        f: 1419,
        cInf: 8
    },
    {
        f: 1529,
        cInf: 12
    },
    {
        f: 1646,
        cInf: 10
    },
    {
        f: 1773,
        cInf: 0
    },
    {
        f: 1853,
        cInf: 14
    },
    {
        f: 1895,
        dur: 30,
        cInf: 6
    },
    {
        f: 2004,
        dur: 30,
        cInf: 9
    },
    {
        f: 2100,
        cInf: 14
    },
    {
        f: 2151,
        cInf: 14
    },
    {
        f: 2251,
        cInf: 4
    },
    {
        f: 2336,
        cInf: 6
    },
    {
        f: 2398,
        cInf: 10
    },
    {
        f: 2446,
        cInf: 6
    }
];
export const dofAt = (f)=>{
    let i = 0;
    while(i + 1 < DOF.length && f >= DOF[i + 1].f)i++;
    const d = DOF[i], p = DOF[Math.max(0, i - 1)];
    const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
    return {
        cInf: p.cInf + (d.cInf - p.cInf) * k,
        focus: d.focus
    };
};
export const focusAt = (id, f)=>{
    const d = dofAt(f);
    return d.focus ? d.focus(f) : camAt(id, f).look;
};
export const FOREGROUND = [];
