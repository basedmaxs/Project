// ---------------- the cast of Wanasari ----------------
export type Stage = { places: Place[]; fx: FxPlace[] };
const SKIN_A = "#d0a074", SKIN_B = "#c99067", SKIN_C = "#e0b48c", SKIN_D = "#b98258";
const hair = (c: string) => ({ hat: "hair", hair: c } as const);
const OUT: Record<string, Outfit> = {
  laras: { jacket: "#f0d58a", dress: "#2f6a6a", boots: "#5a3b2a", skin: SKIN_A, ...hair("#1c1514") },
  joko: { jacket: "#e8e2d0", pants: "#3a3a48", boots: "#4a3426", skin: SKIN_B, hat: "cap", cap: "#1f1b1b" },
  sri: { jacket: "#c25a7a", dress: "#d9a441", boots: "#5a3b2a", skin: SKIN_C, ...hair("#b8b3ad") },
  wati: { jacket: "#5d7a3a", dress: "#8a4a5f", boots: "#4a3426", skin: SKIN_A, ...hair("#241a17") },
  ojek: { jacket: "#d9a02b", pants: "#3b5b9a", boots: "#2b2b2b", skin: SKIN_D, hat: "cap", cap: "#262626" },
  guru: { jacket: "#e9e4d6", dress: "#6b3d78", boots: "#5a3b2a", skin: SKIN_C, ...hair("#241a17") },
  seller: { jacket: "#d98a2b", pants: "#4a3a2a", boots: "#4a3426", skin: SKIN_B, hat: "cap", cap: "#2b211c" },
  buyer: { jacket: "#5a8fc2", dress: "#c25a7a", boots: "#4a3426", skin: SKIN_D, ...hair("#1c1514") },
  dani: { jacket: "#3f6fb5", pants: "#3a3a48", boots: "#4a3426", skin: SKIN_A, hat: "cap", cap: "#1f1b1b" },
  anwar: { jacket: "#8c3b4a", pants: "#3a3a48", boots: "#4a3426", skin: SKIN_D, hat: "cap", cap: "#1f1b1b" },
  kid: { jacket: "#e2453c", pants: "#3b5b9a", boots: "#f4f1ea", skin: SKIN_B, build: "kid", ...hair("#1c1514") },
  mother: { jacket: "#e9d9c0", dress: "#5a8fc2", boots: "#4a3426", skin: SKIN_A, ...hair("#241a17") },
};
const FOLK: string[] = ["joko", "sri", "wati", "dani", "anwar", "buyer", "guru", "ojek"];
const IDX: Record<string, number> = { laras: 1, joko: 2, sri: 3, wati: 4, ojek: 5, guru: 6, seller: 7, buyer: 8, dani: 9, anwar: 10, kid: 11, mother: 12 };

type Spec = { k: string; x: number; z: number; y?: number; sc?: number; by?: number; fo?: Partial<FrontOpts>; i?: number };
const put = (cam: CamInfo, t: number, out: Stage, s: Spec) => {
  const i = s.i ?? IDX[s.k] ?? 20;
  const fo: FrontOpts = { mode: "stand", expr: "neutral", blink: lidAt(t, i), ...s.fo };
  out.places.push(person(cam, { i, o: OUT[s.k], okey: s.k }, s.x, s.y ?? 0, s.z, { side: false, mirror: false }, fo, {}, s.sc ?? 1));
  blob(out, s.x, s.by ?? 0, s.z, s.sc ?? 1);
};
const F = (t: number) => Math.round(t * FPS);
/** reaction lands 2 frames before the word */
const L2 = 2;
const on = (f: number, at: number) => f >= at - L2;
/** thread amount growing from n0 to n1 between frames a and b */
const grow = (f: number, a: number, b: number, n0 = 0, n1 = 1) => n0 + (n1 - n0) * smooth((f - a) / (b - a));
/** walking along x between frames: position, phase (0.7 m per step cycle of 1.4 m), moving flag */
const walkX = (f: number, f0: number, f1: number, x0: number, x1: number) => {
  const u = smooth((f - f0) / (f1 - f0)), x = x0 + (x1 - x0) * u, mv = f > f0 && f < f1;
  return { x: q(x, 100), phase: mv ? q(((Math.abs(x - x0) / 1.4) % 1), 60) : 0, mv };
};
const spark = (out: Stage, f: number, f0: number, x: number, y: number, z: number, w = 0.5) => {
  const n = f - f0;
  if (n < 0 || n >= 7) return;
  const u = q(n / 7, 30);
  out.fx.push({ key: `spark${u}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, u, "#ffd9d4", 9, 18, 120), x, y, z, w, h: w });
};

// ---------------- item cards ----------------
const fxBasket = (p: Pen) => {
  for (const [x, y, c] of [[70, 70, "#f2d04a"], [110, 60, "#f7de6a"], [150, 70, "#ecc63c"]] as const) p.ell(x, y, 17, 42, c, 7, 0, 360, x > 100 ? -20 : 20);
  p.poly([[26, 90], [194, 90], [172, 170], [48, 170]], "#b8864a", 8);
  p.stroke([[40, 118], [180, 118]], 5, "#7a5430"); p.stroke([[46, 144], [176, 144]], 5, "#7a5430");
};
const fxBanana = (p: Pen) => {
  for (const [dx, r] of [[0, 0], [22, 6], [44, 12]] as const) p.stroke([[40 + dx, 50 + r], [60 + dx, 120 - r], [110 + dx * 0.5, 150]], 22, "#d6b73a");
  p.stroke([[40, 50], [62, 118]], 9, "#7a5a2a");
};
const fxHelmet = (p: Pen) => { p.ell(100, 110, 80, 70, "#262626", 8, 180, 360); p.poly([[20, 112], [180, 112], [172, 140], [28, 140]], "#262626", 8); p.ell(72, 82, 22, 12, "#6d7480", 0, 0, 360, -20); };
const fxBook = (p: Pen) => { p.poly([[20, 40], [180, 40], [180, 150], [20, 150]], "#3f6fb5", 8); p.stroke([[40, 70], [160, 70]], 6, "#f2e9cf"); p.stroke([[40, 100], [140, 100]], 6, "#f2e9cf"); };
const fxBag = (p: Pen) => { p.poly([[30, 70], [170, 70], [160, 170], [40, 170]], "#c25a7a", 8); p.arc(100, 70, 40, 34, 180, 360, 7, "#241726"); };
const fxSpool = (p: Pen) => { p.poly([[40, 50], [160, 50], [160, 150], [40, 150]], "#e9d3a0", 8); p.stroke([[44, 72], [156, 72]], 20, "#d4262e"); p.stroke([[44, 104], [156, 104]], 20, "#d4262e"); p.stroke([[44, 134], [156, 134]], 12, "#d4262e"); };
const fxCall = (p: Pen, k: number) => {
  p.poly([[20, 40], [180, 40], [180, 120], [96, 120], [60, 168], [66, 120], [20, 120]], "#fff6e0", 8);
  p.stroke([[100, 56], [100, 92]], 14, "#d4262e"); p.dot(100, 108, 8, "#d4262e");
  if (k) { p.stroke([[50, 64], [50, 86]], 9, "#d4262e"); p.dot(50, 100, 5, "#d4262e"); }
};
/** the kelurahan ledger page: rows of names, red thread rings fill in as the voice says "penuh benang" (fill 0..1) */
const NAMES = ["Pak Joko", "Bu Wati", "Mas Dani", "Bu Sri", "Pak Anwar"];
const fxLedger = (p: Pen, fill: number) => {
  const g = p.g;
  p.poly([[14, 14], [686, 14], [686, 506], [14, 506]], "#f3e9cf", 12);
  g.fillStyle = "#241726"; g.font = "bold 34px 'Comic Sans MS','Segoe Print',cursive,sans-serif"; g.textBaseline = "middle";
  g.fillText("DAFTAR WARGA TERHORMAT", 40, 56);
  p.stroke([[34, 88], [666, 88]], 5, "#241726");
  NAMES.forEach((n, i) => {
    const y = 140 + i * 74;
    g.fillStyle = "#241726"; g.font = "bold 30px 'Comic Sans MS','Segoe Print',cursive,sans-serif"; g.fillText(`${i + 1}. ${n}`, 44, y);
    const rings = Math.round((7 - i * 0.6) * clamp01(fill * 1.15 - i * 0.06));
    for (let r = 0; r < rings; r++) { const x = 330 + r * 44; p.ell(x, y, 15, 24, null, 0); p.stroke([[x - 14, y - 4], [x, y + 8], [x + 14, y - 4]], 10, "#241726"); p.stroke([[x - 14, y - 4], [x, y + 8], [x + 14, y - 4]], 6, "#d4262e"); }
  });
};

// ---------------- crowds ----------------
type Walker = { k: string; z: number; x0: number; x1: number; f0: number; f1: number; n: number };
/** background strollers with threads; they loop along x */
const strollers = (cam: CamInfo, t: number, out: Stage, list: Walker[]) => {
  const f = F(t);
  list.forEach((w, i) => {
    const span = w.f1 - w.f0, u = (((f - w.f0) % span) + span) % span / span, x = w.x0 + (w.x1 - w.x0) * u;
    const dir = Math.sign(w.x1 - w.x0);
    put(cam, t, out, { k: w.k, x: q(x, 100), z: w.z, i: 30 + i, fo: { mode: "stroll", phase: q((Math.abs(x - w.x0) / 1.4) % 1, 60), expr: i % 2 ? "smile_closed" : "neutral", look: 0, thread: [w.n, i % 2 ? w.n : 0] } });
  });
};

export const stage = (id: number, t: number, cam: CamInfo): Stage => {
  const out: Stage = { places: [], fx: [] };
  const s = SHOTS[id - 1], f = F(t);
  LNAME = s.light;
  findSun(cam, SUN);
  const at = (a: number) => on(f, a);
  const [JX, SX] = HOOK_X;

  // ---- 1-3: Pak Joko helps Bu Sri; the thread grows on HIS wrist (the helper), and vanishes when she thanks him ----
  if (id <= 3) {
    let basketX = SX + 0.38, basketY = 0.5;
    if (f >= 104) { const u = smooth((f - 104) / 22); basketX = SX + 0.38 + (JX + 0.34 - SX - 0.38) * u; }
    if (f >= 205) { const u = smooth((f - 205) / 16); basketX = JX + 0.34 + (SX + 0.38 - JX - 0.34) * u; }
    const n = id === 1 ? 0 : id === 2 ? grow(f, 147, 200) : 1 - grow(f, 268, 284);
    put(cam, t, out, { k: "joko", x: JX, z: 0, fo: { expr: at(110) ? "smile_closed" : "neutral", thread: [0, n], look: 0 } });
    put(cam, t, out, { k: "sri", x: SX, z: 0, fo: { expr: id === 1 ? "neutral" : at(110) && f < 205 ? "relief" : at(256) ? "smile" : f < 110 ? "nervous" : "smile_closed", look: 0, tilt: f < 104 ? 3 : 0 } });
    if (id >= 2) out.fx.push({ key: "basket", cw: 200, ch: 200, draw: fxBasket, x: q(basketX, 100), y: basketY, z: 0.12, w: 0.34, h: 0.34 });
    if (id === 3 && f >= 250) {
      const u = smooth((f - 250) / 14);
      out.fx.push({ key: "banana", cw: 200, ch: 200, draw: fxBanana, x: q(SX - 0.3 + (JX + 0.1 - SX + 0.3) * u, 100), y: 0.75 - 0.2 * Math.sin(Math.PI * u), z: 0.12, w: 0.26, h: 0.26 });
    }
    spark(out, f, 147, JX + 0.28, 0.82, 0.1, 0.5);
    spark(out, f, 276, JX + 0.28, 0.82, 0.1, 0.5);
    // passers-by with threads in the background
    strollers(cam, t, out, [
      { k: "dani", z: -3.2, x0: -6, x1: 6, f0: 0, f1: 520, n: 2 }, { k: "wati", z: -5.0, x0: 7, x1: -7, f0: 0, f1: 640, n: 1 },
      { k: "anwar", z: -4.0, x0: -8, x1: 5, f0: 0, f1: 760, n: 3 },
    ]);
  }

  // ---- 4: Laras, bare wrists ----
  if (id === 4) {
    put(cam, t, out, { k: "laras", x: LARAS_X, z: LARAS_Z, fo: { expr: at(310) && f < 339 ? "neutral" : f < 372 ? "nervous" : "neutral", look: at(339) && f < 400 ? 0 : 0, headTilt: at(339) && f < 372 ? 6 : 0, thread: [0, 0] } });
    strollers(cam, t, out, [
      { k: "joko", z: -3.2, x0: -6, x1: 6, f0: 0, f1: 420, n: 2 }, { k: "sri", z: -5.0, x0: 7, x1: -7, f0: 0, f1: 520, n: 1 },
      { k: "wati", z: -4.2, x0: -7, x1: 6, f0: 0, f1: 600, n: 3 },
    ]);
  }

  // ---- 5-6: warung, the front chair ----
  if (id === 5 || id === 6) {
    const [cx, , cz] = CHAIR;
    const bow = at(575) && f < 625 ? 16 * Math.sin(Math.PI * smooth((f - 573) / 52)) : 0;
    const lexpr: Expr = f < 500 ? "neutral" : f < 640 ? "smile_closed" : f < 707 ? "neutral" : "smile";
    put(cam, t, out, { k: "laras", x: cx, y: 0.2, by: 0, z: cz, fo: { mode: "sit", expr: lexpr, headTilt: id === 6 ? -6 : 0, thread: [0, 0] } });
    if (id === 5) {
      const a = walkX(f, 640, 700, cx - 2.3, cx - 6.5), b = walkX(f, 648, 706, cx + 2.4, cx + 6.8);
      put(cam, t, out, { k: "joko", x: a.x, z: cz + 0.8, fo: { mode: a.mv ? "stroll" : "stand", phase: a.phase, expr: "smile_closed", tilt: bow, thread: [grow(f, 436, 437, 2, 2), 1] } });
      put(cam, t, out, { k: "sri", x: b.x, z: cz + 0.9, fo: { mode: b.mv ? "stroll" : "stand", phase: b.phase, expr: "smile_closed", tilt: bow, thread: [2, 0] } });
      put(cam, t, out, { k: "dani", x: cx - 0.2, z: cz - 2.2 + 0 * 0, fo: { expr: "smile_closed", tilt: bow * 0.8, wave: at(502) && f < 551 ? q(Math.sin(f * 0.5), 20) : undefined, thread: [3, 3] } });
    }
  }

  // ---- 7: pasar lane ----
  if (id === 7) {
    const sx = SELLER_X(f), bx = BUYER_X(f), mv = f > 826 && f < 884;
    const ph = mv ? q(((sx - 39.4) / 1.4) % 1, 60) : 0;
    put(cam, t, out, { k: "laras", x: LANE_X - 2.3, z: f < 820 ? 9.0 - 5.5 * smooth((f - 744) / 60) : 3.6, fo: { mode: f < 804 && f > 744 ? "stroll" : "stand", phase: f < 804 ? q((((f - 744) * 0.025) % 1), 60) : 0, expr: at(757) ? "nervous" : "neutral", look: f > 777 ? -1 : 0, headTilt: f > 790 ? -4 : 0, thread: [0, 0] } });
    put(cam, t, out, { k: "seller", x: sx, z: 0.2, fo: { mode: mv ? "stroll" : "stand", phase: ph, expr: "smile", look: 0, thread: [0, grow(f, 911, 950, 0, 1)], wave: mv ? 0.3 : undefined } });
    put(cam, t, out, { k: "buyer", x: bx, z: 0.25, fo: { mode: mv ? "stroll" : "stand", phase: ph, expr: "relief", look: 0, thread: [0, 0] } });
    spark(out, f, 911, 48.3 + 0.28, 0.82, 0.3, 0.5);
    strollers(cam, t, out, [
      { k: "dani", z: -3.0, x0: 40, x1: 48, f0: 744, f1: 1000, n: 2 }, { k: "wati", z: -5.0, x0: 48.5, x1: 39.5, f0: 744, f1: 900, n: 1 },
      { k: "anwar", z: -7.0, x0: 40, x1: 48.4, f0: 744, f1: 880, n: 2 },
    ]);
  }

  // ---- 8: the tests ----
  if (id === 8) {
    const gx = (k: number) => TEST_X[k];
    const ask = (a: number, b: number) => (f >= a && f < b ? q(Math.sin(f * 0.45) * 0.8, 20) : undefined);
    put(cam, t, out, { k: "laras", x: -3.4, z: 0, fo: { expr: f < 1055 ? "stern" : f < 1181 ? "neutral" : "shock", wave: ask(1059, 1080) ?? ask(1110, 1128) ?? ask(1143, 1165), thread: [0, 0] } });
    put(cam, t, out, { k: "wati", x: gx(0) - 0.4, z: 0, fo: { expr: f >= 1070 ? "smile" : "neutral", thread: [0, grow(f, 1090, 1112, 0, 1) + grow(f, 1225, 1265, 0, 1)] } });
    put(cam, t, out, { k: "ojek", x: gx(1) - 0.2, z: 0, fo: { expr: f >= 1115 ? "grin" : "neutral", thread: [0, grow(f, 1118, 1140, 0, 1) + grow(f, 1225, 1265, 0, 1)] } });
    put(cam, t, out, { k: "guru", x: gx(2), z: 0, fo: { expr: f >= 1143 ? "smile" : "neutral", thread: [0, grow(f, 1150, 1175, 0, 1) + grow(f, 1225, 1265, 0, 1)] } });
    if (f >= 1075) out.fx.push({ key: "bag", cw: 200, ch: 200, draw: fxBag, x: q(gx(0) - 0.4 + 0.34, 100), y: 0.42, z: 0.12, w: 0.3, h: 0.3 });
    if (f >= 1120) out.fx.push({ key: "helmet", cw: 200, ch: 200, draw: fxHelmet, x: q(gx(1) - 0.2 - 0.34, 100), y: 0.55, z: 0.12, w: 0.3, h: 0.3 });
    if (f >= 1152) out.fx.push({ key: "book", cw: 200, ch: 200, draw: fxBook, x: q(gx(2) - 0.34, 100), y: 0.55, z: 0.12, w: 0.28, h: 0.28 });
    spark(out, f, 1090, gx(0) - 0.4 + 0.28, 0.82, 0.1, 0.5);
    spark(out, f, 1118, gx(1) - 0.2 + 0.28, 0.82, 0.1, 0.5);
    spark(out, f, 1150, gx(2) + 0.28, 0.82, 0.1, 0.5);
  }

  // ---- 9: school ----
  if (id === 9) {
    const [sx, , sz] = SCHOOL;
    put(cam, t, out, { k: "guru", x: sx + 0.4, z: sz - 4.2, fo: { expr: f < 1362 ? "stern" : "smile_closed", wave: f >= 1306 && f < 1345 ? q(0.6 + 0.4 * Math.sin(f * 0.3), 20) : undefined, thread: [2, 2] } });
  }

  // ---- 10: kelurahan: ledger, then the threaded folks of the town ----
  if (id === 10) {
    const [, , dz] = [0, 0, DESK[2]];
    if (f < 1646) {
      put(cam, t, out, { k: "laras", x: 0, y: 0.25, by: 0, z: dz - 0.9, fo: { mode: "sit", expr: f < 1529 ? "neutral" : "shock", thread: [0, 0] } });
      if (f >= 1440) out.fx.push({ key: `ledger${q(clamp01((f - 1560) / 70), 12)}`, cw: 700, ch: 520, draw: (p) => fxLedger(p, q(clamp01((f - 1560) / 70), 12)), x: 0, y: 1.15, z: dz + 0.2, w: 1.0, h: 0.74 });
    } else if (f < 1773) {
      // three little scenes in a row along x, each with its own camera: someone looks for them / waits / calls them
      put(cam, t, out, { k: "joko", x: -4, z: 0, fo: { expr: at(1646) ? "smile" : "neutral", thread: [3, 3] } });
      put(cam, t, out, { k: "dani", x: -5.2, z: 0.2, fo: { expr: "grin", wave: at(1650) ? q(Math.sin(f * 0.5), 20) : undefined, tilt: -6, thread: [1, 0] } });
      put(cam, t, out, { k: "wati", x: 0.2, z: 0, fo: { expr: "smile_closed", thread: [3, 3] } });
      put(cam, t, out, { k: "sri", x: -1.2, z: 0.1, fo: { expr: at(1678) ? "relief" : "neutral", thread: [1, 0], look: 1 } });
      put(cam, t, out, { k: "ojek", x: 4.0, z: 0, fo: { expr: at(1704) ? "laugh" : "neutral", thread: [3, 3], look: 1 } });
      put(cam, t, out, { k: "anwar", x: 6.0, z: -0.8, fo: { expr: "laugh", wave: at(1704) ? q(0.8 + 0.2 * Math.sin(f * 0.7), 20) : undefined, thread: [0, 0] } });
      if (at(1704)) out.fx.push({ key: `call${(f >> 3) & 1}`, cw: 200, ch: 200, draw: (p) => fxCall(p, (f >> 3) & 1), x: 5.4, y: 2.35, z: -0.8, w: 0.5, h: 0.5 });
    } else {
      put(cam, t, out, { k: "joko", x: 0, z: 0, fo: { expr: "laugh", thread: [3, 3] } });
      [[-1.5, 0.3, "sri", 2], [-0.8, -0.9, "wati", 3], [1.4, 0.4, "dani", 2], [0.8, -1.0, "ojek", 3], [2.2, -0.6, "anwar", 1], [-2.2, -0.5, "guru", 2]].forEach(([x, z, k, n], i) =>
        put(cam, t, out, { k: k as string, x: x as number, z: z as number, fo: { expr: i % 2 ? "laugh" : "grin", thread: [n as number, i % 2 ? (n as number) : 1] } }));
    }
  }

  // ---- 11: Laras understands ----
  if (id === 11) {
    const ex: Expr = f < 1902 ? "shock" : f < 2017 ? "relief" : f < 2105 ? "pained" : "pained";
    put(cam, t, out, { k: "laras", x: 0, z: 0, fo: { expr: ex, headTilt: f >= 2105 ? -7 : f >= 2017 ? 3 : 0, look: f >= 1902 && f < 1990 ? 1 : 0, thread: [0, 0] } });
    const W: Walker[] = [
      { k: "joko", z: -3.5, x0: -7, x1: 7, f0: 1853, f1: 2150, n: 3 }, { k: "wati", z: -5.2, x0: 8, x1: -6, f0: 1853, f1: 2300, n: 2 },
      { k: "dani", z: -7.0, x0: -8, x1: 7, f0: 1853, f1: 2500, n: 3 }, { k: "sri", z: -4.4, x0: 6, x1: -8, f0: 1853, f1: 2650, n: 2 },
    ];
    strollers(cam, t, out, W);
    if (f >= 1960 && f < 1967) {
      const u = q((f - 1960) / 7, 30);
      for (const [x, z] of [[-1.6, -3.5], [1.8, -4.4], [-0.2, -5.2]] as const) out.fx.push({ key: `spark${u}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, u, "#ffd9d4", 9, 18, 120), x, y: 0.9, z, w: 0.5, h: 0.5 });
    }
  }

  // ---- 12: golden: Laras wraps the red sewing thread, walks to the pasar ----
  if (id === 12) {
    if (f < 2251) {
      const n = grow(f, 2171, 2240, 0, 1.4);
      put(cam, t, out, { k: "laras", x: 0, z: 0.4, fo: { expr: f < 2186 ? "neutral" : "smile_closed", thread: [0, n], headTilt: 4 } });
      out.fx.push({ key: "spool", cw: 200, ch: 200, draw: fxSpool, x: -0.3, y: 0.62, z: 0.55, w: 0.26, h: 0.26 });
      spark(out, f, 2236, 0.27, 0.82, 0.5, 0.5);
    } else {
      const u = smooth((f - 2251) / 85), z = -6 + 6.8 * u, mv = f < 2336;
      put(cam, t, out, { k: "laras", x: LANE_X, z: q(z, 100), fo: { mode: mv ? "stroll" : "stand", phase: mv ? q(((z + 6) / 1.4) % 1, 60) : 0, expr: "smile_closed", wave: q(0.4 + 0.6 * smooth((f - 2282) / 30), 20), thread: [0, 1.4] } });
      for (const [x, z2, k, n] of [[-2.6, -2.5, "joko", 2], [2.8, -3.0, "sri", 1], [-1.4, -6, "wati", 3], [1.8, -7.5, "dani", 2]] as const)
        put(cam, t, out, { k, x: LANE_X + x, z: z2, fo: { expr: "neutral", thread: [n, 1] } });
    }
  }

  // ---- 13: they stare; the child points; the mother pulls it away ----
  if (id === 13) {
    const stare = at(2351), nerv = at(2400);
    const pull = smooth((f - 2462) / 44);
    put(cam, t, out, { k: "laras", x: LANE_X, z: 0.8, fo: { expr: f < 2380 ? "smile_closed" : "neutral", wave: 1, thread: [0, 1.4] } });
    const ex = (a: Expr, b: Expr): Expr => (nerv ? b : stare ? a : "neutral");
    put(cam, t, out, { k: "joko", x: LANE_X - 1.5, z: 0.3, fo: { expr: ex("stern", "nervous"), look: 1, thread: [2, 1] } });
    put(cam, t, out, { k: "wati", x: LANE_X - 0.9, z: -1.0, fo: { expr: ex("stern", "stern"), look: 1, thread: [3, 3] } });
    put(cam, t, out, { k: "dani", x: LANE_X + 1.6, z: -0.4, fo: { expr: ex("stern", "nervous"), look: -1, thread: [2, 0] } });
    put(cam, t, out, { k: "seller", x: LANE_X + 2.5, z: -1.4, fo: { expr: ex("neutral", "stern"), look: -1, thread: [1, 1] } });
    const kx = LANE_X + 1.15 + 1.9 * pull, mx = LANE_X + 2.0 + 2.0 * pull, moving = pull > 0 && pull < 1;
    put(cam, t, out, { k: "kid", x: q(kx, 100), z: 2.4, sc: 0.72, fo: { mode: moving ? "stroll" : "stand", phase: moving ? q((pull * 2.5) % 1, 60) : 0, expr: at(2400) ? "grin" : "smile", wave: at(2410) && f < 2480 ? q(0.8 + 0.2 * Math.sin(f * 0.5), 20) : undefined, look: -1, tilt: moving ? 8 : 0, thread: [0, 0] } });
    put(cam, t, out, { k: "mother", x: q(mx, 100), z: 2.5, fo: { mode: moving ? "stroll" : "stand", phase: moving ? q((pull * 2.2) % 1, 60) : 0, expr: at(2448) ? "shock" : "neutral", tilt: moving ? -8 : 0, look: -1, thread: [1, 0] } });
  }
  return out;
};
export { FPS };
