# Benang Merah (Wanasari) — shot plan
Voice 83.54 s -> TOTAL = 2506 f @30. Light: day until "Sore itu" (f2151), then golden.
Props/world: small kampung town (warung, pasar with orange stall, SD school, kelurahan office), red thread = thin curved Fx card on wrist.

| # | frames | words | place / light | camera | on screen | lens | fg prop | SFX |
|---|---|---|---|---|---|---|---|---|
| 1 | 0-75 | Di kota Wanasari, utang budi bisa dilihat. | street, day | MS 3/4, slow push | helper steadies a neighbour; red thread on helper's wrist | cInf 12 | none | soft chime |
| 2 | 75-225 | Setiap kali menerima pertolongan, seutas benang merah muncul... | street insert | wrist CU, push | thread draws itself | 14 | none | shimmer |
| 3 | 225-310 | Benang itu lenyap saat utangnya dibalas. | street | MS | neighbour hands back fruit, thread fades | 10 | none | pop |
| 4 | 310-436 | Laras tidak pernah punya benang. Pergelangannya polos sejak kecil. | street | CU bare wrist -> Laras MS (roll) | Laras, bare wrist | 13 | none | low note |
| 5 | 436-690 | Warga menyebutnya si Bersih ... tak pernah mengajaknya bicara lama. | warung | 2-shot; front seat; folk bow and drift away | Laras + 3 folk | 10 | stool | whoosh x2 |
| 6 | 690-744 | Laras bangga. | warung | CU, chin up | Laras proud | 14 | none | — |
| 7 | 744-1010 | Lalu ia memperhatikan sesuatu di pasar. Penjual jeruk ... bukan pembeli. | pasar | wide -> stall MS -> wrist insert | orange seller, buyer; thread on seller | 0/10 | crate | thread shimmer |
| 8 | 1010-1294 | Laras mengujinya ... tetangga, tukang ojek, ibu guru ... tangan penolong. | street, 3 quick set-ups | 3 cuts, one per helper | Laras asks, helper gets thread | 10 | — | pop x3 |
| 9 | 1294-1419 | Padahal sekolah mengajarkan sebaliknya | SD classroom | blackboard MS | teacher + diagram (diegetic sign) | 8 | desk | chalk |
| 10 | 1419-1853 | Laras membuka catatan kelurahan ... Mereka tak pernah sendirian. | kelurahan office | desk CU -> list insert -> crowd of threaded folk | Laras, ledger, busy folk | 12 | ledger | page flips |
| 11 | 1853-2151 | Laras mengerti ... tak ada yang pernah memerlukanmu. | office/street | slow push + roll; sting on last line | Laras alone, folk pass | 14 | — | music stops, low hit |
| 12 | 2151-2336 | Sore itu Laras melilitkan benang ... tangan terangkat. | golden, office -> pasar | CU wrist wrap -> walk | Laras | 8 | — | — |
| 13 | 2336-2506 | Orang-orang menatap ... anak menunjuknya. Ibunya menarik anak itu menjauh. | golden pasar | MS crowd -> child point -> last pull-away lands on final word | Laras, child, mother | 10 | — | final soft thud |
