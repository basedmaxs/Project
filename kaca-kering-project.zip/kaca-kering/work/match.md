# Word -> picture map (id, 53.59 s, 1608 frames)

Frames are at 30 fps. A reaction or graphic starts at the frame in brackets (3 frames before its word).
Hints only: the shot plan and `docs/in-scene-graphics.md` decide what is really drawn (about 1 graphic per 2 shots).

## 1. f0-f104  (3.5 s)
> Dimas datang ke kantor dengan wajah panik saat hujan deras baru saja reda.

## 2. f112-f222  (3.6 s)
> Dia melapor kalau laptop kantor seharga dua puluh juta baru dicuri dari mobilnya.
- [f160] **dua** -> counter / number
- [f168] **puluh** -> counter / number
- [f175] **juta** -> counter / number

## 3. f231-f244  (0.5 s)
> Katanya,

## 4. f250-f313  (2.1 s)
> dia parkir di pinggir jalan selama satu jam.
- [f285] **selama** -> timer / counter (time)
- [f298] **satu** -> counter / number
- [f306] **jam.** -> timer / counter (time)

## 5. f320-f332  (0.4 s)
> Pas balik,

## 6. f337-f407  (2.3 s)
> kaca sampingnya sudah pecah dan tas laptopnya lenyap.

## 7. f418-f452  (1.1 s)
> Biar nggak perlu ganti rugi,

## 8. f457-f550  (3.1 s)
> Dimas langsung menunjukkan foto kaca mobilnya yang pecah berantakan.

## 9. f556-f632  (2.5 s)
> Bosnya hampir percaya dan sudah mau mengurus asuransi.

## 10. f642-f653  (0.4 s)
> Tapi,

## 11. f658-f758  (3.3 s)
> kepala keamanan yang ikut melihat foto itu tiba-tiba tersenyum sinis,
- [f655] **kepala** -> label (role / name)

## 12. f765-f839  (2.4 s)
> lalu menyuruh bosnya memecat Dimas saat itu juga.

## 13. f849-f902  (1.8 s)
> Dimas kaget dan langsung membela diri.

## 14. f913-f1015  (3.4 s)
> Namun, kepala keamanan cuma menunjuk satu detail kecil di foto itu.
- [f918] **kepala** -> label (role / name)
- [f965] **satu** -> counter / number

## 15. f1025-f1092  (2.2 s)
> Kalau kacanya benar-benar pecah saat hujan deras,

## 16. f1100-f1160  (2.0 s)
> seharusnya bagian dalam mobil basah kuyup.
- [f1125] **dalam** -> measuring line (distance / height)

## 17. f1169-f1198  (1.0 s)
> Tapi di foto itu,

## 18. f1206-f1319  (3.8 s)
> jok kulitnya kering total, padahal bodi luar mobil masih penuh tetesan air.
- [f1286] **penuh** -> bar (health / energy / progress)

## 19. f1329-f1433  (3.5 s)
> Artinya, Dimas memecahkan kacanya sendiri setelah hujan berhenti.

## 20. f1443-f1513  (2.3 s)
> Niatnya mau jual laptop kantor dan klaim asuransi,

## 21. f1522-f1595  (2.4 s)
> eh malah ketahuan gara-gara lupa nyiram jok mobil.
