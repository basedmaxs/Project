#!/usr/bin/env python3
"""Word timings for a voiceover -> words.json + phrases.json + match.md.

Usage:
  python3 tools/timing.py voice.mp3 [script.txt] [--out work/] [--lang id|en|auto] [--model small]

Languages: Indonesian (id) and English (en). --lang auto (default) reads it from the script text.
1. If faster-whisper or openai-whisper is importable, transcribe with word timestamps (best). English uses base.en;
   any other language uses the multilingual "small" model (override with --model). The script, if given, is passed to
   Whisper as a prompt and the heard words are snapped to the script's own spelling and punctuation.
2. Otherwise needs the script text: detects speech segments by silence (ffmpeg silencedetect),
   splits the script into phrases at punctuation, and aligns phrases to segments with a DP that
   matches phrase length (syllables, counted per language) to segment duration. Words inside a phrase are spread by syllables.
Always eyeball phrases.json against the audio waveform; hand-fix if a phrase landed in the wrong gap.
match.md lists every phrase with its frames and the words that call for a picture or an in-scene graphic.
"""
import json, re, subprocess, sys, os, difflib

# ---------------------------------------------------------------- language (en | id)
ID_STOP = set("yang dan di ke dari itu ini untuk dengan tidak ada pada mereka adalah akan saya kami kita bisa juga sudah karena tapi atau seperti hanya semua orang satu dua tiga".split())
EN_STOP = set("the and of to a in is that was they he she it for with on as his her this have had not but are were been from at by".split())

def detect_lang(text):
    """'id' or 'en' from a script text (stop-word vote); 'en' if unsure."""
    ws = re.findall(r"[a-z]+", (text or "").lower())
    i = sum(w in ID_STOP for w in ws); e = sum(w in EN_STOP for w in ws)
    return "id" if i > e else "en"

# ---- number words (to estimate how long a digit string takes to say)
_ID1 = "nol satu dua tiga empat lima enam tujuh delapan sembilan sepuluh sebelas".split()
def id_words(n):
    if n < 12: return _ID1[n]
    if n < 20: return id_words(n - 10).replace("satu", "se") + " belas" if n != 11 else "sebelas"
    if n < 100: return id_words(n // 10) + " puluh" + (" " + id_words(n % 10) if n % 10 else "")
    if n < 200: return "seratus" + (" " + id_words(n - 100) if n > 100 else "")
    if n < 1000: return id_words(n // 100) + " ratus" + (" " + id_words(n % 100) if n % 100 else "")
    if n < 2000: return "seribu" + (" " + id_words(n - 1000) if n > 1000 else "")
    if n < 10**6: return id_words(n // 1000) + " ribu" + (" " + id_words(n % 1000) if n % 1000 else "")
    if n < 10**9: return id_words(n // 10**6) + " juta" + (" " + id_words(n % 10**6) if n % 10**6 else "")
    return id_words(n // 10**9) + " miliar" + (" " + id_words(n % 10**9) if n % 10**9 else "")

_EN1 = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
_EN10 = "x x twenty thirty forty fifty sixty seventy eighty ninety".split()
def en_words(n):
    if n < 20: return _EN1[n]
    if n < 100: return _EN10[n // 10] + (" " + _EN1[n % 10] if n % 10 else "")
    if n < 1000: return _EN1[n // 100] + " hundred" + (" " + en_words(n % 100) if n % 100 else "")
    if n < 10**6: return en_words(n // 1000) + " thousand" + (" " + en_words(n % 1000) if n % 1000 else "")
    if n < 10**9: return en_words(n // 10**6) + " million" + (" " + en_words(n % 10**6) if n % 10**6 else "")
    return en_words(n // 10**9) + " billion" + (" " + en_words(n % 10**9) if n % 10**9 else "")

# ---- syllables (timing weight of a word)
def syll_en(w):
    v = re.findall(r"[aeiouy]+", w); n = len(v)
    if w.endswith("e") and n > 1 and not w.endswith("le"): n -= 1
    return max(1, n)

def syll_id(w):
    """Indonesian: every vowel letter is a syllable (e is always pronounced); only the word-final diphthongs ai / au / oi count as one."""
    n = len(re.findall(r"[aeiou]", w))
    if re.search(r"(ai|au|oi)$", w): n -= 1
    return max(1, n)

def syll(w, lang="en"):
    raw = w.lower()
    d = re.sub(r"[^0-9]", "", raw)
    if d:                                            # "199", "2026", "10%": say the number (script should spell numbers out for exact timing)
        try:
            words = (id_words if lang == "id" else en_words)(int(d[:12]))
            n = sum(syll(x, lang) for x in words.split())
            return n + (2 if "%" in raw else 0)
        except ValueError:
            pass
    w = re.sub(r"[^a-z]", "", raw)
    if not w: return 1
    return syll_id(w) if lang == "id" else syll_en(w)

def duration(path):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True).stdout)

def speech_segments(path, db=-35, mind=0.12):
    err = subprocess.run(["ffmpeg", "-i", path, "-af", f"silencedetect=n={db}dB:d={mind}", "-f", "null", "-"], capture_output=True, text=True).stderr
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", err)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", err)]
    D = duration(path); segs = []; cur = 0.0
    for s, e in zip(starts, ends + [D] * (len(starts) - len(ends))):
        if s - cur > 0.08: segs.append([cur, s])
        cur = e
    if D - cur > 0.08: segs.append([cur, D])
    # trim leading silence of first segment if file starts with silence
    return segs, D

def whisper_words(path, lang=None, model=None, prompt=None):
    """Word timestamps from faster-whisper / openai-whisper. lang None = auto-detect. English -> base.en, else multilingual small."""
    model = model or ("base.en" if lang == "en" else "small")
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel(model, compute_type="int8")
        segs, _ = m.transcribe(path, word_timestamps=True, language=lang, initial_prompt=prompt)
        return [{"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)} for s in segs for w in s.words]
    except Exception:
        pass
    try:
        import whisper
        r = whisper.load_model(model).transcribe(path, word_timestamps=True, language=lang, initial_prompt=prompt)
        return [{"w": w["word"].strip(), "s": round(w["start"], 3), "e": round(w["end"], 3)} for s in r["segments"] for w in s["words"]]
    except Exception:
        return None

_norm = lambda t: re.sub(r"[^0-9a-z\u00c0-\u024f]", "", t.lower())

def snap_to_script(words, script):
    """Use the script's own spelling and punctuation for the words Whisper heard (Whisper misspells names and
    Indonesian words). Only 1:1 matches and same-length replacements are swapped; everything else stays as heard.
    Returns (words, match ratio)."""
    st = script.split(); a = [_norm(w["w"]) for w in words]; b = [_norm(t) for t in st]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False); out = [dict(w) for w in words]
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op in ("equal", "replace") and (i2 - i1) == (j2 - j1):
            for k in range(i2 - i1): out[i1 + k]["w"] = st[j1 + k]
    return out, sm.ratio()

# ---------------------------------------------------------------- picture hints (match.md)
# Words that usually call for a picture or an in-scene graphic (docs/in-scene-graphics.md). Hints only: the shot plan decides.
TRIG = {
 "id": [
  ("counter / number", r"^(\d[\d.,]*%?|nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas|\w*belas|\w*puluh|\w*ratus|\w*ribu|\w*juta|\w*miliar|kali|berkali-kali)$"),
  ("measuring line (distance / height)", r"^(meter|kilometer|km|cm|sentimeter|kaki|mil|tinggi|panjang|jarak|lebar|dalam|jauh|ketinggian|ketebalan)$"),
  ("timer / counter (time)", r"^(detik|menit|jam|hari|minggu|bulan|tahun|abad|sejam|semenit|sedetik|selama|hitung)$"),
  ("bar (health / energy / progress)", r"^(persen|energi|tenaga|bahan|baterai|nyawa|progres|kemajuan|penuh|habis)$"),
  ("labels on two things (comparison)", r"^(lebih|paling|daripada|dibanding|dibandingkan|terbesar|tercepat|terbanyak|terkecil|dua|kembar)$"),
  ("arrow (speed / direction)", r"^(kecepatan|cepat|lambat|arah|menuju|mengarah|kecepatannya)$"),
  ("pin / arrow (place / target)", r"^(sini|situ|lihat|tempat|lokasi|titik|target|sasaran|bernama)$"),
  ("label (role / name)", r"^(kapten|jenderal|dokter|raja|ratu|kepala|insinyur|profesor|bernama|dijuluki|disebut)$"),
 ],
 "en": [
  ("counter / number", r"^(\d[\d,.]*%?|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|\w+teen|\w+ty|hundred|thousand|million|billion|times|twice)$"),
  ("measuring line (distance / height)", r"^(meters?|metres?|kilometers?|km|feet|foot|miles?|inches|tall|long|high|wide|deep|distance|away|height)$"),
  ("timer / counter (time)", r"^(seconds?|minutes?|hours?|days?|weeks?|months?|years?|centuries|countdown)$"),
  ("bar (health / energy / progress)", r"^(percent|energy|fuel|battery|health|progress|full|empty)$"),
  ("labels on two things (comparison)", r"^(more|most|than|bigger|biggest|faster|fastest|larger|smaller|twice|both)$"),
  ("arrow (speed / direction)", r"^(speed|fast|slow|toward|towards|direction|mph)$"),
  ("pin / arrow (place / target)", r"^(here|there|look|target|spot|place|location|named|called)$"),
  ("label (role / name)", r"^(captain|general|doctor|king|queen|chief|engineer|professor|named|called|nicknamed)$"),
 ],
}

def picture_hints(words, lang):
    """[(kind, word, frame)] for words that match a trigger; frame = 3 frames before the word (reactions land 0-3 frames early)."""
    out = []
    for w in words:
        t = re.sub(r"^[^\w%]+|[^\w%]+$", "", w["w"].lower())
        for kind, rx in TRIG.get(lang, TRIG["en"]):
            if re.match(rx, t):
                out.append((kind, w["w"], max(0, int(round(w["s"] * 30)) - 3))); break
    return out

def write_match(path, phr, words, lang, D):
    L = [f"# Word -> picture map ({lang}, {D:.2f} s, {int(round(D * 30))} frames)", "",
         "Frames are at 30 fps. A reaction or graphic starts at the frame in brackets (3 frames before its word).",
         "Hints only: the shot plan and `docs/in-scene-graphics.md` decide what is really drawn (about 1 graphic per 2 shots).", ""]
    for i, p in enumerate(phr, 1):
        f0, f1 = int(round(p["s"] * 30)), int(round(p["e"] * 30))
        ws = [w for w in words if p["s"] - 1e-3 <= w["s"] <= p["e"] + 1e-3]
        L.append(f"## {i}. f{f0}-f{f1}  ({p['e'] - p['s']:.1f} s)"); L.append(f"> {p['text']}")
        for kind, w, f in picture_hints(ws, lang): L.append(f"- [f{f}] **{w}** -> {kind}")
        L.append("")
    open(path, "w", encoding="utf-8").write("\n".join(L))

def align(script, segs, lang="en"):
    # phrases: split after , . ; : ! ? and closing quotes
    raw = re.findall(r"[^,.;:!?]+[,.;:!?\"”']*", script.replace("\n", " "))
    phrases = [p.strip() for p in raw if p.strip()]
    P, S = len(phrases), len(segs)
    syl = [sum(syll(w, lang) for w in p.split()) for p in phrases]
    tot_syl = sum(syl); tot_dur = sum(e - s for s, e in segs); rate = tot_syl / tot_dur
    import functools
    INF = 1e9
    # dp over (phrase i, segment j): segment j holds phrases [i..k); a phrase may also span several segments (merge)
    @functools.lru_cache(None)
    def best(i, j):
        if i == P and j == S: return (0.0, ())
        if i == P or j == S: return (INF, ())
        out = (INF, ())
        for k in range(i + 1, min(P, i + 4) + 1):          # 1-3 phrases into one segment
            for l in range(j + 1, min(S, j + 3) + 1):      # or one group across 1-2 segments
                if k - i > 1 and l - j > 1: continue
                d = segs[l - 1][1] - segs[j][0]; s_ = sum(syl[i:k]) / rate
                cost = (d - s_) ** 2 / max(d, 0.3)
                # a sentence end inside a segment is unlikely (speakers pause there); a long gap inside one phrase too
                cost += sum(0.35 for m in range(i, k - 1) if re.search(r"[.!?][\"”']?$", phrases[m]))
                cost += sum(1.5 * (segs[m + 1][0] - segs[m][1]) for m in range(j, l - 1))
                sub = best(k, l)
                if sub[0] + cost < out[0]: out = (sub[0] + cost, ((i, k, j, l),) + sub[1])
        return out
    cost, plan = best(0, 0)
    words, phr = [], []
    for i, k, j, l in plan:
        a, b = segs[j][0], segs[l - 1][1]
        text = " ".join(phrases[i:k]); ws = text.split(); sy = [syll(w, lang) for w in ws]; T = sum(sy); t = a
        phr.append({"text": text, "s": round(a, 3), "e": round(b, 3)})
        for w, s_ in zip(ws, sy):
            d = (b - a) * s_ / T; words.append({"w": w, "s": round(t, 3), "e": round(t + d, 3)}); t += d
    return words, phr, cost

if __name__ == "__main__":
    opt = lambda n, d=None: sys.argv[sys.argv.index(n) + 1] if n in sys.argv else d
    flagvals = {sys.argv[i + 1] for i, x in enumerate(sys.argv[:-1]) if x in ("--out", "--lang", "--model")}
    args = [a for a in sys.argv[1:] if not a.startswith("--") and a not in flagvals]
    out = opt("--out", "."); os.makedirs(out, exist_ok=True)
    audio = args[0]; script = open(args[1], encoding="utf-8").read() if len(args) > 1 and os.path.exists(args[1]) else (args[1] if len(args) > 1 else None)
    lang = opt("--lang", "auto")
    if lang == "auto": lang = detect_lang(script) if script else None
    words = whisper_words(audio, lang, opt("--model"), (script or "")[:500] or None)
    lang = lang or "en"                                   # syllable rules when Whisper had to detect the language itself
    segs, D = speech_segments(audio)
    note = ""
    if words:
        if script:
            words, ratio = snap_to_script(words, script); note = f", script match {ratio:.0%}"
            if ratio < 0.5: print(f"WARNING: only {ratio:.0%} of the heard words match the script: wrong --lang, wrong script or a noisy recording. Check words.json.")
        phr = []; cur = []
        for w in words:
            cur.append(w)
            if re.search(r"[,.;:!?]$", w["w"]): phr.append({"text": " ".join(x["w"] for x in cur), "s": cur[0]["s"], "e": cur[-1]["e"]}); cur = []
        if cur: phr.append({"text": " ".join(x["w"] for x in cur), "s": cur[0]["s"], "e": cur[-1]["e"]})
        src = "whisper"
    elif script:
        words, phr, cost = align(script, segs, lang); src = f"silence-align (cost {cost:.2f})"
    else:
        print("NO_ASR: no whisper available and no script given. Ask the user for the script text (or install faster-whisper)."); sys.exit(2)
    for w in words: w["f"] = int(round(w["s"] * 30))
    json.dump(words, open(os.path.join(out, "words.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    json.dump({"duration": D, "frames30": int(round(D * 30)), "lang": lang, "source": src, "segments": segs, "phrases": phr}, open(os.path.join(out, "phrases.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    write_match(os.path.join(out, "match.md"), phr, words, lang, D)
    print(f"source={src}{note} lang={lang} duration={D:.2f}s frames={int(round(D*30))}")
    for p in phr: print(f"{p['s']:6.2f}-{p['e']:6.2f}  f{int(p['s']*30):4d}-{int(p['e']*30):4d}  {p['text']}")
    print(f"-> {out}/words.json, phrases.json, match.md")
