# Render Kaca Kering di GitHub Actions

1. Buat repository baru di GitHub (public = gratis tanpa batas menit; private = pakai jatah menit bulanan).
2. Upload SEMUA isi folder ini ke repository (termasuk folder tersembunyi `.github`):
   - di HP/web: Add file -> Upload files (pastikan `.github/workflows/render.yml` ikut), atau
   - di komputer: `git init && git add -A && git commit -m init && git remote add origin <URL> && git push -u origin main`
3. Buka tab **Actions** -> workflow **render** -> **Run workflow**:
   - title: `Kaca Kering`
   - chunk: `81` (1608 frame / 81 = 20 job sekaligus, sekitar 15-30 menit)
   - total: kosongkan (isi `60` kalau mau uji coba cepat dulu)
4. Setelah selesai, unduh artifact **final-video** (isi: `Kaca-Kering.mp4` + `qa_sheet.jpg`).

Teks kata-per-kata sudah otomatis dipasang di tiap job. Audio memakai `mix_final.wav` (sudah ada di repo).
Catatan: syarat penggunaan GitHub Actions membatasi penggunaan untuk proyek perangkat lunak; render video dari repo adalah area abu-abu, jadi pakai seperlunya saja.
