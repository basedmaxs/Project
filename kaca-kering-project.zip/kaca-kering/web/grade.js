import { Effect, BlendFunction } from "postprocessing";
import { Uniform, Vector3, Vector2 } from "three";
const frag = `
uniform float gradeKy[7];
uniform float gradeKm[7];
uniform vec3 gradeSat;      // x = shadows, y = mids, z = highlights
uniform vec3 gradeTintS;    // zero-luma RGB offsets (sRGB-encoded units)
uniform vec3 gradeTintM;
uniform vec3 gradeTintH;
uniform vec2 gradeVig;      // x = strength k, y = start radius r0
uniform float gradeAmount;

vec3 gradeEncode(vec3 c) {   // linear -> sRGB
  c = clamp(c, 0.0, 1.0);
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}
vec3 gradeDecode(vec3 c) {   // sRGB -> linear
  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}
float gradeHermite(float v, float x0, float x1, float y0, float y1, float m0, float m1) {
  float h = x1 - x0, t = (v - x0) / h, t2 = t * t, t3 = t2 * t;
  return (2.0 * t3 - 3.0 * t2 + 1.0) * y0 + (t3 - 2.0 * t2 + t) * h * m0 + (-2.0 * t3 + 3.0 * t2) * y1 + (t3 - t2) * h * m1;
}
float gradeCurve(float v) {
  v = clamp(v, 0.0, 1.0);
  if (v < 0.1)  return gradeHermite(v, 0.0, 0.1, gradeKy[0], gradeKy[1], gradeKm[0], gradeKm[1]);
  if (v < 0.25) return gradeHermite(v, 0.1, 0.25, gradeKy[1], gradeKy[2], gradeKm[1], gradeKm[2]);
  if (v < 0.5)  return gradeHermite(v, 0.25, 0.5, gradeKy[2], gradeKy[3], gradeKm[2], gradeKm[3]);
  if (v < 0.75) return gradeHermite(v, 0.5, 0.75, gradeKy[3], gradeKy[4], gradeKm[3], gradeKm[4]);
  if (v < 0.9)  return gradeHermite(v, 0.75, 0.9, gradeKy[4], gradeKy[5], gradeKm[4], gradeKm[5]);
  return gradeHermite(v, 0.9, 1.0, gradeKy[5], gradeKy[6], gradeKm[5], gradeKm[6]);
}

void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  vec3 src = gradeEncode(inputColor.rgb);
  vec3 c = vec3(gradeCurve(src.r), gradeCurve(src.g), gradeCurve(src.b));
  const vec3 W = vec3(0.2126, 0.7152, 0.0722);
  float y = dot(c, W);
  float wS = 1.0 - smoothstep(0.0, 0.55, y);
  float wH = smoothstep(0.45, 1.0, y);
  float wM = 1.0 - wS - wH;
  float s = gradeSat.y + (gradeSat.x - gradeSat.y) * wS + (gradeSat.z - gradeSat.y) * wH;
  c = vec3(y) + s * (c - vec3(y));
  c += wS * gradeTintS + wM * gradeTintM + wH * gradeTintH;
  vec2 p = uv * 2.0 - 1.0;
  float r = length(p) * 0.70710678;
  c *= 1.0 - gradeVig.x * smoothstep(gradeVig.y, 1.0, r);
  c = clamp(c, 0.0, 1.0);
  outputColor = vec4(gradeDecode(mix(src, c, gradeAmount)), inputColor.a);
}`;
const E_CB = [
    0.0,
    -0.18733,
    1.8556
];
const E_CR = [
    1.5748,
    -0.46813,
    0.0
];
export const tintRGB = (cb, cr)=>new Vector3(cb * E_CB[0] + cr * E_CR[0], cb * E_CB[1] + cr * E_CR[1], cb * E_CB[2] + cr * E_CR[2]);
export const KX = [
    0,
    0.1,
    0.25,
    0.5,
    0.75,
    0.9,
    1
];
export function monoTangents(ky) {
    const n = KX.length, h = [], d = [], m = new Array(n).fill(0);
    for(let k = 0; k < n - 1; k++){
        h.push(KX[k + 1] - KX[k]);
        d.push((ky[k + 1] - ky[k]) / h[k]);
    }
    m[0] = d[0];
    m[n - 1] = d[n - 2];
    for(let k = 1; k < n - 1; k++){
        if (d[k - 1] * d[k] <= 0) {
            m[k] = 0;
            continue;
        }
        const w1 = 2 * h[k] + h[k - 1], w2 = h[k] + 2 * h[k - 1];
        m[k] = (w1 + w2) / (w1 / d[k - 1] + w2 / d[k]);
    }
    return m;
}
export const GRADE_DAY = {
    ky: [
        0.0345,
        0.1828,
        0.3812,
        0.6605,
        0.8814,
        0.9631,
        1
    ],
    sat: [
        0.9831,
        1.2727,
        1.4573
    ],
    tintS: [
        -0.0291,
        0.0411
    ],
    tintM: [
        0.0376,
        -0.0104
    ],
    tintH: [
        0.0144,
        -0.0047
    ],
    vig: [
        0.1,
        0.45
    ]
};
export const GRADE_GOLDEN = {
    ky: [
        0.0311,
        0.1877,
        0.4017,
        0.6754,
        0.875,
        0.9582,
        1
    ],
    sat: [
        0.8316,
        0.8799,
        1.7061
    ],
    tintS: [
        0.0528,
        0.0004
    ],
    tintM: [
        0.0583,
        -0.0003
    ],
    tintH: [
        0,
        0
    ],
    vig: [
        0.16,
        0.4
    ]
};
export class GradeEffect extends Effect {
    constructor(p, amount = 1){
        super("GradeEffect", frag, {
            blendFunction: BlendFunction.NORMAL,
            uniforms: new Map([
                [
                    "gradeKy",
                    new Uniform(p.ky.slice())
                ],
                [
                    "gradeKm",
                    new Uniform(monoTangents(p.ky))
                ],
                [
                    "gradeSat",
                    new Uniform(new Vector3(...p.sat))
                ],
                [
                    "gradeTintS",
                    new Uniform(tintRGB(...p.tintS))
                ],
                [
                    "gradeTintM",
                    new Uniform(tintRGB(...p.tintM))
                ],
                [
                    "gradeTintH",
                    new Uniform(tintRGB(...p.tintH))
                ],
                [
                    "gradeVig",
                    new Uniform(new Vector2(...p.vig))
                ],
                [
                    "gradeAmount",
                    new Uniform(amount)
                ]
            ])
        });
    }
    set(p, q, t = 0) {
        const L = (a, b)=>a + (b - a) * t;
        const r = q ? {
            ky: p.ky.map((v, i)=>L(v, q.ky[i])),
            sat: [
                L(p.sat[0], q.sat[0]),
                L(p.sat[1], q.sat[1]),
                L(p.sat[2], q.sat[2])
            ],
            tintS: [
                L(p.tintS[0], q.tintS[0]),
                L(p.tintS[1], q.tintS[1])
            ],
            tintM: [
                L(p.tintM[0], q.tintM[0]),
                L(p.tintM[1], q.tintM[1])
            ],
            tintH: [
                L(p.tintH[0], q.tintH[0]),
                L(p.tintH[1], q.tintH[1])
            ],
            vig: [
                L(p.vig[0], q.vig[0]),
                L(p.vig[1], q.vig[1])
            ]
        } : p;
        const u = this.uniforms;
        u.get("gradeKy").value = r.ky.slice();
        u.get("gradeKm").value = monoTangents(r.ky);
        u.get("gradeSat").value.set(...r.sat);
        u.get("gradeTintS").value = tintRGB(...r.tintS);
        u.get("gradeTintM").value = tintRGB(...r.tintM);
        u.get("gradeTintH").value = tintRGB(...r.tintH);
        u.get("gradeVig").value.set(...r.vig);
    }
    get amount() {
        return this.uniforms.get("gradeAmount").value;
    }
    set amount(v) {
        this.uniforms.get("gradeAmount").value = v;
    }
}
export const GRADE_DAY2 = {
    ky: [
        0,
        0.1,
        0.28,
        0.6,
        0.835,
        0.945,
        1
    ],
    sat: [
        1.0,
        1.05,
        1.0
    ],
    tintS: [
        0.01,
        0.002
    ],
    tintM: [
        0,
        0
    ],
    tintH: [
        0.006,
        0
    ],
    vig: [
        0.12,
        0.45
    ]
};
export const GRADE_GOLDEN2 = {
    ky: [
        0,
        0.09,
        0.245,
        0.54,
        0.8,
        0.93,
        1
    ],
    sat: [
        1.0,
        1.12,
        1.15
    ],
    tintS: [
        0.02,
        0.002
    ],
    tintM: [
        0,
        0
    ],
    tintH: [
        -0.012,
        0.006
    ],
    vig: [
        0.2,
        0.4
    ]
};
export const GRADES = {
    day: GRADE_DAY2,
    golden: GRADE_GOLDEN2,
    rain: GRADE_DAY2
};
export const GRADE_STRENGTH = {
    day: 1,
    golden: 1,
    rain: 1
};
export function gradeFor(fx, light) {
    const tag = fx;
    if (tag._light !== light) {
        fx.set(GRADES[light]);
        tag._light = light;
    }
    fx.amount = GRADE_STRENGTH[light];
}
