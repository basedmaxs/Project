// Browser entry: one frame = window.renderFrame(f) painted into <canvas id="c"> (1080x1920).
// The render method is unchanged from stickman v2 (tools/render.mjs calls renderFrame, reads the canvas as JPEG).
// Look = the animated-shorts "bridge" look, ported from React Three Fiber / Remotion to plain three.js:
//   World (story layer) -> InkPass -> [bloom + NEUTRAL tone map + grade], MSAA 4. No lens blur / depth of field: everything is sharp.
// Two render slots exist so a place change can crossfade (layersAt(f) returns 1 or 2 layers); slot 0 is the base.
// URL hash flags for A/B stills (render.mjs: HASH="#noink,nobloom"): noink nobloom nograde grain.
import * as THREE from 'three';
import { EffectComposer, RenderPass, EffectPass, BloomEffect, ToneMappingEffect, ToneMappingMode, BlendFunction } from 'postprocessing';
import { World, loadKit } from './world.js';
import { InkPass, noInkFallback } from './ink.js';
import { GrainEffect } from './grain.js';
import { GradeEffect, GRADES, GRADE_STRENGTH, gradeFor } from './grade.js';
import { TOTAL, FLASH_AT, SHOTS, layersAt } from './story.js';

const W = 1080, H = 1920;
const FLAGS = new Set((location.hash || '').replace('#', '').split(',').filter(Boolean));
const on = { ink: !FLAGS.has('noink'), bloom: !FLAGS.has('nobloom'), grade: !FLAGS.has('nograde'), grain: FLAGS.has('grain') };

// Bloom for emissive sources only: its MIP chain always starts at 540x960 so the glow keeps its size at any output size.
const makeBloom = () => {
  const b = new BloomEffect({ blendFunction: BlendFunction.ADD, intensity: 0.5, luminanceThreshold: 1.0, luminanceSmoothing: 0.2, mipmapBlur: true, levels: 6, radius: 0.6 });
  const mip = b.mipmapBlurPass; const setSize = mip.setSize.bind(mip);
  mip.setSize = (w, h) => setSize(Math.round((1920 * w) / Math.max(h, 1)), 1920);
  return b;
};

class Slot {
  constructor(kit) {
    this.canvas = document.createElement('canvas'); this.canvas.width = W; this.canvas.height = H;
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: false, stencil: false, powerPreference: 'high-performance' });
    const r = this.renderer;
    r.setPixelRatio(1); r.setSize(W, H, false);
    r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.NoToneMapping; r.toneMappingExposure = 1.0;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(40, W / H, 0.2, 1500);
    this.world = new World(kit);
    this.scene.add(this.world.root);
    this.target = new THREE.Vector3();
    this.fx = {
      ink: new InkPass(this.scene, this.camera),
      bloom: makeBloom(),
      tone: new ToneMappingEffect({ mode: ToneMappingMode.NEUTRAL }),
      grade: new GradeEffect(GRADES.day, GRADE_STRENGTH.day),
      grain: new GrainEffect({ amount: 0.025, cellPx: 1.5 }), // OFF by default: the reference has no grain and it quadruples the file size
    };
    const c = this.composer = new EffectComposer(r, { multisampling: 4 });
    c.setSize(W, H, false);
    c.addPass(new RenderPass(this.scene, this.camera));
    if (on.ink) c.addPass(this.fx.ink);
    const tail = [];
    if (on.bloom) tail.push(this.fx.bloom);
    tail.push(this.fx.tone);
    if (on.grade) tail.push(this.fx.grade);
    if (on.grain) tail.push(this.fx.grain);
    c.addPass(new EffectPass(this.camera, ...tail));
  }
  draw(id, f) {
    const cam = this.camera, fx = this.fx;
    this.target.copy(this.world.update(id, f, cam, this.scene));
    noInkFallback(this.world.root);
    gradeFor(fx.grade, SHOTS[id - 1].light);
    fx.grain.seed = f;                        // deterministic per frame
    this.composer.render(1 / 30);
    return this.canvas;
  }
}

const out = document.getElementById('c'), g2 = out.getContext('2d');
let slots = [];
window.err = null;
const boot = async () => {
  const kit = await loadKit();                // optional CC0 props (web/kenney/*.glb); the look works without them
  slots = [new Slot(kit)];
  window.renderFrame = (f) => {
    const layers = layersAt(f);
    while (slots.length < layers.length) slots.push(new Slot(kit));
    g2.globalAlpha = 1; g2.fillStyle = '#cfe3f2'; g2.fillRect(0, 0, W, H);
    layers.forEach((l, i) => { const cv = slots[i].draw(l.id, f); g2.globalAlpha = l.alpha; g2.drawImage(cv, 0, 0, W, H); });
    const flash = f >= FLASH_AT && f < FLASH_AT + 4 ? [1, 0.75, 0.45, 0.2][f - FLASH_AT] : 0;   // white flash after the hook
    if (flash > 0) { g2.globalAlpha = flash; g2.fillStyle = '#fff'; g2.fillRect(0, 0, W, H); }
    g2.globalAlpha = 1;
    return true;
  };
  window.TOTAL = TOTAL;
  window.ready = true;
};
boot().catch((e) => { window.err = String(e && e.stack || e); console.log('BOOT ERROR', window.err); });
