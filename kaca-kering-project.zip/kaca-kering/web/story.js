export const FPS = 30;
export const TOTAL = 1608;
export const D0 = 0;
export const clamp01 = (x)=>Math.max(0, Math.min(1, x));
export const smooth = (x)=>{
    const u = clamp01(x);
    return u * u * (3 - 2 * u);
};
export const easeOut = (u)=>1 - (1 - clamp01(u)) ** 4;
export const SHOTS = [
    {
        id: 1,
        a: 0,
        b: 112,
        light: "rain",
        place: "office"
    },
    {
        id: 2,
        a: 112,
        b: 230,
        light: "rain",
        place: "office"
    },
    {
        id: 3,
        a: 230,
        b: 337,
        light: "rain",
        place: "street"
    },
    {
        id: 4,
        a: 337,
        b: 417,
        light: "day",
        place: "street"
    },
    {
        id: 5,
        a: 417,
        b: 556,
        light: "day",
        place: "office"
    },
    {
        id: 6,
        a: 556,
        b: 656,
        light: "day",
        place: "office"
    },
    {
        id: 7,
        a: 656,
        b: 849,
        light: "day",
        place: "office"
    },
    {
        id: 8,
        a: 849,
        b: 1025,
        light: "day",
        place: "office"
    },
    {
        id: 9,
        a: 1025,
        b: 1169,
        light: "rain",
        place: "street"
    },
    {
        id: 10,
        a: 1169,
        b: 1329,
        light: "day",
        place: "street"
    },
    {
        id: 11,
        a: 1329,
        b: 1443,
        light: "day",
        place: "street"
    },
    {
        id: 12,
        a: 1443,
        b: 1522,
        light: "day",
        place: "street"
    },
    {
        id: 13,
        a: 1522,
        b: TOTAL,
        light: "day",
        place: "street"
    }
];
export const XFADE = {
    3: 6,
    5: 6,
    9: 6,
    11: 6
};
export const FLASH_AT = 99999;
export const shotAt = (f)=>SHOTS.find((s)=>f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f)=>{
    for (const s of SHOTS){
        const x = XFADE[s.id];
        if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [
            {
                id: s.id - 1,
                alpha: 1
            },
            {
                id: s.id,
                alpha: (f - (s.a - x / 2) + 1) / (x + 1)
            }
        ];
    }
    return [
        {
            id: shotAt(f).id,
            alpha: 1
        }
    ];
};
export const FACADE_Z = -9;
export const CURB_Z = -3.2;
export const CAR = [
    36,
    0,
    -2.2
];
export const WIN_X = 35.65;
export const WIN_W = 1.1;
export const WIN_Y0 = 1.0, WIN_Y1 = 1.38;
export const SMASH = 1358;
export const winBroken = (id, f)=>id === 11 ? f >= SMASH : id >= 4 && id !== 3;
export const glide = (u)=>{
    const x = clamp01(u);
    return x * x * x * (x * (6 * x - 15) + 10);
};
const mix = (a, b, k)=>({
        pos: a.pos.map((v, i)=>v + (b.pos[i] - v) * k),
        look: a.look.map((v, i)=>v + (b.look[i] - v) * k),
        fov: a.fov + (b.fov - a.fov) * k,
        roll: a.roll + (b.roll - a.roll) * k
    });
const full = (c)=>({
        fov: 40,
        roll: 0,
        ...c
    });
const run = (keys, f)=>{
    let cur = full(keys[0].s(f));
    for(let i = 1; i < keys.length; i++){
        const k = keys[i];
        if (f < k.f) break;
        cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
    }
    return cur;
};
const T = (f)=>f / FPS;
const pushK = (f, f0, rate, punch = 0, n = 35)=>{
    const x = Math.max(0, f - f0);
    let s = rate * x;
    if (punch > rate) for(let i = 0; i < Math.min(x, n); i++)s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
    return Math.exp(-s);
};
const dolly = (pos, look, k, rest = {})=>({
        pos: [
            look[0] + (pos[0] - look[0]) * k,
            look[1] + (pos[1] - look[1]) * k,
            look[2] + (pos[2] - look[2]) * k
        ],
        look,
        ...rest
    });
const rolled = (s, roll)=>(f)=>({
            ...s(f),
            roll
        });
export const OFF = {
    dimas: -1.25,
    boss: 0.15,
    chief: 1.5,
    z: -6.0
};
const S1a = (f)=>dolly([
        0,
        1.55,
        0.4
    ], [
        0,
        1.4,
        -6.5
    ], pushK(f, 0, 0.0025), {
        fov: 42
    });
const S1b = (f)=>dolly([
        -0.1,
        1.5,
        -1.6
    ], [
        0,
        1.5,
        -5
    ], pushK(f, 60, 0.002), {
        fov: 36
    });
const S2a = (f)=>dolly([
        0,
        1.5,
        -0.9
    ], [
        0,
        1.6,
        -6
    ], pushK(f, 112, 0.002), {
        fov: 38
    });
const S3a = (f)=>dolly([
        31.5,
        1.5,
        4.5
    ], [
        35.5,
        1.1,
        -2.2
    ], pushK(f, 230, 0.0018), {
        fov: 42
    });
const S3b = (f)=>dolly([
        33.5,
        1.45,
        3.2
    ], [
        36,
        1.3,
        -2.2
    ], pushK(f, 288, 0.002), {
        fov: 38
    });
const S4a = (f)=>dolly([
        36.3,
        1.45,
        3.4
    ], [
        36.3,
        1.2,
        -2.0
    ], pushK(f, 337, 0.0022), {
        fov: 52
    });
const S4b = (f)=>dolly([
        35.8,
        1.25,
        2.1
    ], [
        35.7,
        1.1,
        -2.1
    ], pushK(f, 381, 0.002, 0.005, 30), {
        fov: 34,
        roll: 0.03
    });
const S5a = (f)=>dolly([
        0.3,
        1.5,
        0.5
    ], [
        0.1,
        1.5,
        -6
    ], pushK(f, 417, 0.002), {
        fov: 46
    });
const S5b = (f)=>dolly([
        -0.2,
        1.5,
        -1.2
    ], [
        -0.8,
        1.5,
        -6
    ], pushK(f, 490, 0.002), {
        fov: 38
    });
const S6a = (f)=>dolly([
        0.7,
        1.55,
        -1.4
    ], [
        0.15,
        1.55,
        -6.1
    ], pushK(f, 556, 0.0025), {
        fov: 34
    });
const S7a = (f)=>dolly([
        1.9,
        1.6,
        -1.5
    ], [
        1.5,
        1.6,
        -6.1
    ], pushK(f, 656, 0.0025), {
        fov: 32
    });
const S7b = (f)=>dolly([
        1.9,
        1.65,
        -3.4
    ], [
        1.5,
        1.65,
        -6.1
    ], pushK(f, 723, 0.003), {
        fov: 28
    });
const S7c = (f)=>dolly([
        0.3,
        1.5,
        0.5
    ], [
        0.2,
        1.55,
        -6
    ], pushK(f, 765, 0.0022, 0.005, 30), {
        fov: 46,
        roll: -0.035
    });
const S8a = (f)=>dolly([
        -0.7,
        1.55,
        -1.0
    ], [
        -1.25,
        1.55,
        -6
    ], pushK(f, 849, 0.0028), {
        fov: 34
    });
const S8b = (f)=>dolly([
        0.75,
        1.6,
        -1.5
    ], [
        0.75,
        1.6,
        -6
    ], pushK(f, 913, 0.002), {
        fov: 38
    });
const S9a = (f)=>dolly([
        34.6,
        1.45,
        2.8
    ], [
        35.7,
        1.1,
        -2.3
    ], pushK(f, 1025, 0.0018), {
        fov: 38,
        roll: -0.03
    });
const S9b = (f)=>dolly([
        35.4,
        1.3,
        1.7
    ], [
        35.65,
        1.05,
        -2.2
    ], pushK(f, 1100, 0.002, 0.006, 32), {
        fov: 32
    });
const S10a = (f)=>dolly([
        35.9,
        1.3,
        2.6
    ], [
        35.9,
        1.05,
        -2.0
    ], pushK(f, 1169, 0.0018), {
        fov: 40
    });
const S10b = (f)=>dolly([
        36.2,
        0.9,
        2.2
    ], [
        36.4,
        0.75,
        -2.0
    ], pushK(f, 1270, 0.0022), {
        fov: 38,
        roll: 0.03
    });
const S11a = (f)=>dolly([
        36.2,
        1.45,
        2.6
    ], [
        36.4,
        1.3,
        -2.0
    ], pushK(f, 1329, 0.002), {
        fov: 46
    });
const S11b = (f)=>dolly([
        36.9,
        1.5,
        1.2
    ], [
        37.0,
        1.5,
        -1.0
    ], pushK(f, 1397, 0.002), {
        fov: 34,
        roll: -0.03
    });
const S12a = (f)=>dolly([
        36.2,
        1.8,
        4.6
    ], [
        36.2,
        1.7,
        -0.6
    ], pushK(f, 1443, 0.0015), {
        fov: 44
    });
const S13a = (f)=>dolly([
        36.3,
        1.6,
        4.2
    ], [
        36.3,
        1.45,
        -0.6
    ], pushK(f, 1522, 0.0015), {
        fov: 42
    });
const S13b = (f)=>dolly([
        35.35,
        1.2,
        0.5
    ], [
        35.65,
        1.0,
        -2.0
    ], pushK(f, 1583, 0.0012), {
        fov: 26
    });
const CAMS = {
    1: [
        {
            f: 0,
            s: S1a
        },
        {
            f: 60,
            dur: 30,
            s: S1b
        }
    ],
    2: [
        {
            f: 112,
            s: S2a
        }
    ],
    3: [
        {
            f: 230,
            s: S3a
        },
        {
            f: 288,
            dur: 30,
            s: S3b
        }
    ],
    4: [
        {
            f: 337,
            s: S4a
        },
        {
            f: 381,
            dur: 22,
            s: S4b
        }
    ],
    5: [
        {
            f: 417,
            s: S5a
        },
        {
            f: 490,
            dur: 26,
            s: S5b
        }
    ],
    6: [
        {
            f: 556,
            s: S6a
        }
    ],
    7: [
        {
            f: 656,
            s: S7a
        },
        {
            f: 723,
            cut: true,
            s: S7b
        },
        {
            f: 765,
            cut: true,
            s: S7c
        },
        {
            f: 765,
            dur: 20,
            s: rolled(S7c, 0.035)
        }
    ],
    8: [
        {
            f: 849,
            s: S8a
        },
        {
            f: 913,
            cut: true,
            s: S8b
        }
    ],
    9: [
        {
            f: 1025,
            s: S9a
        },
        {
            f: 1100,
            dur: 30,
            s: S9b
        }
    ],
    10: [
        {
            f: 1169,
            s: S10a
        },
        {
            f: 1270,
            dur: 24,
            s: S10b
        }
    ],
    11: [
        {
            f: 1329,
            s: S11a
        },
        {
            f: 1397,
            dur: 30,
            s: S11b
        }
    ],
    12: [
        {
            f: 1443,
            s: S12a
        }
    ],
    13: [
        {
            f: 1522,
            s: S13a
        },
        {
            f: 1583,
            cut: true,
            s: S13b
        }
    ]
};
const KICKS = [
    [
        SMASH / FPS,
        1.1
    ],
    [
        806 / FPS,
        0.5
    ],
    [
        1590 / FPS,
        0.4
    ]
];
export const kickAt = (t)=>{
    let a = 0;
    for (const [t0, g] of KICKS){
        const n = Math.floor((t - t0) * FPS + 1e-6);
        if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
    }
    return a;
};
export const camAt = (id, f)=>{
    const c = run(CAMS[id], f), a = kickAt(T(f));
    if (!a) return c;
    const d = [
        c.look[0] - c.pos[0],
        c.look[1] - c.pos[1],
        c.look[2] - c.pos[2]
    ];
    const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
    const m = 3 / 640 * Math.tan(c.fov * Math.PI / 360) * L * a;
    return {
        ...c,
        look: [
            c.look[0] - d[2] / h * m,
            c.look[1] + 0.6 * m,
            c.look[2] + d[0] / h * m
        ],
        roll: c.roll + a * 0.004
    };
};
export const keyEnd = (id, f)=>{
    let e = 0;
    for (const k of CAMS[id])if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
    return Math.max(f, e);
};
export const FOREGROUND = [];
