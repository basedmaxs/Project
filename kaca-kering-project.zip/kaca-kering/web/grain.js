import { Effect, BlendFunction } from "postprocessing";
import { Uniform } from "three";
const grainFrag = `
uniform float seed;      // frame number
uniform float amount;    // std of the grain in display units (0.025 = 2.5 %)
uniform float cellPx;    // grain cell size in px at 1080x1920
uint pcg(uint v) { uint s = v * 747796405u + 2891336453u; uint w = ((s >> ((s >> 28u) + 4u)) ^ s) * 277803737u; return (w >> 22u) ^ w; }
float h3(ivec2 c, uint k) { return float(pcg(uint(c.x) + pcg(uint(c.y) + pcg(k)))) * (1.0 / 4294967295.0) - 0.5; }
void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  vec2 p = uv * resolution / (cellPx * resolution.y / 1920.0);
  ivec2 i = ivec2(floor(p)); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  uint k = uint(seed + 0.5) * 2654435761u + 1013904223u;
  float n = mix(mix(h3(i, k), h3(i + ivec2(1, 0), k), f.x), mix(h3(i + ivec2(0, 1), k), h3(i + ivec2(1, 1), k), f.x), f.y);
  vec3 g = pow(max(inputColor.rgb, 0.0), vec3(1.0 / 2.2));             // display-like space
  float l = dot(g, vec3(0.2126, 0.7152, 0.0722));
  float w = 0.25 + 0.75 * clamp(4.0 * l * (1.0 - l), 0.0, 1.0);      // less grain in deep black and near white
  g = max(g + n * (amount / 0.2145) * w, 0.0);                        // 0.2145 = std of the smoothed lattice noise
  outputColor = vec4(pow(g, vec3(2.2)), inputColor.a);
}`;
export class GrainEffect extends Effect {
    constructor({ amount = 0.025, cellPx = 1.5 } = {}){
        super("GrainEffect", grainFrag, {
            blendFunction: BlendFunction.NORMAL,
            uniforms: new Map([
                [
                    "seed",
                    new Uniform(0)
                ],
                [
                    "amount",
                    new Uniform(amount)
                ],
                [
                    "cellPx",
                    new Uniform(cellPx)
                ]
            ])
        });
    }
    set seed(v) {
        this.uniforms.get("seed").value = v;
    }
    set amount(v) {
        this.uniforms.get("amount").value = v;
    }
}
