import * as THREE from "three";
import { Pen, bodyFront, bodySide, INK, SKINS, fxBurst, fxRing, fxContact, fxShadow, fxStars } from "./toon.js";
import { FPS, smooth, clamp01, CAR, WIN_X, WIN_Y0, WIN_Y1, WIN_W, SMASH, winBroken, OFF, SHOTS } from "./story.js";
import { LIGHTS } from "./lights.js";
import { NOINK } from "./ink.js";
import { cardShade, blobMaterial, CARD_K } from "./cardshade.js";
const makeEntry = (w, h)=>{
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return {
        cv,
        tex,
        w,
        h
    };
};
export class Pool {
    live = new Map();
    free = [];
    reqs = [];
    req(key, w, h, k, draw) {
        const r = {
            key: `${w}x${h}|${key}`,
            w,
            h,
            k,
            draw
        };
        this.reqs.push(r);
        return r;
    }
    flush() {
        const want = new Map();
        for (const r of this.reqs){
            const l = want.get(r.key);
            if (l) l.push(r);
            else want.set(r.key, [
                r
            ]);
        }
        for (const [key, e] of this.live)if (!want.has(key)) {
            this.live.delete(key);
            this.free.push(e);
        }
        for (const [key, rs] of want){
            let e = this.live.get(key);
            if (!e) {
                const r = rs[0], i = this.free.findIndex((x)=>x.w === r.w && x.h === r.h);
                e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
                const g = e.cv.getContext("2d");
                g.setTransform(1, 0, 0, 1, 0, 0);
                g.clearRect(0, 0, e.w, e.h);
                g.setTransform(r.k, 0, 0, r.k, 0, 0);
                r.draw(new Pen(g));
                e.tex.needsUpdate = true;
                this.live.set(key, e);
            }
            for (const r of rs)r.tex = e.tex;
        }
        this.reqs = [];
    }
}
const blank = (()=>{
    const c = document.createElement("canvas");
    c.width = c.height = 2;
    return new THREE.CanvasTexture(c);
})();
export const SU = 0.00216;
export const SU_SWING = 2.3 / 1830;
const BODY = (()=>{
    const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU);
    g.translate(0, (975 - 500) * SU, 0);
    return g;
})();
const CARD = new THREE.PlaneGeometry(1, 1);
const ROOTS = new Set();
export class Actor {
    mesh;
    mat;
    dmat;
    r = null;
    constructor(parent, geo = BODY){
        this.mat = cardShade(new THREE.MeshLambertMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        }));
        this.mat.alphaToCoverage = false;
        this.dmat = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mesh = new THREE.Mesh(geo, this.mat);
        this.mesh.customDepthMaterial = this.dmat;
        this.mesh.onBeforeRender = (r)=>{
            const rt = r.getRenderTarget();
            CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920;
        };
        this.mesh.castShadow = false;
        this.mesh.receiveShadow = true;
        this.mesh.visible = false;
        this.mesh.rotation.order = "YXZ";
        this.mesh.renderOrder = 1;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
        ROOTS.add(parent);
    }
    bind() {
        const t = this.r?.tex;
        if (t) {
            this.mat.map = t;
            this.dmat.map = t;
        }
    }
}
export class Fx {
    mesh;
    mat;
    soft;
    blob;
    r = null;
    constructor(parent){
        this.mat = new THREE.MeshBasicMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mat.alphaToCoverage = false;
        this.soft = new THREE.MeshBasicMaterial({
            map: blank,
            transparent: true,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.blob = blobMaterial(blank);
        this.mesh = new THREE.Mesh(CARD, this.mat);
        this.mesh.visible = false;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
    }
    use(soft) {
        this.mesh.material = soft ? this.soft : this.mat;
    }
    bind() {
        const t = this.r?.tex;
        if (!t) return;
        if (this.r.key.includes("|blob|")) {
            if (t.generateMipmaps) {
                t.generateMipmaps = false;
                t.minFilter = THREE.LinearFilter;
                t.needsUpdate = true;
            }
            this.blob.map = t;
            this.mesh.material = this.blob;
            this.mesh.renderOrder = 0.5;
        } else {
            this.mat.map = t;
            this.soft.map = t;
            this.mesh.renderOrder = 0;
        }
    }
}
const hh = (i, s = 0)=>{
    const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453;
    return v - Math.floor(v);
};
const q = (v, n = 120)=>Math.round(v * n) / n;
const seedOf = (i)=>(i * 5 + 3) % 7 + 1;
const tier = (d)=>d < 3.2 ? [
        1800,
        3000,
        3.0
    ] : d < 6.5 ? [
        1080,
        1800,
        1.8
    ] : d < 16 ? [
        480,
        800,
        0.8
    ] : [
        240,
        400,
        0.4
    ];
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME = "day";
const sunOf = (root)=>{
    let s = null;
    root.traverse((o)=>{
        if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o;
    });
    return s;
};
const findSun = (cam, out)=>{
    if (cam.sun) return out.copy(cam.sun).normalize();
    let best = null, err = Infinity;
    for (const r of ROOTS){
        if (!r.parent) continue;
        const s = sunOf(r);
        if (!s) continue;
        const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
        if (e < err) {
            err = e;
            best = s;
        }
    }
    return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
const light2D = (cam, mirror)=>{
    const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
    return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};
const viewOf = (cam, x, z, dx, dz)=>{
    const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
    const c = (tx * dx + tz * dz) / tl;
    return {
        side: c < 0.57,
        mirror: dx * cam.right.x + dz * cam.right.z < 0,
        fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20
    };
};
const LEAD = 2 / FPS;
const LID = [
    0.5,
    1,
    1,
    0.5
];
const lidAt = (t, i, swaps = [])=>{
    const f = Math.round(t * FPS);
    for (const ts of swaps){
        const k = f - Math.round((ts - LEAD) * FPS) + 1;
        if (k >= 0 && k < 4) return LID[k];
    }
    let s = Math.round(-60 * hh(i, 9));
    for(let n = 0; s <= f && n < 400; n++){
        const k = f - s;
        if (k >= 0 && k < 4) return LID[k];
        s += Math.round(15 + 54 * hh(i * 31 + n, 13));
    }
    return 0;
};
const IDLE_HZ = 1.2, IDLE_STEPS = 20;
const idleAt = (t, i)=>q((t * IDLE_HZ + hh(i, 21)) % 1, IDLE_STEPS);
const fkey = (o)=>JSON.stringify(o, (_k, v)=>typeof v === "number" ? q(v) : v);
const person = (cam, who, x, y, z, view, fo, so, scale = 1, flip = false)=>{
    const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
    const [w, h, k] = tier(d);
    const mirror = view.side && view.mirror || flip, light = light2D(cam, mirror), seed = seedOf(who.i);
    const f2 = {
        ...fo,
        light,
        seed
    }, s2 = {
        ...so,
        light,
        seed
    };
    const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
    return {
        key,
        x,
        y,
        z,
        scale,
        mirror,
        tierKey: `${w}`,
        draw: (p)=>view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2),
        size: [
            w,
            h,
            k
        ]
    };
};
const CONTACT = {
    day: [
        0.2,
        0.21,
        0.33
    ],
    golden: [
        0.24,
        0.2,
        0.33
    ],
    rain: [
        0.26,
        0.27,
        0.36
    ]
};
const TAIL = [
    0.42,
    0.44,
    0.62
];
const toSrgb = (v)=>{
    const c = clamp01(v);
    return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055;
};
const hexOf = (c, k)=>"#" + c.map((v)=>Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out, x, y, z, sc = 1, k = 1)=>{
    const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
    if (LNAME === "day") {
        const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
        const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h;
        const tc = hexOf(TAIL, k);
        out.fx.push({
            key: `blob|shadow|${tc}`,
            cw: 128,
            ch: 256,
            draw: (p)=>fxShadow(p, tc),
            x: x + ox * c,
            y: y + 0.018,
            z: z + oz * c,
            w: 0.72 * sc,
            h,
            flat: true,
            rot
        });
    }
    const cc = hexOf(CONTACT[LNAME], k);
    out.fx.push({
        key: `blob|contact|${cc}`,
        cw: 128,
        ch: 128,
        draw: (p)=>fxContact(p, cc),
        x: x + ox * 0.03 * sc,
        y: y + 0.022,
        z: z + oz * 0.03 * sc,
        w: 0.52 * sc,
        h: 0.4 * sc,
        flat: true,
        rot
    });
};
const seq = (f, steps)=>{
    let v = steps[0][1];
    for (const [a, x] of steps)if (f >= a - 2) v = x;
    return v;
};
const DIMAS = {
    jacket: "#3f6fb5",
    pants: "#2f3340",
    boots: "#2a2420",
    hat: "hair",
    hair: "#1d1a1f",
    skin: SKINS[2],
    buttons: "#f4efe2"
};
const BOSS = {
    jacket: "#3a3f55",
    pants: "#2a2d3a",
    boots: "#1f1a1a",
    hat: "hair",
    hair: "#cfcfd4",
    skin: SKINS[0],
    tie: "#b8362f",
    build: "stout",
    buttons: "#d9dde0"
};
const CHIEF = {
    jacket: "#2b3d63",
    pants: "#222836",
    boots: INK,
    hat: "cap",
    cap: "#1d2a4a",
    skin: SKINS[1],
    moustache: "#2a201a",
    build: "stout",
    buttons: "#e8c45a",
    tie: "#e8c45a"
};
const WHO = {
    dimas: {
        i: 1,
        o: DIMAS,
        okey: "dimas"
    },
    boss: {
        i: 2,
        o: BOSS,
        okey: "boss"
    },
    chief: {
        i: 3,
        o: CHIEF,
        okey: "chief"
    }
};
const put = (cam, out, P)=>{
    out.places.push(person(cam, P.who, P.x, 0, P.z, {
        side: false,
        mirror: false
    }, P.fo, {}, 1, P.flip));
    blob(out, P.x, 0, P.z);
};
const HEAD_Y = 1.68;
const popK = (f, f0, f1)=>{
    if (f < f0 || f >= f1 + 5) return 0;
    if (f < f0 + 6) {
        const u = (f - f0) / 6;
        return u < 0.7 ? u / 0.7 * 1.15 : 1.15 - 0.15 * ((u - 0.7) / 0.3);
    }
    if (f >= f1) return Math.max(0, 1 - (f - f1) / 5);
    return 1;
};
const rr = (g, x, y, w, h, r)=>{
    g.beginPath();
    g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r);
    g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r);
    g.arcTo(x, y, x + w, y, r);
    g.closePath();
};
const FONT = "900 %px 'Archivo Black', 'Arial Black', Arial, Helvetica, sans-serif";
const tag = (p, cw, ch, lines, accent, icon)=>{
    const g = p.g, o = 10;
    rr(g, o, o, cw - 2 * o, ch - 2 * o - 18, 34);
    g.fillStyle = "#ffffff";
    g.fill();
    g.lineWidth = 12;
    g.strokeStyle = INK;
    g.stroke();
    g.beginPath();
    g.moveTo(cw / 2 - 22, ch - 28);
    g.lineTo(cw / 2, ch - 4);
    g.lineTo(cw / 2 + 22, ch - 28);
    g.closePath();
    g.fillStyle = "#ffffff";
    g.fill();
    g.stroke();
    g.fillStyle = "#ffffff";
    g.fillRect(cw / 2 - 18, ch - 34, 36, 14);
    const bodyH = ch - 2 * o - 18, x0 = icon ? 150 : 0, cxm = (cw + x0) / 2;
    if (icon) icon(g, 92, 10 + bodyH / 2, 1);
    const n = lines.length, step = bodyH / n;
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.lineJoin = "round";
    lines.forEach(([txt, size], i)=>{
        g.font = FONT.replace("%", String(size));
        const y = o + step * (i + 0.5) + 3;
        g.lineWidth = 9;
        g.strokeStyle = INK;
        g.strokeText(txt, cxm, y);
        g.fillStyle = accent;
        g.fillText(txt, cxm, y);
    });
};
const laptopIcon = (g, x, y, s)=>{
    g.lineWidth = 7;
    g.strokeStyle = INK;
    g.fillStyle = "#8fa2b8";
    rr(g, x - 46 * s, y - 38 * s, 92 * s, 60 * s, 8);
    g.fill();
    g.stroke();
    g.fillStyle = "#cfd7e2";
    g.beginPath();
    g.moveTo(x - 62 * s, y + 22 * s);
    g.lineTo(x + 62 * s, y + 22 * s);
    g.lineTo(x + 50 * s, y + 36 * s);
    g.lineTo(x - 50 * s, y + 36 * s);
    g.closePath();
    g.fill();
    g.stroke();
};
const clockIcon = (g, x, y, s)=>{
    g.lineWidth = 8;
    g.strokeStyle = INK;
    g.fillStyle = "#fbfaf4";
    g.beginPath();
    g.arc(x, y, 46 * s, 0, 7);
    g.fill();
    g.stroke();
    g.lineWidth = 8;
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x, y - 30 * s);
    g.moveTo(x, y);
    g.lineTo(x + 22 * s, y + 8 * s);
    g.stroke();
};
const BADGE_20 = (p)=>tag(p, 760, 250, [
        [
            "Rp20.000.000",
            70
        ]
    ], "#1f8a4c", laptopIcon);
const BADGE_1H = (p)=>tag(p, 560, 250, [
        [
            "1 JAM",
            120
        ]
    ], "#c2363b", clockIcon);
const ROLE = (p)=>tag(p, 520, 330, [
        [
            "KEPALA",
            92
        ],
        [
            "KEAMANAN",
            62
        ]
    ], "#1d2a4a");
const LBL_DRY = (p)=>tag(p, 600, 230, [
        [
            "KERING",
            110
        ]
    ], "#1f8a4c");
const LBL_WET = (p)=>tag(p, 600, 230, [
        [
            "BASAH",
            110
        ]
    ], "#2b6fc2");
const photoArt = (p)=>{
    const g = p.g, W = 600, H = 480;
    g.fillStyle = "#fbfaf4";
    g.fillRect(0, 0, W, H);
    g.lineWidth = 12;
    g.strokeStyle = INK;
    g.strokeRect(6, 6, W - 12, H - 12);
    g.save();
    g.beginPath();
    g.rect(28, 28, W - 56, H - 56);
    g.clip();
    const sky = g.createLinearGradient(0, 0, 0, 250);
    sky.addColorStop(0, "#a9bccd");
    sky.addColorStop(1, "#d2dbe3");
    g.fillStyle = sky;
    g.fillRect(0, 0, W, 250);
    g.fillStyle = "#7d8088";
    g.fillRect(0, 380, W, 100);
    g.fillStyle = "#b8362f";
    g.fillRect(0, 230, W, 170);
    g.fillStyle = "#c2363b";
    g.fillRect(0, 230, W, 22);
    g.fillStyle = "#c2363b";
    g.fillRect(0, 60, W, 60);
    g.fillRect(0, 60, 120, 190);
    g.fillRect(W - 110, 60, 110, 190);
    g.fillStyle = "#2a2c36";
    g.fillRect(120, 120, W - 230, 112);
    g.fillStyle = "#c9985e";
    g.beginPath();
    g.moveTo(250, 232);
    g.lineTo(250, 190);
    g.lineTo(330, 188);
    g.lineTo(350, 128);
    g.lineTo(392, 130);
    g.lineTo(380, 232);
    g.closePath();
    g.fill();
    g.lineWidth = 6;
    g.strokeStyle = INK;
    g.stroke();
    g.fillStyle = "#fbfaf4";
    g.strokeStyle = INK;
    g.lineWidth = 5;
    g.lineJoin = "round";
    for(let i = 0; i < 9; i++){
        const x = 126 + i * 54;
        g.beginPath();
        g.moveTo(x, 120);
        g.lineTo(x + 20, 148 + i % 3 * 8);
        g.lineTo(x + 38, 120);
        g.closePath();
        g.fill();
        g.stroke();
    }
    for(let i = 0; i < 9; i++){
        const x = 140 + i * 52;
        g.beginPath();
        g.moveTo(x, 232);
        g.lineTo(x + 18, 208 - i % 2 * 10);
        g.lineTo(x + 34, 232);
        g.closePath();
        g.fill();
        g.stroke();
    }
    for(let i = 0; i < 34; i++){
        const x = 40 + i * 97 % 520, y = 262 + i * 53 % 120, r = 9 + i % 4 * 3;
        g.fillStyle = "#cfe6f6";
        g.beginPath();
        g.ellipse(x, y, r * 0.8, r, 0, 0, 7);
        g.fill();
        g.lineWidth = 3;
        g.strokeStyle = "#5d8fb8";
        g.stroke();
        g.fillStyle = "#ffffff";
        g.beginPath();
        g.arc(x - r * 0.25, y - r * 0.3, r * 0.22, 0, 7);
        g.fill();
    }
    g.restore();
};
const PHOTO_ASPECT = 0.8;
const ringArt = (p)=>{
    const g = p.g;
    g.lineWidth = 22;
    g.strokeStyle = INK;
    g.beginPath();
    g.ellipse(150, 150, 118, 108, 0, 0, 7);
    g.stroke();
    g.lineWidth = 11;
    g.strokeStyle = "#ffd23a";
    g.beginPath();
    g.ellipse(150, 150, 118, 108, 0, 0, 7);
    g.stroke();
};
const jagged = (p)=>{
    const g = p.g, W = 660, H = 240;
    g.fillStyle = "#e8f4fb";
    g.strokeStyle = INK;
    g.lineWidth = 5;
    g.lineJoin = "round";
    const tri = (x, y, dx, dy, w)=>{
        g.beginPath();
        g.moveTo(x, y);
        g.lineTo(x + dx, y + dy);
        g.lineTo(x + w, y);
        g.closePath();
        g.fill();
        g.stroke();
    };
    const tops = [
        [
            50,
            70,
            20
        ],
        [
            150,
            90,
            14
        ],
        [
            250,
            55,
            28
        ],
        [
            360,
            80,
            18
        ],
        [
            450,
            60,
            24
        ],
        [
            540,
            85,
            16
        ]
    ];
    for (const [x, w, k] of tops)tri(x, 22, w * 0.45, k, w);
    const bots = [
        [
            90,
            60,
            14
        ],
        [
            210,
            90,
            22
        ],
        [
            330,
            70,
            12
        ],
        [
            470,
            80,
            20
        ]
    ];
    for (const [x, w, k] of bots){
        g.beginPath();
        g.moveTo(x, H - 22);
        g.lineTo(x + w * 0.5, H - 22 - k);
        g.lineTo(x + w, H - 22);
        g.closePath();
        g.fill();
        g.stroke();
    }
    g.beginPath();
    g.moveTo(22, 40);
    g.lineTo(52, 100);
    g.lineTo(22, 120);
    g.closePath();
    g.fill();
    g.stroke();
    g.beginPath();
    g.moveTo(W - 22, 120);
    g.lineTo(W - 58, 150);
    g.lineTo(W - 22, 190);
    g.closePath();
    g.fill();
    g.stroke();
};
const dropsArt = (p)=>{
    const g = p.g;
    for(let i = 0; i < 9; i++){
        const x = 30 + i * 61 % 180, y = 30 + i * 47 % 170, r = 10 + i % 3 * 5;
        g.fillStyle = "#cfe6f6";
        g.beginPath();
        g.ellipse(x, y, r * 0.8, r, 0, 0, 7);
        g.fill();
        g.lineWidth = 3;
        g.strokeStyle = "#5d8fb8";
        g.stroke();
        g.fillStyle = "#ffffff";
        g.beginPath();
        g.arc(x - r * 0.25, y - r * 0.3, r * 0.22, 0, 7);
        g.fill();
    }
};
const shardArt = (p)=>{
    const g = p.g;
    g.fillStyle = "#e6f4fc";
    g.strokeStyle = INK;
    g.lineWidth = 10;
    g.lineJoin = "round";
    g.beginPath();
    g.moveTo(10, 90);
    g.lineTo(60, 10);
    g.lineTo(110, 80);
    g.closePath();
    g.fill();
    g.stroke();
};
const streakArt = (p)=>{
    const g = p.g;
    const gr = g.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, "rgba(255,255,255,0)");
    gr.addColorStop(1, "rgba(235,245,255,1)");
    g.fillStyle = gr;
    g.fillRect(6, 0, 10, 256);
};
const puddleArt = (p)=>{
    p.ell(150, 75, 140, 58, "#7fa0c0", 0);
    p.ell(120, 62, 60, 16, "#b9d3ea", 0);
};
const dropArt = (p)=>{
    const g = p.g;
    g.fillStyle = "#cfe6f6";
    g.strokeStyle = INK;
    g.lineWidth = 8;
    g.beginPath();
    g.moveTo(64, 10);
    g.quadraticCurveTo(110, 80, 64, 118);
    g.quadraticCurveTo(18, 80, 64, 10);
    g.fill();
    g.stroke();
};
const bubbleArt = (stage)=>(p)=>{
        const g = p.g, W = 780, H = 640;
        g.lineWidth = 12;
        g.strokeStyle = INK;
        g.fillStyle = "#ffffff";
        g.beginPath();
        for (const [x, y, r] of [
            [
                250,
                220,
                150
            ],
            [
                420,
                170,
                160
            ],
            [
                580,
                240,
                140
            ],
            [
                330,
                320,
                150
            ],
            [
                520,
                340,
                140
            ]
        ]){
            g.moveTo(x + r, y);
            g.arc(x, y, r, 0, 7);
        }
        g.fill();
        g.beginPath();
        for (const [x, y, r] of [
            [
                250,
                220,
                150
            ],
            [
                420,
                170,
                160
            ],
            [
                580,
                240,
                140
            ],
            [
                330,
                320,
                150
            ],
            [
                520,
                340,
                140
            ]
        ]){
            g.moveTo(x + r, y);
            g.arc(x, y, r, 0, 7);
        }
        g.stroke();
        g.fillStyle = "#ffffff";
        g.beginPath();
        for (const [x, y, r] of [
            [
                250,
                220,
                138
            ],
            [
                420,
                170,
                148
            ],
            [
                580,
                240,
                128
            ],
            [
                330,
                320,
                138
            ],
            [
                520,
                340,
                128
            ]
        ]){
            g.moveTo(x + r, y);
            g.arc(x, y, r, 0, 7);
        }
        g.fill();
        for (const [x, y, r] of [
            [
                170,
                500,
                34
            ],
            [
                110,
                580,
                22
            ]
        ]){
            g.beginPath();
            g.arc(x, y, r, 0, 7);
            g.fillStyle = "#ffffff";
            g.fill();
            g.stroke();
        }
        g.lineWidth = 8;
        g.lineJoin = "round";
        if (stage === 0) {
            laptopIcon(g, 230, 270, 1.35);
            g.lineWidth = 14;
            g.strokeStyle = INK;
            g.beginPath();
            g.moveTo(360, 270);
            g.lineTo(420, 270);
            g.moveTo(396, 244);
            g.lineTo(424, 270);
            g.lineTo(396, 296);
            g.stroke();
            for(let i = 0; i < 3; i++){
                g.fillStyle = "#3f9a5a";
                g.strokeStyle = INK;
                g.lineWidth = 7;
                rr(g, 440 + i * 12, 300 - i * 30, 180, 78, 8);
                g.fill();
                g.stroke();
                g.fillStyle = "#e9f6ec";
                g.font = FONT.replace("%", "44");
                g.textAlign = "center";
                g.textBaseline = "middle";
                if (i === 2) g.fillText("Rp", 530 + 24, 262 - 0);
            }
        } else {
            g.fillStyle = "#fbfaf4";
            g.strokeStyle = INK;
            g.lineWidth = 8;
            rr(g, 250, 120, 200, 260, 14);
            g.fill();
            g.stroke();
            g.lineWidth = 8;
            g.strokeStyle = "#9aa0aa";
            for(let i = 0; i < 4; i++){
                g.beginPath();
                g.moveTo(278, 170 + i * 36);
                g.lineTo(422, 170 + i * 36);
                g.stroke();
            }
            g.lineWidth = 20;
            g.strokeStyle = INK;
            g.beginPath();
            g.moveTo(300, 330);
            g.lineTo(336, 366);
            g.lineTo(410, 290);
            g.stroke();
            g.lineWidth = 11;
            g.strokeStyle = "#1f8a4c";
            g.beginPath();
            g.moveTo(300, 330);
            g.lineTo(336, 366);
            g.lineTo(410, 290);
            g.stroke();
            for (const [x, y] of [
                [
                    520,
                    330
                ],
                [
                    580,
                    290
                ],
                [
                    560,
                    360
                ]
            ]){
                g.fillStyle = "#f3c53a";
                g.strokeStyle = INK;
                g.lineWidth = 8;
                g.beginPath();
                g.ellipse(x, y, 38, 38, 0, 0, 7);
                g.fill();
                g.stroke();
            }
        }
    };
const PUD_OFFICE = [
    [
        -2.6,
        -3.4,
        1.5
    ],
    [
        1.9,
        -4.2,
        1.7
    ],
    [
        0.2,
        -1.8,
        1.3
    ],
    [
        -0.9,
        -5.2,
        1.1
    ],
    [
        3.4,
        -2.4,
        1.2
    ]
];
const PUD_STREET = [
    [
        32.6,
        0.4,
        1.6
    ],
    [
        39.6,
        -0.3,
        1.4
    ],
    [
        36.8,
        2.6,
        2.0
    ],
    [
        33.6,
        -2.6,
        1.0
    ],
    [
        40.5,
        3.2,
        1.6
    ]
];
const puddles = (out, t, id, rainy)=>{
    const list = SHOTS[id - 1].place === "office" ? PUD_OFFICE : PUD_STREET;
    list.forEach(([x, z, w], i)=>{
        out.fx.push({
            key: "puddle",
            cw: 300,
            ch: 150,
            draw: puddleArt,
            x,
            y: 0.03,
            z,
            w,
            h: w * 0.5,
            flat: true
        });
        if (rainy) {
            const u = q((t * 1.2 + i * 0.37) % 1, 30);
            out.fx.push({
                key: `ring${u}`,
                cw: 600,
                ch: 600,
                draw: (p)=>fxRing(p, u),
                x: x + (hh(i, 3) - 0.5) * w * 0.5,
                y: 0.04,
                z,
                w: 0.9,
                h: 0.9,
                flat: true
            });
        }
    });
};
const rain = (out, t, cx, cz, n, speed)=>{
    for(let i = 0; i < n; i++){
        const u = (t * speed + hh(i, 1)) % 1, x = cx + (hh(i, 2) - 0.5) * 9, z = cz + (hh(i, 3) - 0.5) * 8 + 1, y = 4.2 - u * 4.2;
        out.fx.push({
            key: "streak",
            cw: 24,
            ch: 256,
            draw: streakArt,
            x: x - u * 0.7,
            y: y + 0.3,
            z,
            w: 0.022,
            h: 0.5,
            rot: 0.17
        });
    }
};
const CAR_NZ = CAR[2] + 0.9;
const carDrops = (out)=>{
    for(let i = 0; i < 16; i++){
        const x = CAR[0] - 2.0 + i % 8 * 0.52 + (hh(i, 4) - 0.5) * 0.2, y = i < 8 ? 0.45 : 0.72 + (hh(i, 5) - 0.5) * 0.08;
        out.fx.push({
            key: "carDrops",
            cw: 256,
            ch: 256,
            draw: dropsArt,
            x,
            y,
            z: CAR_NZ + 0.06,
            w: 0.3,
            h: 0.3
        });
    }
    for(let i = 0; i < 6; i++)out.fx.push({
        key: "carDrops",
        cw: 256,
        ch: 256,
        draw: dropsArt,
        x: CAR[0] + 1.35 + i * 0.12,
        y: 1.0 + i % 3 * 0.12,
        z: CAR_NZ + 0.06,
        w: 0.2,
        h: 0.2
    });
};
const carBroken = (out, id, f)=>{
    if (!winBroken(id, f)) return;
    out.fx.push({
        key: "jagged",
        cw: 660,
        ch: 240,
        draw: jagged,
        x: WIN_X,
        y: (WIN_Y0 + WIN_Y1) / 2,
        z: CAR_NZ + 0.03,
        w: WIN_W + 0.1,
        h: WIN_Y1 - WIN_Y0 + 0.12
    });
    for(let i = 0; i < 6; i++)out.fx.push({
        key: "shard",
        cw: 128,
        ch: 128,
        draw: shardArt,
        x: WIN_X - 0.6 + i * 0.26 + (hh(i, 6) - 0.5) * 0.15,
        y: 0.03,
        z: CAR_NZ + 0.35 + hh(i, 7) * 0.5,
        w: 0.15,
        h: 0.15,
        flat: true,
        rot: hh(i, 8) * 6
    });
};
export const stage = (id, f, cam)=>{
    const out = {
        places: [],
        fx: []
    };
    const s = SHOTS[id - 1], t = f / FPS;
    LNAME = s.light;
    findSun(cam, SUN);
    const lid = (i)=>lidAt(t, i);
    const idl = (i)=>idleAt(t, i);
    const dimas = WHO.dimas, boss = WHO.boss, chief = WHO.chief;
    const rainy = s.light === "rain";
    if (s.place === "office") puddles(out, t, id, rainy && id !== 1 && id !== 2 ? true : id <= 2);
    switch(id){
        case 1:
            {
                const z = -7.6 + 2.4 * smooth(f / 100), x = -0.1 + 0.06 * Math.sin(t * 2.1);
                put(cam, out, {
                    who: dimas,
                    x,
                    z,
                    fo: {
                        mode: "stroll",
                        phase: q(t * 1.25 % 1, 60),
                        expr: seq(f, [
                            [
                                0,
                                "nervous"
                            ],
                            [
                                43,
                                "shock"
                            ]
                        ]),
                        blink: lid(1),
                        lift: 55,
                        look: 0
                    }
                });
                for(let i = 0; i < 9; i++){
                    const u = (t * 1.1 + hh(i, 1)) % 1, x0 = -3.8 + i * 0.95;
                    out.fx.push({
                        key: "drop",
                        cw: 128,
                        ch: 128,
                        draw: dropArt,
                        x: x0,
                        y: 2.55 - u * u * 2.4,
                        z: -7.7,
                        w: 0.06,
                        h: 0.09
                    });
                }
                break;
            }
        case 2:
            {
                const dz = -6.0, bz = -6.2;
                put(cam, out, {
                    who: dimas,
                    x: -0.65,
                    z: dz,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                112,
                                "nervous"
                            ],
                            [
                                190,
                                "shock"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        look: 1,
                        wave: f >= 128 ? q(Math.sin(t * 9) * 0.9, 30) : undefined,
                        facing: 1
                    }
                });
                put(cam, out, {
                    who: boss,
                    x: 0.65,
                    z: bz,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                112,
                                "neutral"
                            ],
                            [
                                190,
                                "shock"
                            ]
                        ]),
                        blink: lid(2),
                        idle: idl(2),
                        look: -1,
                        facing: -1
                    }
                });
                const k = popK(f, 157, 222);
                if (k > 0.01) out.fx.push({
                    key: "badge20",
                    cw: 760,
                    ch: 250,
                    draw: BADGE_20,
                    x: -0.35,
                    y: HEAD_Y + 0.5,
                    z: dz,
                    w: 1.3 * k,
                    h: 0.43 * k
                });
                break;
            }
        case 3:
            {
                const x = 34.4 - 0.85 * (t - 230 / FPS), z = -0.1;
                const view = viewOf(cam, x, z, -1, 0), phase = q(t * 1.1 % 1, 120);
                out.places.push(person(cam, dimas, x, 0, z, view, {
                    mode: "stroll",
                    phase,
                    expr: "neutral",
                    blink: lid(1)
                }, {
                    mode: "march",
                    phase,
                    expr: "neutral",
                    stomp: 0.3,
                    stride: 0.875 * view.fs,
                    blink: lid(1)
                }));
                blob(out, x, 0, z);
                puddles(out, t, id, true);
                rain(out, t, 35, -1, 48, 1.3);
                carDrops(out);
                const k = popK(f, 298, 337);
                if (k > 0.01) out.fx.push({
                    key: "badge1h",
                    cw: 560,
                    ch: 250,
                    draw: BADGE_1H,
                    x: CAR[0],
                    y: 2.35,
                    z: CAR[2],
                    w: 1.7 * k,
                    h: 0.76 * k
                });
                break;
            }
        case 4:
            {
                put(cam, out, {
                    who: dimas,
                    x: 37.1,
                    z: -0.5,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                337,
                                "nervous"
                            ],
                            [
                                360,
                                "shock"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        facing: -1,
                        wave: f >= 352 ? q(Math.sin(t * 9) * 0.8, 30) : undefined
                    }
                });
                puddles(out, t, id, false);
                carDrops(out);
                carBroken(out, id, f);
                if (f >= 340 && f < 345) {
                    const u = q((f - 340) / 5, 30);
                    out.fx.push({
                        key: `burst${u}`,
                        cw: 500,
                        ch: 500,
                        draw: (p)=>fxBurst(p, u),
                        x: 37.1,
                        y: 2.0,
                        z: -0.4,
                        w: 0.9,
                        h: 0.9
                    });
                }
                break;
            }
        case 5:
            {
                const hold = f >= 466;
                put(cam, out, {
                    who: dimas,
                    x: OFF.dimas,
                    z: OFF.z,
                    fo: {
                        mode: "stand",
                        expr: "nervous",
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1,
                        prop: hold ? "photo" : null
                    }
                });
                put(cam, out, {
                    who: boss,
                    x: OFF.boss,
                    z: OFF.z - 0.2,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                417,
                                "neutral"
                            ],
                            [
                                531,
                                "nervous"
                            ]
                        ]),
                        blink: lid(2),
                        idle: idl(2),
                        facing: -1
                    }
                });
                put(cam, out, {
                    who: chief,
                    x: OFF.chief,
                    z: OFF.z - 0.1,
                    fo: {
                        mode: "stand",
                        expr: "stern",
                        blink: lid(3),
                        idle: idl(3),
                        facing: -1
                    }
                });
                const k = smooth((f - 466) / 8);
                if (k > 0.01) out.fx.push({
                    key: "photo",
                    cw: 600,
                    ch: 480,
                    draw: photoArt,
                    x: OFF.dimas + 0.55,
                    y: 1.5,
                    z: OFF.z + 0.06,
                    w: 0.62 * k,
                    h: 0.62 * PHOTO_ASPECT * k
                });
                puddles(out, t, id, false);
                break;
            }
        case 6:
            {
                put(cam, out, {
                    who: dimas,
                    x: OFF.dimas,
                    z: OFF.z,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                556,
                                "nervous"
                            ],
                            [
                                573,
                                "relief"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1
                    }
                });
                put(cam, out, {
                    who: boss,
                    x: OFF.boss,
                    z: OFF.z - 0.2,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                556,
                                "neutral"
                            ],
                            [
                                570,
                                "smile_closed"
                            ]
                        ]),
                        blink: lid(2),
                        idle: idl(2),
                        facing: -1,
                        prop: f >= 596 ? "phone" : null
                    }
                });
                put(cam, out, {
                    who: chief,
                    x: OFF.chief,
                    z: OFF.z - 0.1,
                    fo: {
                        mode: "stand",
                        expr: "stern",
                        blink: lid(3),
                        idle: idl(3),
                        facing: -1
                    }
                });
                break;
            }
        case 7:
            {
                put(cam, out, {
                    who: dimas,
                    x: OFF.dimas,
                    z: OFF.z,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                656,
                                "relief"
                            ],
                            [
                                806,
                                "shock"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1
                    }
                });
                put(cam, out, {
                    who: boss,
                    x: OFF.boss,
                    z: OFF.z - 0.2,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                656,
                                "smile_closed"
                            ],
                            [
                                786,
                                "shock"
                            ]
                        ]),
                        blink: lid(2),
                        idle: idl(2),
                        facing: -1
                    }
                });
                put(cam, out, {
                    who: chief,
                    x: OFF.chief,
                    z: OFF.z - 0.1,
                    flip: f >= 771,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                656,
                                "stern"
                            ],
                            [
                                721,
                                "smile"
                            ]
                        ]),
                        blink: lid(3),
                        idle: idl(3),
                        facing: f >= 771 ? 1 : -1,
                        prop: f >= 771 ? "point" : null
                    }
                });
                const k = popK(f, 655, 758);
                if (k > 0.01) out.fx.push({
                    key: "role",
                    cw: 520,
                    ch: 330,
                    draw: ROLE,
                    x: OFF.chief,
                    y: HEAD_Y + 0.6,
                    z: OFF.z - 0.1,
                    w: 0.9 * k,
                    h: 0.57 * k
                });
                if (f >= 806 && f < 812) {
                    const u = q((f - 806) / 6, 30);
                    out.fx.push({
                        key: `burst${u}`,
                        cw: 500,
                        ch: 500,
                        draw: (p)=>fxBurst(p, u),
                        x: OFF.dimas,
                        y: 1.0,
                        z: OFF.z + 0.3,
                        w: 1.1,
                        h: 1.1
                    });
                }
                break;
            }
        case 8:
            {
                put(cam, out, {
                    who: dimas,
                    x: OFF.dimas,
                    z: OFF.z,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                849,
                                "shock"
                            ],
                            [
                                871,
                                "nervous"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1,
                        wave: f >= 871 && f < 913 ? q(Math.sin(t * 10) * 0.9, 30) : undefined
                    }
                });
                put(cam, out, {
                    who: boss,
                    x: OFF.boss,
                    z: OFF.z - 0.2,
                    fo: {
                        mode: "stand",
                        expr: "neutral",
                        blink: lid(2),
                        idle: idl(2),
                        facing: -1
                    }
                });
                put(cam, out, {
                    who: chief,
                    x: OFF.chief,
                    z: OFF.z - 0.1,
                    flip: true,
                    fo: {
                        mode: "stand",
                        expr: "smile",
                        blink: lid(3),
                        idle: idl(3),
                        facing: 1,
                        prop: f >= 940 ? "point" : null
                    }
                });
                if (f >= 913) {
                    const px = 0.35, py = 1.7, pz = -5.0, pw = 1.0, ph = pw * PHOTO_ASPECT, k = smooth((f - 913) / 7);
                    out.fx.push({
                        key: "photo",
                        cw: 600,
                        ch: 480,
                        draw: photoArt,
                        x: px,
                        y: py,
                        z: pz,
                        w: pw * k,
                        h: ph * k
                    });
                    const rk = popK(f, 971, 1019);
                    if (rk > 0.01) {
                        const toCam = new THREE.Vector3(cam.pos.x - px, cam.pos.y - py, cam.pos.z - pz).normalize().multiplyScalar(0.06);
                        const dx = (310 / 600 - 0.5) * pw, dy = (0.5 - 180 / 480) * ph;
                        out.fx.push({
                            key: "ring",
                            cw: 300,
                            ch: 300,
                            draw: ringArt,
                            x: px + cam.right.x * dx + toCam.x,
                            y: py + dy + toCam.y,
                            z: pz + cam.right.z * dx + toCam.z,
                            w: 0.36 * rk,
                            h: 0.36 * rk
                        });
                    }
                }
                break;
            }
        case 9:
            {
                puddles(out, t, id, true);
                carDrops(out);
                carBroken(out, id, f);
                rain(out, t, 35.7, -0.5, 170, 1.9);
                break;
            }
        case 10:
            {
                puddles(out, t, id, false);
                carDrops(out);
                carBroken(out, id, f);
                const k1 = popK(f, 1220, 1262), k2 = popK(f, 1286, 1325);
                if (k1 > 0.01) out.fx.push({
                    key: "lblDry",
                    cw: 600,
                    ch: 230,
                    draw: LBL_DRY,
                    x: WIN_X + 0.1,
                    y: 1.78,
                    z: CAR_NZ + 0.1,
                    w: 0.95 * k1,
                    h: 0.36 * k1
                });
                if (k2 > 0.01) out.fx.push({
                    key: "lblWet",
                    cw: 600,
                    ch: 230,
                    draw: LBL_WET,
                    x: CAR[0] + 1.0,
                    y: 0.18,
                    z: CAR_NZ + 0.2,
                    w: 0.95 * k2,
                    h: 0.36 * k2
                });
                break;
            }
        case 11:
            {
                const n = f - SMASH;
                const hk = n >= 0 ? 1 : n >= -7 ? 0 : n >= -11 ? 1 - smooth((n + 11) / 4) : 1;
                put(cam, out, {
                    who: dimas,
                    x: 36.7,
                    z: -0.9,
                    flip: true,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                1329,
                                "smile"
                            ],
                            [
                                1395,
                                "relief"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        prop: [
                            "hammer",
                            q(hk, 30)
                        ]
                    }
                });
                puddles(out, t, id, false);
                carDrops(out);
                carBroken(out, id, f);
                if (n >= 0 && n < 6) {
                    const u = q(n / 6, 30);
                    out.fx.push({
                        key: `bigburst${u}`,
                        cw: 500,
                        ch: 500,
                        draw: (p)=>fxBurst(p, u),
                        x: WIN_X + 0.35,
                        y: 1.2,
                        z: CAR_NZ + 0.1,
                        w: 1.3,
                        h: 1.3
                    });
                }
                if (n >= 0 && n < 26) for(let i = 0; i < 14; i++){
                    const u = n / 26, vx = (hh(i, 1) - 0.5) * 1.8, vy = 1.2 + hh(i, 2) * 1.6;
                    out.fx.push({
                        key: "shard",
                        cw: 128,
                        ch: 128,
                        draw: shardArt,
                        x: WIN_X + (hh(i, 3) - 0.5) * 0.9 + vx * u * 0.6,
                        y: Math.max(0.04, 1.2 + vy * u * 0.8 - 5.5 * u * u),
                        z: CAR_NZ + 0.15 + u * hh(i, 4) * 0.8,
                        w: 0.13,
                        h: 0.13,
                        rot: u * 6 + i
                    });
                }
                break;
            }
        case 12:
            {
                put(cam, out, {
                    who: dimas,
                    x: 35.9,
                    z: -0.6,
                    fo: {
                        mode: "stand",
                        expr: "smile",
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1
                    }
                });
                puddles(out, t, id, false);
                carDrops(out);
                carBroken(out, id, f);
                const stg = f >= 1485 ? 1 : 0, k = popK(f, 1457, 1518);
                if (k > 0.01) out.fx.push({
                    key: `bubble${stg}`,
                    cw: 780,
                    ch: 640,
                    draw: bubbleArt(stg),
                    x: 36.55,
                    y: 2.25,
                    z: -0.6,
                    w: 1.25 * k,
                    h: 1.03 * k
                });
                break;
            }
        case 13:
            {
                const can = f >= 1565;
                if (f < 1583) put(cam, out, {
                    who: dimas,
                    x: 36.4,
                    z: -0.6,
                    fo: {
                        mode: "stand",
                        expr: seq(f, [
                            [
                                1522,
                                "smile"
                            ],
                            [
                                1531,
                                "shock"
                            ],
                            [
                                1548,
                                "dazed"
                            ]
                        ]),
                        blink: lid(1),
                        idle: idl(1),
                        facing: 1,
                        prop: can ? "can" : null
                    }
                });
                puddles(out, t, id, false);
                carDrops(out);
                carBroken(out, id, f);
                if (f >= 1584) {
                    const u = clamp01((f - 1584) / 7);
                    if (u < 1) out.fx.push({
                        key: "drop",
                        cw: 128,
                        ch: 128,
                        draw: dropArt,
                        x: WIN_X - 0.05,
                        y: 1.75 - 0.65 * u * u,
                        z: -2.6,
                        w: 0.11,
                        h: 0.16
                    });
                    else {
                        const r = q(clamp01((f - 1591) / 12), 30);
                        out.fx.push({
                            key: `ring${r}`,
                            cw: 600,
                            ch: 600,
                            draw: (p)=>fxRing(p, r),
                            x: WIN_X - 0.05,
                            y: 1.11,
                            z: -2.6,
                            w: 0.35,
                            h: 0.35,
                            flat: true
                        });
                    }
                }
                break;
            }
    }
    return out;
};
void fxContact;
void fxShadow;
void fxStars;
void bodySide;
void bodyFront;
void V3_NOOP();
function V3_NOOP() {
    return 0;
}
export { FPS };
