// The place for "Kaca Kering": a wet city street, the glass office front with its awning, and one parked red car whose
// front side window is intact, smashed live (shot 11) or already broken. Sky / light rig / camera follow the bridge
// short's look layer unchanged. update(id, f, camera) poses everything for shot `id` at frame f (pure function).
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { Batch, boxGeo, quad, V, lam, prop, Kit } from "./build";
import { ctex, cloudHD, rng } from "./paint";
import { Pen } from "./toon";
import { LIGHTS, LOOK, LightPreset } from "./lights";
import { TONE, CHAR, twoTone, untone } from "./shade";
import { NOINK } from "./ink";
import { Pool, Actor, Fx, stage } from "./cast";
import { FPS, SHOTS, camAt, ShotDef, CAR, WIN_X, WIN_W, WIN_Y0, WIN_Y1, FACADE_Z, CURB_Z, winBroken, SMASH, smooth } from "./story";

// ---------------- assets (CC0 Kenney props: only the trees are used) ----------------
const KENNEY = ["tree_oak", "tree_default", "tree_detailed", "tree_fat", "plant_bushLarge", "plant_bushDetailed", "hedge"];
let kitP: Promise<Kit> | null = null;
export const loadKit = () => {
  if (!kitP) {
    const loader = new GLTFLoader();
    kitP = Promise.all(KENNEY.map((n) => loader.loadAsync(`./kenney/${n}.glb`).then((g) => [n, g.scene] as const).catch(() => [n, null] as const)))
      .then((list) => Object.fromEntries(list.filter((e) => e[1]).map(([n, s]) => [n, s!])) as Kit);
  }
  return kitP;
};

const discTex = () => ctex("sunDisc", 128, 128, (g) => {
  const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
});
const haloTex = () => ctex("sunHalo", 256, 256, (g) => {
  const im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const u = Math.hypot(x - 127.5, y - 127.5) / 128;
    const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
    const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
  }
  g.putImageData(im, 0, 0);
});

// ---------------- painted textures (modern city) ----------------
const asphaltTex = () => ctex("asphaltWet", 512, 512, (g, r) => {
  g.fillStyle = "#4b4e57"; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 1400; i++) { const l = 60 + r() * 50; g.fillStyle = `rgba(${l},${l},${l + 6},.28)`; g.fillRect(r() * 512, r() * 512, 2 + r() * 3, 2 + r() * 3); }
  for (let i = 0; i < 18; i++) { g.fillStyle = "rgba(40,42,52,.22)"; g.beginPath(); g.ellipse(r() * 512, r() * 512, 20 + r() * 50, 10 + r() * 24, 0, 0, 7); g.fill(); }
});
const pavingTex = () => ctex("pavingWet", 512, 512, (g, r) => {
  g.fillStyle = "#b9b5ac"; g.fillRect(0, 0, 512, 512);
  for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
    const l = 172 + r() * 22; g.fillStyle = `rgb(${l},${l - 3},${l - 9})`; g.fillRect(x * 128 + 3, y * 128 + 3, 122, 122);
  }
  g.fillStyle = "rgba(60,58,60,.35)"; for (let i = 0; i <= 4; i++) { g.fillRect(i * 128 - 2, 0, 4, 512); g.fillRect(0, i * 128 - 2, 512, 4); }
  for (let i = 0; i < 12; i++) { g.fillStyle = "rgba(60,70,90,.16)"; g.beginPath(); g.ellipse(r() * 512, r() * 512, 20 + r() * 40, 10 + r() * 20, 0, 0, 7); g.fill(); }
});
/** 4 x 3 cells of 3.6 x 3.2 m (256 px per cell): wall + one window per cell; wall colour and glass tint per building */
const gridTex = (key: string, wall: string, glass: [string, string], frame: string) => ctex("grid" + key, 1024, 768, (g, r) => {
  g.fillStyle = wall; g.fillRect(0, 0, 1024, 768);
  for (let i = 0; i < 60; i++) { g.fillStyle = `rgba(${r() > 0.5 ? "255,255,255" : "0,0,0"},.045)`; g.beginPath(); g.ellipse(r() * 1024, r() * 768, 30 + r() * 60, 16 + r() * 30, 0, 0, 7); g.fill(); }
  for (let cy = 0; cy < 3; cy++) for (let cx = 0; cx < 4; cx++) {
    const x0 = cx * 256 + 40, y0 = cy * 256 + 46, w = 176, h = 140;
    g.fillStyle = frame; g.fillRect(x0 - 8, y0 - 8, w + 16, h + 16);
    const gg = g.createLinearGradient(x0, y0, x0 + w, y0 + h); gg.addColorStop(0, glass[0]); gg.addColorStop(1, glass[1]);
    g.fillStyle = gg; g.fillRect(x0, y0, w, h);
    g.fillStyle = "rgba(255,255,255,.35)"; g.beginPath(); g.moveTo(x0 + 14, y0 + h * 0.8); g.lineTo(x0 + w * 0.5, y0 + 10); g.lineTo(x0 + w * 0.68, y0 + 10); g.lineTo(x0 + 14, y0 + h); g.fill();
    g.fillStyle = frame; g.fillRect(x0 + w / 2 - 3, y0, 6, h);
    g.fillStyle = "rgba(0,0,0,.18)"; g.fillRect(x0 - 8, y0 + h + 8, w + 16, 6);
  }
});
/** ground-floor glass front of the office: 18 x 4.2 m, double door in the middle, warm lobby behind tinted glass */
const lobbyTex = () => ctex("lobby", 1152, 270, (g) => {
  const W = 1152, H = 270, m = 64;
  g.fillStyle = "#2f3a48"; g.fillRect(0, 0, W, H);
  const gl = g.createLinearGradient(0, 0, 0, H); gl.addColorStop(0, "#7fa6c0"); gl.addColorStop(0.55, "#9cc2d6"); gl.addColorStop(1, "#e8d9a8");
  for (let i = 0; i < 9; i++) {
    const x0 = i * 2 * m + 5, w = 2 * m - 10;
    g.fillStyle = gl; g.fillRect(x0, 8, w, H - 8);
    g.fillStyle = "rgba(255,255,255,.28)"; g.beginPath(); g.moveTo(x0 + 14, H - 30); g.lineTo(x0 + w * 0.55, 18); g.lineTo(x0 + w * 0.75, 18); g.lineTo(x0 + 14, H - 6); g.fill();
    g.fillStyle = "rgba(60,50,40,.5)"; g.fillRect(x0 + 10, H - 70, w - 20, 62); // desk / plants behind the glass
  }
  // double door (centre bay i = 4): brighter glass, silver frame, two handles
  const dx = 4 * 2 * m + 5, dw = 2 * m - 10;
  g.fillStyle = "#c6ccd2"; g.fillRect(dx - 2, 4, dw + 4, H - 4);
  g.fillStyle = "#bfe0ee"; g.fillRect(dx + 6, 12, dw / 2 - 9, H - 14); g.fillRect(dx + dw / 2 + 3, 12, dw / 2 - 9, H - 14);
  g.fillStyle = "#4b5560"; g.fillRect(dx + dw / 2 - 14, H / 2 - 20, 6, 46); g.fillRect(dx + dw / 2 + 8, H / 2 - 20, 6, 46);
  g.fillStyle = "#26303c"; g.fillRect(0, 0, W, 8); g.fillRect(0, H - 8, W, 8);
});
const awningTex = () => ctex("awningValance", 1024, 128, (g) => {
  g.fillStyle = "#1f3a6e"; g.fillRect(0, 0, 1024, 128);
  g.fillStyle = "#16294f"; g.fillRect(0, 112, 1024, 16);
  g.font = "900 100px 'Archivo Black', Arial Black, Arial, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
  g.lineWidth = 10; g.strokeStyle = "#0e1a33"; g.strokeText("KANTOR", 512, 56);
  g.fillStyle = "#ffffff"; g.fillText("KANTOR", 512, 56);
});
const glassTex = () => ctex("carGlass", 256, 128, (g) => {
  const gg = g.createLinearGradient(0, 0, 256, 128); gg.addColorStop(0, "#3d5f80"); gg.addColorStop(1, "#1f3550");
  g.fillStyle = gg; g.fillRect(0, 0, 256, 128);
  g.fillStyle = "rgba(255,255,255,.3)"; g.beginPath(); g.moveTo(30, 128); g.lineTo(120, 0); g.lineTo(160, 0); g.lineTo(70, 128); g.fill();
  g.fillStyle = "rgba(255,255,255,.18)"; g.beginPath(); g.moveTo(150, 128); g.lineTo(220, 0); g.lineTo(240, 0); g.lineTo(170, 128); g.fill();
});

const groundQuad = (x0: number, x1: number, z0: number, z1: number, y: number, tile: number) => {
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([x0, y, z1, x1, y, z1, x1, y, z0, x0, y, z1, x1, y, z0, x0, y, z0], 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute([0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], 3));
  const u = (x1 - x0) / tile, v = (z1 - z0) / tile;
  g.setAttribute("uv", new THREE.Float32BufferAttribute([0, 0, u, 0, u, v, 0, 0, u, v, 0, v], 2));
  return g;
};

type Mats = Record<string, THREE.Material>;
const rotY = (a: number, x = 0, y = 0, z = 0) => new THREE.Matrix4().makeRotationY(a).setPosition(x, y, z);

export class World {
  root = new THREE.Group();
  private pool = new Pool();
  private actors: Actor[] = [];
  private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden" | "rain", THREE.Texture[]>;
  private clouds: THREE.Mesh[] = [];
  private glass = new THREE.Group();      // intact front side window pane
  private seatMat: THREE.MeshLambertMaterial;
  private frustum = new THREE.Frustum();
  private m4 = new THREE.Matrix4(); private v = new THREE.Vector3(); private sph = new THREE.Sphere();

  constructor(kit: Kit) {
    const R = this.root, M: Mats = {};
    // ---- sky + light (unchanged rig) ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() },
        c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK);
    R.add(this.sky);
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: discTex(), color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true,
      transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(4096, 4096);
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = { day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)), golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)),
      rain: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.rain.cloud)) };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30;
      m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1);
      m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }

    // ---- materials ----
    M.asphalt = lam("asphaltWet", () => ({ map: asphaltTex() }));
    M.paving = lam("pavingWet", () => ({ map: pavingTex() }));
    M.curb = lam("curb", () => ({ color: "#cfcac0" }));
    M.line = lam("roadLine", () => ({ color: "#e9e6dc" }));
    M.dark = lam("darkTrim", () => ({ color: "#2b2e38" }));
    M.steel = twoTone(new THREE.MeshPhongMaterial({ color: "#7d8088", specular: "#b0b0b0", shininess: 45 }), 0.15);
    M.paint = twoTone(new THREE.MeshPhongMaterial({ color: "#c2363b", specular: "#e8d0d0", shininess: 70 }), 0.15);
    M.tyre = lam("tyre", () => ({ color: "#20222a" }));
    M.hub = lam("hub", () => ({ color: "#9aa0aa" }));
    M.lampY = lam("lampY", () => ({ color: "#f3d77a" }));
    M.lampR = lam("lampR", () => ({ color: "#b3262c" }));
    M.glass = lam("carGlassM", () => ({ map: glassTex(), side: THREE.DoubleSide }));
    M.inner = lam("carInner", () => ({ color: "#2a2c36" }));
    this.seatMat = twoTone(new THREE.MeshLambertMaterial({ color: "#e0b070" }));
    M.seatDark = lam("seatDark", () => ({ color: "#6b4a30" }));
    M.awning = lam("awning", () => ({ color: "#1f3a6e" }));
    M.valance = new THREE.MeshBasicMaterial({ map: awningTex() }); // unlit: the sun must not grey the sign
    M.lobby = lam("lobbyM", () => ({ map: lobbyTex() }));
    M.concrete = lam("concrete", () => ({ color: "#aeb0b4" }));
    M.trunkPot = lam("pot", () => ({ color: "#7a5a40" }));

    // ---- ground: road, curb, pavement ----
    const b = new Batch();
    b.add(groundQuad(-200, 260, CURB_Z, 40, 0, 6), M.asphalt);
    b.add(groundQuad(-200, 260, FACADE_Z, CURB_Z - 0.3, 0.02, 3), M.paving);
    b.add(boxGeo(V(-200, 0, CURB_Z - 0.3), V(260, 0.15, CURB_Z), 2), M.curb);
    for (let x = -120; x < 240; x += 6) b.add(boxGeo(V(x, 0.015, 5.0), V(x + 3, 0.02, 5.2)), M.line);
    b.add(boxGeo(V(-200, 0.015, 0.2), V(260, 0.02, 0.28)), M.line); // road edge line

    // ---- office block + neighbours (only z < FACADE_Z is ever in view: cameras look toward -z) ----
    const OZ = FACADE_Z;
    b.add(boxGeo(V(-9, 0, OZ - 14), V(9, 15, OZ)), lam("officeWall", () => ({ color: "#d7d2c6" })));
    b.add(quad(V(-9, 0, OZ + 0.02), V(9, 0, OZ + 0.02), V(9, 4.2, OZ + 0.02), V(-9, 4.2, OZ + 0.02)), M.lobby);
    b.add(quad(V(-9, 4.2, OZ + 0.02), V(9, 4.2, OZ + 0.02), V(9, 15, OZ + 0.02), V(-9, 15, OZ + 0.02), 18 / 14.4, 10.8 / 9.6),
      lam("gridOffice", () => ({ map: gridTex("office", "#dcd7cc", ["#9ec3dc", "#5d8fb8"], "#3a4350") })));
    b.add(boxGeo(V(-9.2, 4.2, OZ), V(9.2, 4.45, OZ + 0.25)), M.concrete);     // ledge over the glass front
    b.add(boxGeo(V(-9.2, 14.9, OZ), V(9.2, 15.3, OZ + 0.3)), M.concrete);     // cornice
    // awning (low slab sloping a little) + unlit valance with the sign, posts, steps
    b.add(boxGeo(V(-2.6, 2.5, OZ), V(2.6, 2.62, OZ + 1.25)), M.awning);
    b.add(quad(V(-2.6, 2.0, OZ + 1.27), V(2.6, 2.0, OZ + 1.27), V(2.6, 2.62, OZ + 1.27), V(-2.6, 2.62, OZ + 1.27), 1, 1), M.valance);
    b.add(boxGeo(V(-2.6, 2.0, OZ + 1.2), V(2.6, 2.62, OZ + 1.26)), M.awning);
    b.add(boxGeo(V(-9, 0.02, OZ), V(9, 0.12, OZ + 0.5)), M.concrete);
    const blocks: [number, number, number, string, [string, string], string][] = [
      [-60, -9.4, 11, "#c9a98a", ["#a7c4d6", "#5e86a8"], "#4b3f38"], [-9.4, -9.4, 0, "#000", ["#000", "#000"], "#000"],
      [9.4, 34, 17, "#b9b6ae", ["#9fc0d8", "#587ea6"], "#3d4650"], [34, 52, 12, "#a8b4a0", ["#b3cfe0", "#6a93b4"], "#3f463e"],
      [52, 90, 21, "#cdb99a", ["#9fbbd2", "#5a7fa3"], "#4a4034"], [-120, -60, 15, "#b8b4ac", ["#a4c1d4", "#5f89ab"], "#3c4450"],
      [90, 150, 14, "#c4a98a", ["#a7c4d6", "#5e86a8"], "#4b3f38"],
    ];
    blocks.forEach(([x0, x1, h, wall, glass, frame], i) => {
      if (h === 0) return;
      const w = x1 - x0;
      b.add(boxGeo(V(x0, 0, OZ - 16), V(x1, h, OZ - 0.05)), lam("blkWall" + i, () => ({ color: wall })));
      b.add(quad(V(x0, 0, OZ + 0.0), V(x1, 0, OZ + 0.0), V(x1, h, OZ + 0.0), V(x0, h, OZ + 0.0), w / 14.4, h / 9.6), lam("gridB" + i, () => ({ map: gridTex("b" + i, wall, glass, frame) })));
      b.add(boxGeo(V(x0 - 0.1, h - 0.3, OZ - 0.05), V(x1 + 0.1, h + 0.15, OZ + 0.2)), M.concrete);
    });
    // far backdrop across the sky line
    for (let i = 0; i < 12; i++) {
      const r = rng(i + 3), w = 14 + r() * 20, h = 18 + r() * 40, x = -150 + i * 42 + r() * 12;
      b.add(boxGeo(V(x, 0, OZ - 90 - r() * 40), V(x + w, h, OZ - 70)), lam("far" + (i % 3), () => ({ color: ["#a9b6c4", "#b9bdc8", "#9fadbd"][i % 3] })));
    }

    // ---- street furniture: lamp posts, bins, bollards ----
    const LAMPX = [-14, -4.5, 5, 14, 22, 30, 43, 50, 58];
    for (const x of LAMPX) {
      b.add(boxGeo(V(x - 0.06, 0.02, -4.1 - 0.06), V(x + 0.06, 4.6, -4.1 + 0.06)), M.dark);
      b.add(boxGeo(V(x - 0.06, 4.5, -4.1 - 0.06), V(x + 0.06, 4.58, 0.5)), M.dark);
      b.add(boxGeo(V(x - 0.18, 4.42, 0.2), V(x + 0.18, 4.5, 0.62)), M.steel);
    }
    for (const x of [-7.5, 11, 28, 46]) {
      b.add(boxGeo(V(x - 0.25, 0.02, -4.6 - 0.25), V(x + 0.25, 0.85, -4.6 + 0.25)), lam("bin", () => ({ color: "#3d6a58" })));
      b.add(boxGeo(V(x - 0.28, 0.85, -4.6 - 0.28), V(x + 0.28, 0.95, -4.6 + 0.28)), M.dark);
    }
    // trees (cartoon vegetation from build.ts) kept off the cast's spots
    const TREES: [string, number, number, number][] = [["tree_default", -11, -4.9, 5.2], ["tree_oak", 9.8, -4.9, 5.6], ["tree_default", 16, -4.9, 5.0], ["tree_detailed", -20, -4.9, 5.4],
      ["tree_oak", 28.8, -4.9, 5.4], ["tree_default", 41, -4.9, 5.2], ["tree_detailed", 47, -4.9, 5.6], ["tree_oak", 24, -4.9, 5.0]];
    for (const [n, x, z, h] of TREES) prop(b, kit, n, x, 0.02, z, h, x * 0.7);
    for (const x of [-3.2, 3.2]) b.add(boxGeo(V(x - 0.35, 0.02, OZ + 1.9), V(x + 0.35, 0.7, OZ + 2.5)), M.trunkPot);
    for (const x of [-3.2, 3.2]) prop(b, kit, "plant_bushLarge", x, 0.7, OZ + 2.2, 0.9, x);

    // ---- the car ----
    const [cx, , cz] = CAR, zn = cz + 0.9, zf = cz - 0.9; // near (road side, faces +z) and far side
    b.add(boxGeo(V(cx - 2.2, 0.3, zf), V(cx + 2.2, 0.95, zn)), M.paint);                     // body
    b.add(boxGeo(V(cx - 2.25, 0.32, zf + 0.1), V(cx - 2.2, 0.62, zn - 0.1)), M.dark);       // bumpers
    b.add(boxGeo(V(cx + 2.2, 0.32, zf + 0.1), V(cx + 2.26, 0.62, zn - 0.1)), M.dark);
    for (const s of [-1, 1]) {
      b.add(boxGeo(V(cx + 2.2, 0.62, cz + s * 0.62 - 0.14), V(cx + 2.24, 0.78, cz + s * 0.62 + 0.14)), M.lampY);
      b.add(boxGeo(V(cx - 2.24, 0.66, cz + s * 0.62 - 0.14), V(cx - 2.2, 0.8, cz + s * 0.62 + 0.14)), M.lampR);
    }
    const cabZn = zn - 0.12, cabZf = zf + 0.12, rx0 = cx - 1.1, rx1 = cx + 1.4;                // cabin x 34.9 .. 37.4
    b.add(boxGeo(V(rx0, WIN_Y1, cabZf), V(rx1, 1.5, cabZn)), M.paint);                       // roof
    b.add(boxGeo(V(rx0, 0.95, cabZf), V(rx0 + 0.2, WIN_Y1, cabZn)), M.paint);                // A pillar
    b.add(boxGeo(V(cx + 0.2, 0.95, cabZf), V(cx + 0.5, WIN_Y1, cabZn)), M.paint);            // B pillar
    b.add(boxGeo(V(rx1 - 0.25, 0.95, cabZf), V(rx1, WIN_Y1, cabZn)), M.paint);               // C pillar
    b.add(boxGeo(V(rx0, WIN_Y0 - 0.05, cabZf), V(rx1, WIN_Y0, cabZn)), M.paint);             // sill
    // far side glass (always intact) closes the cabin: dark blue panes behind the seats
    b.add(quad(V(rx0 + 0.2, WIN_Y0, cabZf + 0.02), V(rx1 - 0.25, WIN_Y0, cabZf + 0.02), V(rx1 - 0.25, WIN_Y1, cabZf + 0.02), V(rx0 + 0.2, WIN_Y1, cabZf + 0.02)), M.glass);
    b.add(boxGeo(V(rx0 + 0.18, 0.7, cabZf + 0.03), V(rx1 - 0.23, 0.95, cabZf + 0.1)), M.inner); // door card + dashboard line
    // seats (profile visible through the window): cushion, leaned back, headrest
    const sx = WIN_X;
    this.addSeat(R, sx, cz);
    b.add(boxGeo(V(rx0 + 0.2, 0.62, cabZf + 0.1), V(sx - 0.5, 0.95, cabZn - 0.2)), M.inner);  // dash / footwell
    // wheels
    for (const wx of [cx - 1.35, cx + 1.4]) for (const wz of [zn - 0.02, zf + 0.02]) {
      const t = new THREE.CylinderGeometry(0.33, 0.33, 0.22, 20); t.rotateX(Math.PI / 2);
      b.add(t, M.tyre, new THREE.Matrix4().makeTranslation(wx, 0.33, wz));
      const h = new THREE.CylinderGeometry(0.17, 0.17, 0.24, 12); h.rotateX(Math.PI / 2);
      b.add(h, M.hub, new THREE.Matrix4().makeTranslation(wx, 0.33, wz));
    }
    // door handle + mirror
    b.add(boxGeo(V(cx + 0.05, 0.85, zn), V(cx + 0.3, 0.9, zn + 0.05)), M.steel);
    b.add(boxGeo(V(rx0 + 0.05, 1.0, zn), V(rx0 + 0.3, 1.14, zn + 0.18)), M.paint);
    b.build(R);

    // intact side-window panes (front door + rear door): shown only while the front one is unbroken
    const pane = (x0: number, x1: number) => quad(V(x0, WIN_Y0, cabZn - 0.01), V(x1, WIN_Y0, cabZn - 0.01), V(x1, WIN_Y1, cabZn - 0.01), V(x0, WIN_Y1, cabZn - 0.01));
    const front = new THREE.Mesh(pane(rx0 + 0.2, cx + 0.2), M.glass); front.castShadow = false; this.glass.add(front);
    R.add(this.glass);
    const rear = new THREE.Mesh(pane(cx + 0.5, rx1 - 0.25), M.glass); R.add(rear);
  }

  /** the driver seat as its own meshes so its colour can go from dry tan to soaked blue-grey */
  private addSeat(R: THREE.Object3D, sx: number, cz: number) {
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.44, 0.8), this.seatMat);
    back.position.set(sx + 0.22, 1.17, cz - 0.45); back.rotation.z = -0.12;
    const cush = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.2, 0.8), this.seatMat);
    cush.position.set(sx - 0.12, 0.99, cz - 0.45);
    for (const m of [back, cush]) { m.castShadow = true; m.receiveShadow = true; R.add(m); }
  }

  /** camera-relative sun, frozen per shot */
  private shotSun(id: number, s: ShotDef, L: LightPreset) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }

  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene) {
    const t = f / FPS, s = SHOTS[id - 1], L = LIGHTS[s.light];
    // ---- camera ----
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);
    // ---- light rig ----
    const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (s.light === "golden") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...LOOK[s.light].bounce); TONE.uSat.value = LOOK[s.light].sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);
    // ---- sky, fog, sun disc, clouds ----
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = L.fogNear; this.fog.far = L.fogFar;
    scene.fog = this.fog; scene.background = null;
    const showSun = s.light === "golden";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mat = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z);
      mat.map = this.cloudMaps[s.light][i % 4];
    }
    // ---- the car: pane present while intact, seat wet in the imagined downpour (shot 9) ----
    this.glass.visible = !winBroken(id, f);
    const wet = id === 9 ? smooth((f - 1100) / 40) : 0;
    this.seatMat.color.set("#e0b070").lerp(new THREE.Color("#34405f"), wet);
    // ---- cast + effects ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const st = stage(id, f, { pos: cam.position, right });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const tint = "#ffffff";
    let ai = 0;
    const used: Actor[] = [];
    for (const p of st.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true;
      a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      if (a.mat.emissiveMap) a.mat.emissive.set(tint);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0;
    const fused: Fx[] = [];
    for (const p of st.fx) {
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const e2 = this.fx(fi++);
      e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      e2.use(!!p.soft);
      e2.mesh.visible = true;
      e2.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { e2.mesh.quaternion.copy(cam.quaternion); e2.mesh.rotateZ(p.rot ?? 0); }
      e2.mesh.scale.set(p.w, p.h, 1);
      fused.push(e2);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const e2 of fused) e2.bind();
    return focus;
  }
}
void SMASH; void Pen; void rotY; void WIN_W;
