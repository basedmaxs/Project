// Timeline of "Kaca Kering" (Dimas fakes a car break-in): shots timed to the voice words (work/words.json).
// World: a street along x (road z -3.2 .. +14, curb at z = -3.2, sidewalk z -3.5 .. -9, office facade at z = -9 around
// x = 0). The camera looks toward -z, so world +x is screen right. The parked car stands at x = 36 (z = -2.2).
// Camera grammar as in the bridge short: continuous creeping push-ins, symmetric smootherstep glides of 18-40 f, big
// reframes are cuts, impacts are 7-frame kicks, no hand-held float.
export const FPS = 30;
export const TOTAL = 1608; // 53.592 s x 30
export const D0 = 0; // ground level (build.ts imports it)
export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 4;

export type Light = "day" | "golden" | "rain";
export type Place = "office" | "street";
export type ShotDef = { id: number; a: number; b: number; light: Light; place: Place };
export const SHOTS: ShotDef[] = [
  { id: 1, a: 0, b: 112, light: "rain", place: "office" },      // hook: Dimas arrives, panicked, right after the rain
  { id: 2, a: 112, b: 230, light: "rain", place: "office" },    // "laptop dua puluh juta dicuri"
  { id: 3, a: 230, b: 337, light: "rain", place: "street" },    // parked an hour, in the rain
  { id: 4, a: 337, b: 417, light: "day", place: "street" },     // window broken, bag gone
  { id: 5, a: 417, b: 556, light: "day", place: "office" },     // shows the photo
  { id: 6, a: 556, b: 656, light: "day", place: "office" },     // boss almost believes, calls the insurer
  { id: 7, a: 656, b: 849, light: "day", place: "office" },     // security chief smirks: fire him
  { id: 8, a: 849, b: 1025, light: "day", place: "office" },    // Dimas protests, chief points at one detail
  { id: 9, a: 1025, b: 1169, light: "rain", place: "street" },  // what should have happened: soaked seat
  { id: 10, a: 1169, b: 1329, light: "day", place: "street" },  // the photo: dry seat, wet body
  { id: 11, a: 1329, b: 1443, light: "day", place: "street" },  // Dimas smashes the window after the rain
  { id: 12, a: 1443, b: 1522, light: "day", place: "street" },  // the plan: sell the laptop, claim insurance
  { id: 13, a: 1522, b: TOTAL, light: "day", place: "street" }, // forgot to wet the seat
];
/** crossfades (frames) at place / weather changes; no flash */
export const XFADE: Record<number, number> = { 3: 6, 5: 6, 9: 6, 11: 6 };
export const FLASH_AT = 99999;

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [{ id: s.id - 1, alpha: 1 }, { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) }];
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

// ---------------- places ----------------
export const FACADE_Z = -9;       // office front
export const CURB_Z = -3.2;       // road edge
export const CAR: V3 = [36, 0, -2.2]; // car centre (x, ground, z); nose toward +x; the broken side faces +z (the road)
export const WIN_X = 35.65;       // centre of the front door window
export const WIN_W = 1.1;
export const WIN_Y0 = 1.0, WIN_Y1 = 1.38;
export const SMASH = 1358;        // frame the hammer lands (shot 11)
/** is the front side window broken at this frame in this shot? (shot 3 intact; 11 breaks it live) */
export const winBroken = (id: number, f: number) => (id === 11 ? f >= SMASH : id >= 4 && id !== 3);

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const mix = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3, look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k, roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};
const T = (f: number) => f / FPS;
/** push-in factor since f0 (the subject grows ~rate per frame); punch raises it for the first n frames */
const pushK = (f: number, f0: number, rate: number, punch = 0, n = 35) => {
  const x = Math.max(0, f - f0);
  let s = rate * x;
  if (punch > rate) for (let i = 0; i < Math.min(x, n); i++) s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
  return Math.exp(-s);
};
const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [look[0] + (pos[0] - look[0]) * k, look[1] + (pos[1] - look[1]) * k, look[2] + (pos[2] - look[2]) * k], look, ...rest });
const rolled = (s: (f: number) => Shot, roll: number) => (f: number): Shot => ({ ...s(f), roll });

// ---- who stands where (office, sidewalk z ~ -6; x grows to screen right) ----
export const OFF = { dimas: -1.25, boss: 0.15, chief: 1.5, z: -6.0 };
// ---- framings ----
// shot 1: Dimas walks toward the lens; wide, then closer on "panik"
const S1a = (f: number) => dolly([0, 1.55, 0.4], [0, 1.4, -6.5], pushK(f, 0, 0.0025), { fov: 42 });
const S1b = (f: number) => dolly([-0.1, 1.5, -1.6], [0, 1.5, -5], pushK(f, 60, 0.002), { fov: 36 });
// shot 2: Dimas + boss
const S2a = (f: number) => dolly([0, 1.5, -0.9], [0, 1.6, -6], pushK(f, 112, 0.002), { fov: 38 });
// shot 3: street, car parked in the rain; closer on "jam"
const S3a = (f: number) => dolly([31.5, 1.5, 4.5], [35.5, 1.1, -2.2], pushK(f, 230, 0.0018), { fov: 42 });
const S3b = (f: number) => dolly([33.5, 1.45, 3.2], [36, 1.3, -2.2], pushK(f, 288, 0.002), { fov: 38 });
// shot 4: the window, then the empty seat on "tas laptopnya lenyap"
const S4a = (f: number) => dolly([36.3, 1.45, 3.4], [36.3, 1.2, -2.0], pushK(f, 337, 0.0022), { fov: 52 });
const S4b = (f: number) => dolly([35.8, 1.25, 2.1], [35.7, 1.1, -2.1], pushK(f, 381, 0.002, 0.005, 30), { fov: 34, roll: 0.03 });
// shot 5: three-shot, then in on Dimas + photo
const S5a = (f: number) => dolly([0.3, 1.5, 0.5], [0.1, 1.5, -6], pushK(f, 417, 0.002), { fov: 46 });
const S5b = (f: number) => dolly([-0.2, 1.5, -1.2], [-0.8, 1.5, -6], pushK(f, 490, 0.002), { fov: 38 });
// shot 6: boss MS
const S6a = (f: number) => dolly([0.7, 1.55, -1.4], [0.15, 1.55, -6.1], pushK(f, 556, 0.0025), { fov: 34 });
// shot 7: chief MS -> smirk CU -> wide three-shot with roll
const S7a = (f: number) => dolly([1.9, 1.6, -1.5], [1.5, 1.6, -6.1], pushK(f, 656, 0.0025), { fov: 32 });
const S7b = (f: number) => dolly([1.9, 1.65, -3.4], [1.5, 1.65, -6.1], pushK(f, 723, 0.003), { fov: 28 });
const S7c = (f: number) => dolly([0.3, 1.5, 0.5], [0.2, 1.55, -6], pushK(f, 765, 0.0022, 0.005, 30), { fov: 46, roll: -0.035 });
// shot 8: Dimas protests -> insert photo with the chief pointing
const S8a = (f: number) => dolly([-0.7, 1.55, -1.0], [-1.25, 1.55, -6], pushK(f, 849, 0.0028), { fov: 34 });
const S8b = (f: number) => dolly([0.75, 1.6, -1.5], [0.75, 1.6, -6], pushK(f, 913, 0.002), { fov: 38 });
// shot 9: heavy rain at the car, then in at the window
const S9a = (f: number) => dolly([34.6, 1.45, 2.8], [35.7, 1.1, -2.3], pushK(f, 1025, 0.0018), { fov: 38, roll: -0.03 });
const S9b = (f: number) => dolly([35.4, 1.3, 1.7], [35.65, 1.05, -2.2], pushK(f, 1100, 0.002, 0.006, 32), { fov: 32 });
// shot 10: the photo content: seat + body
const S10a = (f: number) => dolly([35.9, 1.3, 2.6], [35.9, 1.05, -2.0], pushK(f, 1169, 0.0018), { fov: 40 });
const S10b = (f: number) => dolly([36.2, 0.9, 2.2], [36.4, 0.75, -2.0], pushK(f, 1270, 0.0022), { fov: 38, roll: 0.03 });
// shot 11: Dimas swings, strike on "memecahkan", then up at the sky
const S11a = (f: number) => dolly([36.2, 1.45, 2.6], [36.4, 1.3, -2.0], pushK(f, 1329, 0.002), { fov: 46 });
const S11b = (f: number) => dolly([36.9, 1.5, 1.2], [37.0, 1.5, -1.0], pushK(f, 1397, 0.002), { fov: 34, roll: -0.03 });
// shot 12: Dimas by the car, the plan in a thought bubble
const S12a = (f: number) => dolly([36.2, 1.8, 4.6], [36.2, 1.7, -0.6], pushK(f, 1443, 0.0015), { fov: 44 });
// shot 13: Dimas with the watering can -> seat close-up for the last word
const S13a = (f: number) => dolly([36.3, 1.6, 4.2], [36.3, 1.45, -0.6], pushK(f, 1522, 0.0015), { fov: 42 });
const S13b = (f: number) => dolly([35.35, 1.2, 0.5], [35.65, 1.0, -2.0], pushK(f, 1583, 0.0012), { fov: 26 });

const CAMS: Record<number, Key[]> = {
  1: [{ f: 0, s: S1a }, { f: 60, dur: 30, s: S1b }],
  2: [{ f: 112, s: S2a }],
  3: [{ f: 230, s: S3a }, { f: 288, dur: 30, s: S3b }],
  4: [{ f: 337, s: S4a }, { f: 381, dur: 22, s: S4b }],
  5: [{ f: 417, s: S5a }, { f: 490, dur: 26, s: S5b }],
  6: [{ f: 556, s: S6a }],
  7: [{ f: 656, s: S7a }, { f: 723, cut: true, s: S7b }, { f: 765, cut: true, s: S7c }, { f: 765, dur: 20, s: rolled(S7c, 0.035) }],
  8: [{ f: 849, s: S8a }, { f: 913, cut: true, s: S8b }],
  9: [{ f: 1025, s: S9a }, { f: 1100, dur: 30, s: S9b }],
  10: [{ f: 1169, s: S10a }, { f: 1270, dur: 24, s: S10b }],
  11: [{ f: 1329, s: S11a }, { f: 1397, dur: 30, s: S11b }],
  12: [{ f: 1443, s: S12a }],
  13: [{ f: 1522, s: S13a }, { f: 1583, cut: true, s: S13b }],
};

// impact kicks: the image offset flips sign every frame and decays over 7 frames
const KICKS: [number, number][] = [[SMASH / FPS, 1.1], [806 / FPS, 0.5], [1590 / FPS, 0.4]];
export const kickAt = (t: number) => {
  let a = 0;
  for (const [t0, g] of KICKS) {
    const n = Math.floor((t - t0) * FPS + 1e-6);
    if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
  }
  return a;
};
export const camAt = (id: number, f: number): Cam => {
  const c = run(CAMS[id], f), a = kickAt(T(f));
  if (!a) return c;
  const d: V3 = [c.look[0] - c.pos[0], c.look[1] - c.pos[1], c.look[2] - c.pos[2]];
  const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
  const m = (3 / 640) * Math.tan((c.fov * Math.PI) / 360) * L * a;
  return { ...c, look: [c.look[0] - (d[2] / h) * m, c.look[1] + 0.6 * m, c.look[2] + (d[0] / h) * m], roll: c.roll + a * 0.004 };
};
export const keyEnd = (id: number, f: number) => {
  let e = 0;
  for (const k of CAMS[id]) if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
  return Math.max(f, e);
};

// ---------------- foreground framing ----------------
export type Fg = { a: number; b: number; kit: string; pos: V3; s?: number; yaw?: number };
export const FOREGROUND: Fg[] = [];
