# Picture timeline of "Kaca Kering" (mirrors src/story.ts + cast.ts): shots, the smash frame, graphic pop-ins, cuts.
import numpy as np

FPS = 30
TOTAL = 1608
DUR = TOTAL / FPS            # 53.592 s
fr = lambda f: f / FPS
FLASH = 1e9                  # no white flash in this film
SMASH = fr(1358)             # hammer lands on the window (shot 11)
DROP = fr(1591)              # the lonely drop on the dry seat (last word)

# id: (first frame, end frame, light, place)
SHOTS = {
    1: (0, 112, "rain", "office"), 2: (112, 230, "rain", "office"), 3: (230, 337, "rain", "street"),
    4: (337, 417, "day", "street"), 5: (417, 556, "day", "office"), 6: (556, 656, "day", "office"),
    7: (656, 849, "day", "office"), 8: (849, 1025, "day", "office"), 9: (1025, 1169, "rain", "street"),
    10: (1169, 1329, "day", "street"), 11: (1329, 1443, "day", "street"), 12: (1443, 1522, "day", "street"),
    13: (1522, TOTAL, "day", "street"),
}
XFADE = {3: 6, 5: 6, 9: 6, 11: 6}
# frames of the in-scene graphics popping in (sound: a soft blip) and the hard cuts / big glides (sound: whoosh)
POPS = [157, 298, 655, 971, 1220, 1286, 1457, 1485]
CUTS = [112, 230, 337, 417, 556, 656, 723, 765, 849, 913, 1025, 1169, 1329, 1443, 1522, 1583]
GLIDES = [60, 288, 381, 490, 1100, 1270, 1397]


def shot_t(i):
    a, b = SHOTS[i][:2]
    return fr(a), fr(b)


def shot_at(t):
    f = t * FPS
    for i, (a, b, *_r) in SHOTS.items():
        if a <= f < b:
            return i
    return 13


def words(path):
    import json
    return json.load(open(path, encoding="utf-8"))
