# Kaca Kering - soundtrack cue sheet

All sound is original: synthesized in numpy/scipy by `sfx_gen.py` / `instruments.py`, placed by `sfx.py` / `music.py`, mixed by `mix.py`.
Voice = `voice/voice.wav`, gain only (no EQ, no compression, no pitch).

## Files
| file | content |
|---|---|
| `mix.wav` | final mix, 48 kHz, stereo, 24-bit, exact film length |
| `stem_voice.wav` / `stem_music.wav` / `stem_sfx.wav` | stems at mix gain (they sum to the mix before the master limiter) |

## Master loudness (own BS.1770-4 meter)
- Integrated **-15.0 LUFS**, true peak **-1.2 dBTP**, LRA 2.2 LU, max momentary -11.0 LUFS, max short-term -13.5 LUFS
- Stems: voice -15.3 LUFS, music -25.9 LUFS, sfx -38.0 LUFS (voice gain +3.88 dB, same gain on every stem)
- Master limiter (4x oversampled look-ahead, ceiling -1.2 dBTP): max gain reduction 1.21 dB, active (>0.1 dB) on 3.43 % of samples, >0.5 dB on 0.49 %

ffmpeg ebur128 cross-check:
```
Summary:
  Integrated loudness:
    I:         -15.0 LUFS
    Threshold: -25.1 LUFS
  Loudness range:
    LRA:         2.2 LU
    Threshold: -35.1 LUFS
    LRA low:   -16.2 LUFS
    LRA high:  -14.0 LUFS
  True peak:
    Peak:       -1.2 dBFS
```

## Voice on top: per-section loudness (LUFS, integrated per stem, at mix gain)
bed = music + sfx. margin = voice - bed (integrated over the section). speech median / p10 = median and 10th percentile of the 400 ms momentary margin (voice - bed) over windows centred on spoken words.

| section (shots) | time s | voice | music | sfx | bed | margin LU | speech median LU | speech p10 LU |
|---|---|---|---|---|---|---|---|---|
| hook (1-2) | 0.00-7.67 | -14.5 | -24.4 | -36.9 | -24.1 | 9.6 | 9.3 | 6.3 |
| street (3-4) | 7.67-13.90 | -16.4 | -27.5 | -36.9 | -27.0 | 10.6 | 10.9 | 5.4 |
| photo (5-6) | 13.90-21.87 | -15.4 | -26.4 | -44.7 | -26.3 | 10.9 | 11.3 | 6.5 |
| accusation (7-8) | 21.87-34.17 | -15.7 | -25.8 | -43.7 | -25.7 | 10.1 | 12.3 | 6.1 |
| rain (9) | 34.17-38.97 | -14.2 | -26.2 | -32.2 | -25.2 | 11.0 | 10.5 | 9.0 |
| evidence (10) | 38.97-44.30 | -15.0 | -25.0 | -43.2 | -24.9 | 9.9 | 10.4 | 5.6 |
| smash (11) | 44.30-48.10 | -15.9 | -26.7 | -34.0 | -26.1 | 10.3 | 11.2 | 7.2 |
| plan (12) | 48.10-50.73 | -14.5 | -25.6 | -39.4 | -25.4 | 11.0 | 11.2 | 8.1 |
| caught (13) | 50.73-53.60 | -15.3 | -27.7 | -38.8 | -27.4 | 12.0 | 12.0 | 10.3 |

## Music map (original comic-noir band, A minor, 96 bpm)
Music target per section, LU under the voice (after a -3 dB speech duck keyed from words.json): hook -9.5, report -10.5, doubt -11.0, twist -10.0, rain -12.0, reveal -10.0, scheme -11.0, outro -12.0. Applied section gains (dB): hook -6.9, report -9.2, doubt -7.3, twist -6.9, rain -5.5, reveal -7.7, scheme -6.3, outro -6.0.

Rides (music only, dB): 3.30-3.75 s -2.0, 28.40-28.90 s -2.0, 53.00-53.50 s -2.0 - so quiet sentence-final words stay on top and the band blooms in the gaps after them. The hook's last two footfalls (3.5, 4.0) are also 3 dB lower in the SFX for '...walking across it.'

| time s | frame | music |
|---|---|---|
| 0.00 | 0 | hook: nervous 8th-note pulse on A + pad (Dimas arrives panicked) |
| 3.73 | 112 | report: walking pizzicato bass in A minor, brushes, vibes pah, music-box phrase |
| 13.90 | 417 | doubt: brighter C-F-G walk (boss almost believes, calls the insurer) |
| 21.87 | 656 | twist: pad + pulse, timpani on the smirk, stab on the order, hush for the small detail |
| 34.17 | 1025 | rain: slow pad + glock drips (what should have happened) |
| 38.97 | 1169 | reveal: Dm-G-C-E7 walk; glock pings on the labels |
| 45.27 | 1358 | smash: timpani + brass stab + cymbal on the hammer, then a sneaky pizzicato walk |
| 50.73 | 1522 | outro: soft pad, falling horn after the drop (last word) |

## SFX events
Level convention: every EVENT has a naive level (LU vs the voice stem, as the event's max momentary loudness); applied = naive - 6 dB (standard mix rule) + distance/intensity offsets. BEDS are integrated loudness, not reduced. 'mix LUFS' = the event's max momentary loudness in the final mix (voice stem = -15.3 LUFS integrated). Column sounds also get the camera-distance low-pass and more valley reverb.

| # | time s | frame | cue | what | naive LU | applied LU | mix LUFS | pan |
|---|---|---|---|---|---|---|---|---|
| 1 | 0.000 | 0.0 | amb_rain1 (bed, integrated) | tail of the rain on the office awning, drips (shots 1-2) | -26 | -26.0 | -41.3 | +0.00 |
| 2 | 0.000 | 0.0 | amb_street1 (bed, integrated) | wet city street: traffic rumble, breeze (shots 1-3) | -32 | -32.0 | -47.3 | +0.00 |
| 3 | 0.100 | 3.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -17 | -23.2 | -38.5 | +0.00 |
| 4 | 0.500 | 15.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -17 | -22.8 | -38.1 | +0.00 |
| 5 | 0.900 | 27.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -16 | -22.4 | -37.7 | +0.00 |
| 6 | 1.300 | 39.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -16 | -22.0 | -37.3 | +0.00 |
| 7 | 1.700 | 51.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -16 | -21.6 | -36.9 | +0.00 |
| 8 | 1.880 | 56.4 | whoosh | camera move (frame 60) | -22 | -28.0 | -43.3 | +0.00 |
| 9 | 2.100 | 63.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -15 | -21.2 | -36.5 | +0.00 |
| 10 | 2.500 | 75.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -15 | -20.8 | -36.1 | +0.00 |
| 11 | 2.900 | 87.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -14 | -20.4 | -35.7 | +0.00 |
| 12 | 3.300 | 99.0 | step_hurry | Dimas' hurried wet footstep (shot 1) | -14 | -20.0 | -35.3 | +0.00 |
| 13 | 5.253 | 157.6 | pop | in-scene graphic pops in (frame 157) | -20 | -26.0 | -41.3 | +0.00 |
| 14 | 7.500 | 225.0 | amb_rain2 (bed, integrated) | steady rain on the parked car and street (shot 3) | -23 | -23.0 | -38.3 | +0.00 |
| 15 | 7.800 | 234.0 | step_away | Dimas walking away from the car (shot 3), fading with distance | -16 | -22.0 | -37.4 | -0.40 |
| 16 | 8.250 | 247.5 | step_away | Dimas walking away from the car (shot 3), fading with distance | -17 | -22.9 | -38.3 | -0.44 |
| 17 | 8.600 | 258.0 | car_lock | car lock chirp as he leaves (shot 3) | -17 | -23.0 | -38.3 | +0.30 |
| 18 | 8.700 | 261.0 | step_away | Dimas walking away from the car (shot 3), fading with distance | -18 | -23.8 | -39.2 | -0.48 |
| 19 | 9.150 | 274.5 | step_away | Dimas walking away from the car (shot 3), fading with distance | -19 | -24.7 | -40.1 | -0.52 |
| 20 | 9.480 | 284.4 | whoosh | camera move (frame 288) | -22 | -28.0 | -43.3 | +0.00 |
| 21 | 9.600 | 288.0 | step_away | Dimas walking away from the car (shot 3), fading with distance | -20 | -25.6 | -41.0 | -0.56 |
| 22 | 9.953 | 298.6 | pop | in-scene graphic pops in (frame 298) | -20 | -26.0 | -41.3 | +0.00 |
| 23 | 10.050 | 301.5 | step_away | Dimas walking away from the car (shot 3), fading with distance | -20 | -26.5 | -41.9 | -0.60 |
| 24 | 10.500 | 315.0 | step_away | Dimas walking away from the car (shot 3), fading with distance | -21 | -27.4 | -42.8 | -0.64 |
| 25 | 10.950 | 328.5 | step_away | Dimas walking away from the car (shot 3), fading with distance | -22 | -28.3 | -43.7 | -0.68 |
| 26 | 11.100 | 333.0 | amb_street2 (bed, integrated) | the street after the rain: traffic, breeze, a few birds (shots 4-8) | -31 | -31.0 | -46.3 | +0.00 |
| 27 | 11.340 | 340.2 | gasp1 | Dimas: shock at the broken window (shot 4) | -15 | -21.0 | -36.3 | +0.30 |
| 28 | 12.580 | 377.4 | whoosh | camera move (frame 381) | -22 | -28.0 | -43.3 | +0.00 |
| 29 | 15.483 | 464.5 | photo_flap | Dimas raises the photo (shot 5) | -22 | -28.0 | -43.3 | -0.20 |
| 30 | 16.213 | 486.4 | whoosh | camera move (frame 490) | -22 | -28.0 | -43.3 | +0.00 |
| 31 | 19.900 | 597.0 | dial | the boss dials the insurer (shot 6) | -19 | -25.0 | -40.3 | +0.40 |
| 32 | 21.853 | 655.6 | pop | in-scene graphic pops in (frame 655) | -20 | -26.0 | -41.3 | +0.00 |
| 33 | 23.980 | 719.4 | whoosh | camera move (frame 723) | -22 | -28.0 | -43.3 | +0.00 |
| 34 | 25.380 | 761.4 | whoosh | camera move (frame 765) | -22 | -28.0 | -43.3 | +0.00 |
| 35 | 26.870 | 806.1 | gasp2 | Dimas: shock at "pecat" (shot 7) | -15 | -21.0 | -36.3 | -0.30 |
| 36 | 28.900 | 867.0 | protest | Dimas protesting (shot 8) | -18 | -24.0 | -39.3 | -0.30 |
| 37 | 30.313 | 909.4 | whoosh | camera move (frame 913) | -22 | -28.0 | -43.3 | +0.00 |
| 38 | 32.387 | 971.6 | pop | in-scene graphic pops in (frame 971) | -20 | -26.0 | -41.3 | +0.00 |
| 39 | 34.100 | 1023.0 | amb_rain3 (bed, integrated) | imagined downpour pouring on the car (shot 9) | -17 | -17.0 | -32.3 | +0.00 |
| 40 | 36.547 | 1096.4 | whoosh | camera move (frame 1100) | -22 | -28.0 | -43.3 | +0.00 |
| 41 | 38.500 | 1155.0 | amb_street3 (bed, integrated) | street after the rain, birds come back (shots 10-13) | -30 | -30.0 | -45.3 | +0.00 |
| 42 | 40.687 | 1220.6 | pop | in-scene graphic pops in (frame 1220) | -20 | -26.0 | -41.3 | +0.00 |
| 43 | 42.213 | 1266.4 | whoosh | camera move (frame 1270) | -22 | -28.0 | -43.3 | +0.00 |
| 44 | 42.887 | 1286.6 | pop | in-scene graphic pops in (frame 1286) | -20 | -26.0 | -41.3 | +0.00 |
| 45 | 44.817 | 1344.5 | windup | hammer wind-up whoosh (shot 11) | -20 | -26.0 | -41.3 | +0.00 |
| 46 | 45.267 | 1358.0 | glass | window shatters, shards rain onto the road (shot 11) | -8 | -14.0 | -29.3 | +0.00 |
| 47 | 45.267 | 1358.0 | hammer | hammer hits the glass (shot 11) | -10 | -16.0 | -31.3 | +0.00 |
| 48 | 46.447 | 1393.4 | whoosh | camera move (frame 1397) | -22 | -28.0 | -43.3 | +0.00 |
| 49 | 46.667 | 1400.0 | birds_back (bed, integrated) | the rain has stopped: birds (shot 11-12) | -27 | -27.0 | -42.3 | +0.00 |
| 50 | 48.587 | 1457.6 | pop | in-scene graphic pops in (frame 1457) | -20 | -26.0 | -41.3 | +0.00 |
| 51 | 49.520 | 1485.6 | pop | in-scene graphic pops in (frame 1485) | -20 | -26.0 | -41.3 | +0.00 |
| 52 | 53.033 | 1591.0 | plip | one lonely drop falls on the dry seat (last word) | -12 | -18.0 | -33.3 | +0.00 |
