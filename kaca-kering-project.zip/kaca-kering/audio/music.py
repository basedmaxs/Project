# Score of "Kaca Kering": a small comic-noir band (pizzicato bass, vibes, brush, pad, timpani, glock) at 96 bpm in A minor.
# Sections follow the shots; the smash gets a roll + stab, the last word a falling horn.
import numpy as np
from dsp import SR, ns, tt, rng, dbg, lp, hp, pan, st, place, fades, make_ir, convolve_st, integrated
import instruments as I
import timeline as T

N = ns(T.DUR)
Q = 0.625            # quarter note (s) at 96 bpm
BAR = 4 * Q
F = I.m2f

# (name, start s, end s)
SECTIONS = [("hook", 0.0, 3.73), ("report", 3.73, 13.9), ("doubt", 13.9, 21.87), ("twist", 21.87, 34.17), ("rain", 34.17, 38.97),
            ("reveal", 38.97, 44.3), ("scheme", 44.3, 50.73), ("outro", 50.73, T.DUR)]

class Band:
    def __init__(self):
        self.tr = {}
        self.send = {}
        self.cues = []

    def track(self, name, send):
        if name not in self.tr:
            self.tr[name] = np.zeros((2, N))
            self.send[name] = send
        return self.tr[name]

    def add(self, name, x, t, p=0.0, g=1.0, send=0.15):
        buf = self.track(name, send)
        place(buf, pan(x, p) if np.ndim(x) == 1 else x, t, g)



R = rng(1831)


def _r():
    return rng(int(R.integers(1 << 30)))


ROOT = {"Am": 45, "C": 48, "F": 41, "G": 43, "Dm": 38, "E7": 40}
TONES = {"Am": [57, 60, 64], "C": [55, 60, 64], "F": [57, 60, 65], "G": [55, 59, 62], "Dm": [57, 62, 65], "E7": [56, 59, 62]}


def walk(b, t0, t1, prog, vel=0.55, comp=True, brush=True, stac=1.0):
    """pizzicato walking bass on every beat, vibes 'pah' on 2 and 4, brushes"""
    k = 0
    t = t0
    while t < t1 - 0.05:
        ch = prog[k % len(prog)]
        r0 = ROOT[ch]
        for beat, n in enumerate([r0, r0 + 7, r0 + 12 if beat_odd(k) else r0 + 5, r0 + 4 if ch in ("C", "E7") else r0 + 3]):
            tb = t + beat * Q
            if tb >= t1 - 0.05:
                break
            b.add("pluck", I.pluck(F(n), vel * (1.0 if beat == 0 else 0.8), _r(), 0.5 * stac, 0.45), tb, p=-0.15, send=0.1)
            if comp and beat in (1, 3):
                for m in TONES[ch][:2]:
                    b.add("vibes", I.vibes(F(m + 12), 0.34 * vel, _r(), 0.9), tb + 0.01, p=0.25, send=0.3)
            if brush and beat in (1, 3):
                b.add("brush", I.brush(0.5, _r(), 0.3), tb, p=0.4, send=0.05)
        t += BAR
        k += 1


def beat_odd(k):
    return k % 2 == 1


def pulse(b, t0, t1, note, v0, v1, step=Q / 2):
    n = max(1, int((t1 - t0) / step))
    for i in range(n):
        u = i / n
        b.add("pluck", I.pluck(F(note), v0 + (v1 - v0) * u, _r(), 0.25, 0.4), t0 + i * step, p=-0.1, send=0.08)


def build():
    b = Band()
    c = b.cues.append
    # ---- hook: nervous pulse on A under a thin pad, a low hit as the title situation lands
    b.add("pad", I.pad([F(45), F(52), F(57), F(60)], 3.7, 0.5, _r(), att=0.5, rel=0.4, warm=700), 0.0, send=0.35)
    pulse(b, 0.0, 3.55, 45, 0.35, 0.7)
    b.add("timpani", I.timpani(F(33), 0.8, _r(), 1.6), 3.55, send=0.3)
    c((0.0, "hook: nervous 8th-note pulse on A + pad (Dimas arrives panicked)"))
    # ---- report: light walking noir, theme on vibes
    walk(b, 3.73, 13.9, ["Am", "Am", "Dm", "E7"], 0.55)
    for i, (m, dt) in enumerate([(69, 0), (72, 1), (76, 2), (74, 3), (72, 5), (69, 6)]):
        b.add("musicbox", I.musicbox(F(m), 0.5, _r(), 1.4), 3.73 + dt * Q * 1.0 + 0.0, p=0.35, send=0.35)
    b.add("stab", I.brass(F(57), 0.18, 0.7, _r(), "stab"), 5.0 + 0.0, p=-0.3, g=0.5, send=0.2) if False else None
    c((3.73, "report: walking pizzicato bass in A minor, brushes, vibes pah, music-box phrase"))
    b.add("glock", I.glock(F(88), 0.5, _r(), 1.2), 5.22, p=0.4, send=0.3)       # price badge
    b.add("glock", I.glock(F(84), 0.5, _r(), 1.2), 9.93, p=0.4, send=0.3)       # 1 JAM
    b.add("timpani", I.timpani(F(38), 0.6, _r(), 1.2), 11.3, send=0.3)          # window found broken
    # ---- doubt: the boss almost believes, warm major turn
    walk(b, 13.9, 21.87, ["C", "F", "G", "C"], 0.5)
    c((13.9, "doubt: brighter C-F-G walk (boss almost believes, calls the insurer)"))
    # ---- twist: the chief smirks; tension builds under the accusation, thins out for "one small detail"
    b.add("pad", I.pad([F(38), F(50), F(57), F(62)], 8.2, 0.5, _r(), att=1.0, rel=0.6, warm=600), 21.87, send=0.35)
    pulse(b, 21.87, 23.9, 38, 0.3, 0.55)
    b.add("timpani", I.timpani(F(36), 0.9, _r(), 1.8), 24.1, send=0.3)           # smirk
    b.add("stab", I.brass(F(50), 0.22, 0.8, _r(), "stab"), 24.1, p=-0.2, send=0.25)
    pulse(b, 24.1, 29.0, 40, 0.35, 0.75)
    b.add("timpani", I.timpani(F(36), 0.8, _r(), 1.4), 25.85, send=0.3)          # "menyuruh bosnya memecat"
    b.add("timpani", I.timpani(F(33), 1.0, _r(), 1.8), 26.87, send=0.3)          # "Dimas": shock
    b.add("brush", I.brush(0.7, _r(), 0.35, True), 28.0, send=0.1)
    for i in range(14):                                                           # a ticking hush under "satu detail kecil"
        b.add("brush", I.brush(0.3 + 0.02 * i, _r(), 0.15), 30.4 + i * Q / 2, p=0.3, send=0.05)
    b.add("glock", I.glock(F(93), 0.6, _r(), 1.4), 32.37, p=0.3, send=0.35)       # the ring lands on the seat
    c((21.87, "twist: pad + pulse, timpani on the smirk, stab on the order, hush for the small detail"))
    # ---- rain: the imagined downpour, drips on glock over a slow pad
    b.add("pad", I.pad([F(50), F(57), F(62)], 4.7, 0.4, _r(), att=0.8, rel=0.5, warm=800), 34.17, send=0.4)
    for i in range(11):
        b.add("glock", I.glock(F([86, 89, 93, 91, 88, 84, 91, 93, 86, 89, 84][i]), 0.35, _r(), 0.9), 34.5 + i * 0.4, p=-0.5 + 0.1 * i, send=0.4)
    c((34.17, "rain: slow pad + glock drips (what should have happened)"))
    # ---- reveal: ascending vibes, the two labels ping, snare roll into the smash
    walk(b, 38.97, 44.3, ["Dm", "G", "C", "E7"], 0.6)
    b.add("glock", I.glock(F(96), 0.7, _r(), 1.4), 40.7, p=0.3, send=0.35)        # KERING
    b.add("glock", I.glock(F(91), 0.7, _r(), 1.4), 42.87, p=-0.3, send=0.35)      # BASAH
    b.add("snare", I.snare_roll(44.35, T.SMASH - 0.02, 0.15, 0.95, _r()), 44.35 - 44.35 + 0.0, send=0.2) if False else None
    c((38.97, "reveal: Dm-G-C-E7 walk; glock pings on the labels"))
    # ---- scheme: the smash, then a sneaky walk
    b.add("timpani", I.timpani(F(33), 1.0, _r(), 1.6), T.SMASH, send=0.3)
    b.add("stab", I.brass(F(45), 0.3, 0.9, _r(), "stab"), T.SMASH, p=-0.2, send=0.3)
    b.add("cymbal", I.cymbal(0.6, _r(), 1.8), T.SMASH, send=0.3)
    walk(b, 46.2, 50.73, ["Am", "Am", "E7", "Am"], 0.42, comp=True, brush=False, stac=0.6)
    b.add("glock", I.glock(F(88), 0.55, _r(), 1.2), 48.57, p=0.4, send=0.3)       # laptop -> money
    b.add("glock", I.glock(F(93), 0.55, _r(), 1.2), 49.47, p=0.4, send=0.3)       # insurance claim
    c((T.SMASH, "smash: timpani + brass stab + cymbal on the hammer, then a sneaky pizzicato walk"))
    # ---- outro: everything thins; one falling horn after the lonely drop
    b.add("pad", I.pad([F(45), F(52), F(57)], 2.5, 0.35, _r(), att=0.4, rel=0.4, warm=600), 50.73, send=0.4)
    b.add("tuba", I.brass(F(50), 0.42, 0.85, _r(), "horn", fall=-7), T.DROP + 0.1, p=0.0, send=0.3)
    c((50.73, "outro: soft pad, falling horn after the drop (last word)"))
    for k in b.tr:
        b.tr[k] *= np.ones(N)[None, :]
    return b


TARGET = {  # relative balance inside the band (LU, measured on each track's own active span)
    "whistle": 0.0, "fife": -3.0, "glock": -6.0, "tuba": -2.5, "pah": -7.5, "snare": -5.5, "cymbal": -11.0,
    "stab": -3.0, "timpani": -5.0, "pad": -3.5, "vibes": -2.0, "musicbox": -1.5, "pluck": -4.0, "brush": -13.0, "triangle": -15.0,
}


def render(b, ref=-20.0):
    hall = make_ir(1.5, 7, pre=0.018, hf=1.4)
    yard = make_ir(0.9, 8, pre=0.008, hf=1.8, early=[(0.11, 0.5, -0.4), (0.19, 0.35, 0.5)])
    dry = np.zeros((2, N))
    wet_hall = np.zeros((2, N))
    wet_yard = np.zeros((2, N))
    levels = {}
    for k, x in b.tr.items():
        if not np.any(x):
            continue
        L = integrated(x)
        g = dbg(ref + TARGET.get(k, -6) - L)
        levels[k] = (round(L, 1), round(ref + TARGET.get(k, -6), 1))
        x = x * g
        b.tr[k] = x
        dry += x
        if k == "whistle":
            wet_yard += 0.16 * x
        else:
            wet_hall += b.send[k] * x
    out = dry + 0.7 * convolve_st(wet_hall.mean(0), hall) + 0.8 * convolve_st(wet_yard.mean(0), yard)
    out = hp(out, 30, 2)
    return out, levels
