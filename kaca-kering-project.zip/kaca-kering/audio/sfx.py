# Every sound effect + ambience bed of "Kaca Kering" as a cue list timed to the picture (timeline.py), rendered into one
# stereo SFX stem. Levels follow the standard mix: each EVENT has a "naive" level (LU vs the voice stem) and is placed
# SFX_DB = -6 dB under it; ambience BEDS (integrated loudness) are not reduced.
import math
import numpy as np
from dsp import (SR, ns, tt, rng, dbg, lp, hp, bp, peq, shelf, pan, st, place, fades, widen, make_ir, convolve_st,
                 momentary_max, integrated, colored, smooth_noise, modal, phase)
import sfx_gen as G
import timeline as T

N = ns(T.DUR)
SFX_DB = -6.0


class Cue:
    def __init__(self, t, name, desc, gen, naive, kind="event", p=0.0, extra=0.0, lpf=None, send=0.12, group=None, cut=None):
        self.t, self.name, self.desc, self.gen, self.naive = t, name, desc, gen, naive
        self.kind, self.p, self.extra, self.lpf, self.send, self.cut = kind, p, extra, lpf, send, cut
        self.group = group or name
        self.applied = naive + (SFX_DB if kind == "event" else 0.0) + extra
        self.measured = None



def rain_bed(dur, seed, heavy=0.5):
    def g():
        r = rng(seed)
        n = ns(dur)
        x = bp(colored(n, r, 0.3), 1800, 9000, 1) * (0.6 + 0.4 * heavy) * (0.85 + 0.15 * smooth_noise(n, r, 0.6))
        x += hp(r.standard_normal(n), 6000) * 0.05 * heavy
        return fades(st(x) * 1.0, 0.5, 0.7), 0.0
    return g


def street_bed(dur, seed, birds=0.0):
    def g():
        r = rng(seed)
        n = ns(dur)
        x = lp(colored(n, r, 1.0), 220, 1) * 0.9 * (0.8 + 0.2 * smooth_noise(n, r, 0.2))       # distant traffic rumble
        x = x + G.breeze(dur, r, 0.5, 0.15, 700)
        y = st(x)
        if birds > 0:
            y = y + pan(G.bird_chirps(dur, r, birds, "sparrow") * 0.12, 0.5) + pan(G.bird_chirps(dur, r, birds * 0.7, "sparrow") * 0.08, -0.6)
        return fades(y, 0.5, 0.6), 0.0
    return g


def blip(up=True):
    def g():
        d = 0.14
        t = tt(d)
        f = (620 + 420 * (t / d)) if up else (900 - 300 * (t / d))
        y = np.sin(phase(f)) * np.exp(-t / 0.05) + 0.3 * np.sin(phase(2 * f)) * np.exp(-t / 0.03)
        return fades(y, 0.002, 0.04), 0.0
    return g


def beeps(n, f=1900, gap=0.16):
    def g():
        out = np.zeros(ns(n * gap + 0.2))
        for i in range(n):
            d = 0.09
            t = tt(d)
            y = np.sin(phase(f * np.ones_like(t))) * np.minimum(1, t / 0.004) * np.minimum(1, (d - t) / 0.01)
            a = ns(i * gap)
            out[a:a + len(y)] += y
        return out, 0.0
    return g


def dtmf(seq):
    def g():
        out = np.zeros(ns(len(seq) * 0.14 + 0.2))
        for i, (f1, f2) in enumerate(seq):
            d = 0.09
            t = tt(d)
            y = (np.sin(phase(f1 * np.ones_like(t))) + np.sin(phase(f2 * np.ones_like(t)))) * 0.5 * np.minimum(1, (d - t) / 0.01)
            a = ns(i * 0.14)
            out[a:a + len(y)] += y
        return out, 0.0
    return g


def glass_break(r):
    d = 1.2
    t = tt(d)
    x = hp(r.standard_normal(len(t)), 2500) * np.exp(-t / 0.05) * 1.2
    x += bp(r.standard_normal(len(t)), 800, 3500, 1) * np.exp(-t / 0.02) * 0.8
    out = x
    for i in range(48):
        c = G.clink(r, None, 0.12, 1.4) * r.uniform(0.15, 0.7)
        a = ns(r.uniform(0.0, 0.8) ** 1.5)
        out[a:a + len(c)] += c[: len(out) - a]
    return fades(out, 0.0, 0.2), 0.0


def drop_plip(r):
    d = 0.35
    t = tt(d)
    f = 1100 * np.exp(-t / 0.03) + 500
    y = np.sin(phase(f)) * np.exp(-t / 0.05)
    y += bp(r.standard_normal(len(t)), 1200, 5000, 1) * np.exp(-t / 0.01) * 0.2
    return fades(y, 0.001, 0.1), 0.0


def cues():
    C = []
    R = rng(1831)
    rr = lambda: rng(int(R.integers(1 << 30)))
    add = C.append
    fr = T.fr

    # ------------------------------------------------ beds
    add(Cue(0.0, "amb_rain1", "tail of the rain on the office awning, drips (shots 1-2)", _cut(rain_bed(7.9, 11, 0.4), 7.9, 0.2, 0.6), -26, "bed", send=0.0))
    add(Cue(7.5, "amb_rain2", "steady rain on the parked car and street (shot 3)", _cut(rain_bed(4.2, 12, 0.7), 4.2, 0.4, 0.3), -23, "bed", send=0.0))
    add(Cue(0.0, "amb_street1", "wet city street: traffic rumble, breeze (shots 1-3)", _cut(street_bed(11.4, 21, 0.0), 11.4, 0.3, 0.5), -32, "bed", send=0.0))
    add(Cue(11.1, "amb_street2", "the street after the rain: traffic, breeze, a few birds (shots 4-8)", _cut(street_bed(23.2, 22, 0.35), 23.2, 0.4, 0.5), -31, "bed", send=0.0))
    add(Cue(34.1, "amb_rain3", "imagined downpour pouring on the car (shot 9)", _cut(rain_bed(5.0, 13, 1.0), 5.0, 0.5, 0.6), -17, "bed", send=0.0))
    add(Cue(38.5, "amb_street3", "street after the rain, birds come back (shots 10-13)", _cut(street_bed(15.1, 23, 0.7), 15.1, 0.5, 0.3), -30, "bed", send=0.0))

    # ------------------------------------------------ footsteps
    for k in range(9):  # hook: Dimas hurries (stroll cadence 2.5 steps/s), puddle-wet steps
        t = 0.1 + k * 0.4
        add(Cue(t, "step_hurry", "Dimas' hurried wet footstep (shot 1)", (lambda: (G.stroll_step(rr(), 0.8), 0.0)), -14 - (8 - k) * 0.4, p=0.0, send=0.15, group="step1"))
    for k in range(8):
        t = 7.8 + k * 0.45
        add(Cue(t, "step_away", "Dimas walking away from the car (shot 3), fading with distance", (lambda: (G.stroll_step(rr(), 0.5), 0.0)), -16 - k * 0.9, p=-0.4 - 0.04 * k, lpf=5200, send=0.2, group="step3"))
    add(Cue(8.6, "car_lock", "car lock chirp as he leaves (shot 3)", beeps(2), -17, p=0.3, send=0.25))

    # ------------------------------------------------ reactions
    add(Cue(11.34, "gasp1", "Dimas: shock at the broken window (shot 4)", lambda: (G.whoa(rr(), 130, 0.5), 0.0), -15, p=0.3, send=0.2))
    add(Cue(26.87, "gasp2", "Dimas: shock at \"pecat\" (shot 7)", lambda: (G.whoa(rr(), 128, 0.45), 0.0), -15, p=-0.3, send=0.2))
    add(Cue(28.9, "protest", "Dimas protesting (shot 8)", lambda: (G.oof(rr(), "oof"), 0.0), -18, p=-0.3, send=0.2))
    add(Cue(19.9, "dial", "the boss dials the insurer (shot 6)", dtmf([(697, 1209), (770, 1336), (852, 1477), (941, 1209)]), -19, p=0.4, send=0.15))

    # ------------------------------------------------ graphics + cuts
    for i, f in enumerate(T.POPS):
        add(Cue(T.fr(f) + 0.02, "pop", f"in-scene graphic pops in (frame {f})", blip(True), -20, p=0.0, send=0.2, group="pop"))
    for f in T.GLIDES + [723, 765, 913]:
        add(Cue(T.fr(f) - 0.12, "whoosh", f"camera move (frame {f})", (lambda: (G.whoosh(0.4, rr(), 0.25, 400, 2400), 0.12)), -22, p=0.0, send=0.1, group="whoosh"))
    add(Cue(T.fr(466) - 0.05, "photo_flap", "Dimas raises the photo (shot 5)", (lambda: (G.whoosh(0.2, rr(), 0.3, 900, 3500, 0.6, 0.1), 0.05)), -22, p=-0.2, send=0.1))

    # ------------------------------------------------ the smash
    add(Cue(T.SMASH - 0.45, "windup", "hammer wind-up whoosh (shot 11)", (lambda: (G.whoosh(0.4, rr(), 0.3, 300, 1800), 0.0)), -20, p=0.0, send=0.1))
    add(Cue(T.SMASH, "hammer", "hammer hits the glass (shot 11)", (lambda: (G.hammer_hit(rr(), 0.6), 0.0)), -10, p=0.0, send=0.2))
    add(Cue(T.SMASH, "glass", "window shatters, shards rain onto the road (shot 11)", (lambda: glass_break(rr())), -8, p=0.0, send=0.3))
    add(Cue(T.fr(1400), "birds_back", "the rain has stopped: birds (shot 11-12)", _cut(street_bed(5.0, 31, 1.0), 5.0, 0.5, 0.5), -27, "bed", send=0.0))

    # ------------------------------------------------ the last word
    add(Cue(T.DROP, "plip", "one lonely drop falls on the dry seat (last word)", (lambda: drop_plip(rr())), -12, p=0.0, send=0.5))
    return C


def _cut(gen, dur, fin, fout):
    def g():
        x, a = gen()
        return fades(x, fin, fout), a
    return g


def _env(gen, dur, fin, fout):
    return _cut(gen, dur, fin, fout)


def render(v_ref, on_event=None):
    """v_ref = integrated loudness of the voice stem (stereo). Returns (stereo stem, cue list with measured levels).
    on_event(cue, x, t0) is called with every placed (dry) event, for analysis."""
    C = cues()
    out = np.zeros((2, N))
    send = np.zeros(N)
    for c in C:
        x, anchor = c.gen()
        x = np.asarray(x, float)
        x = pan(x, c.p) if x.ndim == 1 else x
        if c.cut is not None:
            k = ns(c.cut - (c.t - anchor))
            if 0 < k < x.shape[1]:
                x = fades(x[:, :k], 0.0, 0.02)
        tgt = v_ref + c.applied
        cur = momentary_max(x) if c.kind == "event" else integrated(x)
        if np.isfinite(cur):
            x = x * dbg(tgt - cur)
        if c.lpf:
            x = lp(x, c.lpf, 1)
        c.measured = momentary_max(x) - v_ref if c.kind == "event" else integrated(x) - v_ref
        t0 = c.t - anchor
        place(out, x, t0)
        if on_event:
            on_event(c, x, t0)
        if c.send > 0:
            G._place_mono(send, c.send * x.mean(0), t0)
    valley = make_ir(1.1, 77, pre=0.01, hf=1.6, early=[(0.09, 0.45, -0.5), (0.14, 0.3, 0.6), (0.23, 0.2, -0.2)])
    out += 0.55 * convolve_st(send, valley)
    out = hp(out, 25, 2)
    end = ns(T.DUR - 0.12)
    out[:, end:] *= np.linspace(1, 0, N - end)[None, :] ** 2
    return out, C
