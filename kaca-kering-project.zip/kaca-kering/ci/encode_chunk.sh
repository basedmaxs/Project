#!/usr/bin/env bash
# Burn the word captions into frames a..b (captions.py), then encode them to chunks/chunk_NNN.mp4 with exactly the video
# settings of tools/finish.sh, so the stitched file needs no second encode.   bash ci/encode_chunk.sh <a> <b> <index>
set -e; A="$1"; B="$2"; I=$(printf %03d "$3"); mkdir -p chunks
pip install -q pillow 2>/dev/null || true
rm -rf frames_cap
python3 captions.py work/words.json frames --out frames_cap --frames "$A-$B"
ffmpeg -v error -y -framerate 30 -start_number "$A" -i frames_cap/f%04d.jpg -frames:v $((B - A + 1)) \
  -c:v libx264 -preset slow -crf 17 -pix_fmt yuv420p -an "chunks/chunk_$I.mp4"
echo "chunks/chunk_$I.mp4: $(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "chunks/chunk_$I.mp4") frames"
