#!/usr/bin/env python3
"""Burn word captions into rendered frames (run AFTER render.mjs, BEFORE finish.sh).

Usage:
  python3 tools/captions.py work/words.json frames --out frames_cap [--scale 0.85] [--frames 0-99]
  mv frames frames_clean && mv frames_cap frames      # finish.sh reads frames/ (never edited)

Style (measured from the user's reference frames, 540x960 -> x2 = 1080x1920):
  reference: Arial-Black-like bold sans, white fill, black outline + soft drop shadow, centred,
             baseline at y = 1374 px (71.6 % of height), ascender height 52 px (~72 px font).
  ours:      same baseline (same height), size = reference x SCALE (default 0.85 -> ~61 px font).
One word (sometimes 2-3 short ones) per caption, hard swap on each group, no animation.
Pixel values are for 1080x1920 and scale with the frame height / 1920.
"""
import json, os, re, sys
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = next(p for p in (os.path.join(HERE, "fonts", "ArchivoBlack-Regular.ttf"),) if os.path.exists(p))
REF_FONT_PX = 72          # reference font size at 1080x1920
BASELINE_Y = 1374         # reference baseline (same height as the reference)
SCALE = 0.85              # "slightly smaller" than the reference
OUTLINE_REF = 6           # px at the reference size
SHADOW_REF = (3, 4)       # px offset at the reference size
MAX_W = 0.88              # caption never wider than 88 % of the frame
LEAD = 0                  # frames a caption appears before its word (0 = on the word)

def groups(words):
    """Group words: a short word (<= 3 letters) waits for the next word; max 3 words; punctuation ends a group."""
    out, cur = [], []
    for w in words:
        cur.append(w); t = w["w"]
        letters = re.sub(r"[^A-Za-z0-9]", "", t)
        ends = bool(re.search(r"[,.;:!?\"”]$", t))
        if ends or len(cur) >= 3 or (len(letters) > 3 and len(cur) >= 1):
            out.append(cur); cur = []
    if cur: out.append(cur)
    return [{"text": " ".join(x["w"] for x in g), "s": g[0]["s"], "e": g[-1]["e"]} for g in out]

def timeline(groups_, fps=30, hold=0.25):
    """caption i is visible from its start to the next caption's start (hold through gaps <= hold s, else to its own end)."""
    tl = []
    for i, g in enumerate(groups_):
        a = int(round(g["s"] * fps)) - LEAD
        nxt = groups_[i + 1]["s"] if i + 1 < len(groups_) else g["e"] + hold
        b_t = nxt if (nxt - g["e"]) <= hold else g["e"] + hold
        tl.append((a, int(round(b_t * fps)), g["text"]))
    return tl

def draw_caption(im, text, scale=SCALE):
    H = im.height; k = H / 1920
    size = max(8, int(round(REF_FONT_PX * scale * k)))
    font = ImageFont.truetype(FONT, size)
    ow = max(1, int(round(OUTLINE_REF * scale * k))); sx, sy = (int(round(v * scale * k)) for v in SHADOW_REF)
    while font.getlength(text) > im.width * MAX_W and size > 8:
        size -= 2; font = ImageFont.truetype(FONT, size)
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    x = im.width / 2; y = BASELINE_Y * k
    d.text((x + sx, y + sy), text, font=font, anchor="ms", fill=(0, 0, 0, 150), stroke_width=ow, stroke_fill=(0, 0, 0, 150))
    d.text((x, y), text, font=font, anchor="ms", fill=(255, 255, 255, 255), stroke_width=ow, stroke_fill=(0, 0, 0, 255))
    return Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB")

def main():
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    opt = lambda n, d=None: sys.argv[sys.argv.index(n) + 1] if n in sys.argv else d
    words = json.load(open(a[0])); src = a[1]; out = opt("--out", "frames_cap"); scale = float(opt("--scale", SCALE))
    os.makedirs(out, exist_ok=True)
    files = sorted(f for f in os.listdir(src) if re.match(r"f\d{4}\.jpg$", f))
    rng = opt("--frames")
    if rng: lo, hi = map(int, rng.split("-")); files = [f for f in files if lo <= int(f[1:5]) <= hi]
    tl = timeline(groups(words))
    for f in files:
        n = int(f[1:5]); im = Image.open(os.path.join(src, f)).convert("RGB")
        t = next((c for s, e, c in tl if s <= n < e), None)
        if t: im = draw_caption(im, t, scale)
        im.save(os.path.join(out, f), quality=95, subsampling=0)
    print(f"{len(files)} frames -> {out}  ({len(tl)} captions, scale {scale})")

if __name__ == "__main__":
    main()
