# Kaggle runner: parallel render of every frame + burned-in karaoke subtitles + audio -> one MP4.
# Usage (notebook cells):  !python kaggle_render.py setup | render | encode     (or: all)
import glob, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

TOTAL = 1478                       # frames (49.27 s at 30 fps)
CHUNK = 37                         # frames per browser launch (1478 = 40 x 37): good load balancing
TITLE = "Pak-Hendra-dan-Es-Krim"
CLEAN = False                      # True: also write a version without subtitles
PW = "1.63.0"
W = "/kaggle/working/proj"

def sh(cmd, check=True, env=None):
    print("$", cmd, flush=True)
    return subprocess.run(cmd, shell=True, check=check, env=env)

def bundle():
    hit = glob.glob("/kaggle/input/**/render.mjs", recursive=True)
    assert hit, "render.mjs not found: add the dataset to the notebook (Add Input)"
    return os.path.dirname(hit[0])


def psnr(a, b):
    r = subprocess.run(f'ffmpeg -hide_banner -i {a} -i {b} -lavfi psnr -f null -', shell=True, capture_output=True, text=True).stderr
    m = re.search(r"average:([0-9.]+|inf)", r)
    return 99.0 if (m and m.group(1) == "inf") else float(m.group(1)) if m else 0.0

def bench(mode, n, tag):
    """n parallel browsers x 2 frames each: seconds for 2n frames (frames 700..)"""
    out = f"bench_{tag}"; shutil.rmtree(out, ignore_errors=True)
    env = dict(os.environ, MODE=mode)
    t0 = time.time()
    ps = [subprocess.Popen(f'node render2.mjs {out} "{700 + 2 * k}-{701 + 2 * k}" > /dev/null 2>&1', shell=True, env=env) for k in range(n)]
    ok = all(p.wait() == 0 for p in ps)
    return (time.time() - t0, out) if ok and len(glob.glob(f"{out}/*.jpg")) == 2 * n else (None, out)

def pick_mode():
    n = max(1, os.cpu_count() or 1)
    t_cpu, d_cpu = bench("cpu", n, "cpu")
    info = {"mode": "cpu", "cpu_s_per_frame": t_cpu / (2 * n) if t_cpu else None}
    print(f"CPU: {t_cpu:.1f} s for {2 * n} frames with {n} browsers -> {t_cpu / (2 * n):.2f} s/frame effective", flush=True)
    if shutil.which("nvidia-smi"):
        sh("nvidia-smi -L", check=False)
        for m in ("g1", "g2", "g3"):
            r = subprocess.run(f"PROBE=1 MODE={m} node render2.mjs x 0 2>&1 | grep RENDERER", shell=True, capture_output=True, text=True).stdout.strip()
            print(m, r, flush=True)
            if not r or re.search(r"swiftshader|llvmpipe|softpipe|software|none|unknown", r, re.I):
                continue
            t_g, d_g = bench(m, n, m)
            if not t_g:
                continue
            q = psnr(f"{d_g}/f0700.jpg", f"{d_cpu}/f0700.jpg")
            print(f"GPU {m}: {t_g / (2 * n):.2f} s/frame effective, PSNR vs CPU {q:.1f} dB", flush=True)
            # a GPU path is taken only if clearly faster AND pixel-equivalent to the CPU render (else chunks could differ in look)
            if t_g < t_cpu / 1.3 and q >= 40 and t_g / (2 * n) < (info.get("gpu_s_per_frame") or 1e9):
                info.update(mode=m, gpu_s_per_frame=t_g / (2 * n))
    print("MODE ->", info, flush=True)
    json.dump(info, open("mode.json", "w"))
    for d in glob.glob("bench_*"):
        shutil.rmtree(d, ignore_errors=True)

def setup():
    if not os.path.exists(W):
        shutil.copytree(bundle(), W)
    os.chdir(W)
    v = subprocess.run("node -v", shell=True, capture_output=True, text=True).stdout.strip().lstrip("v").split(".")[0] if shutil.which("node") else "0"
    if not v.isdigit() or int(v) < 18:
        sh("curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs")
    sh("apt-get install -y fonts-dejavu-core ffmpeg >/dev/null 2>&1 || true", check=False)
    if not os.path.exists("node_modules/playwright"):
        sh("npm init -y >/dev/null && npm i playwright@%s" % PW)
    sh("npx playwright install --with-deps chromium")
    sh("python3 make_subs.py work/words.json subs.ass subs.srt")
    print("cpus:", os.cpu_count())
    pick_mode()

def render():
    os.chdir(W)
    os.makedirs("frames", exist_ok=True)
    def have(a, b):
        return all(os.path.exists(f"frames/f{f:04d}.jpg") for f in range(a, b + 1))
    jobs = [(a, min(a + CHUNK - 1, TOTAL - 1)) for a in range(0, TOTAL, CHUNK)]
    todo = [j for j in jobs if not have(*j)]
    n = max(1, os.cpu_count() or 1)
    print(f"{len(todo)} chunks, {n} parallel workers", flush=True)
    mode = json.load(open("mode.json"))["mode"] if os.path.exists("mode.json") else "cpu"
    print("render mode:", mode, flush=True)
    env = dict(os.environ, RESUME="1", MODE=mode)
    t0 = time.time(); done = [0]
    def run(j):
        sh(f'node render2.mjs frames "{j[0]}-{j[1]}" 2>&1 | grep -v "^PAGE" | tail -2', env=env)
        done[0] += 1
        el = time.time() - t0
        print(f"[{done[0]}/{len(todo)}] {el / 60:.1f} min elapsed, ETA {el / done[0] * (len(todo) - done[0]) / 60:.1f} min", flush=True)
    with ThreadPoolExecutor(n) as ex:
        list(ex.map(run, todo))
    miss = [f for f in range(TOTAL) if not os.path.exists(f"frames/f{f:04d}.jpg")]
    assert not miss, f"missing frames: {miss[:10]} ... run render again (it resumes)"
    print("all", TOTAL, "frames rendered")

def encode():
    os.chdir(W)
    wav = "mix_final.wav"
    ain = f'-i {wav}' if os.path.exists(wav) else ""
    amap = "-map 0:v:0 -map 1:a:0 -c:a aac -b:a 192k -shortest" if ain else "-an"
    os.makedirs("out", exist_ok=True)
    base = f'ffmpeg -v error -y -framerate 30 -i frames/f%04d.jpg {ain} {{vf}} {amap} -c:v libx264 -preset slow -crf 17 -threads 0 -pix_fmt yuv420p -movflags +faststart'
    sh(base.format(vf='-vf "ass=subs.ass"') + f' "out/{TITLE}.mp4"')
    if CLEAN:
        sh(base.format(vf="") + f' "out/{TITLE}-tanpa-subtitle.mp4"')
    shutil.copy("subs.srt", f"out/{TITLE}.srt")
    n = subprocess.run(f'ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "out/{TITLE}.mp4"', shell=True, capture_output=True, text=True).stdout.strip()
    print("frames in video:", n, "expected", TOTAL)
    sh(f'ffmpeg -v error -y -i "out/{TITLE}.mp4" -vf "fps=2,scale=180:-1,tile=10x4" -frames:v 1 out/qa_sheet.jpg')
    for f in glob.glob("out/*"):
        shutil.copy(f, "/kaggle/working/")
    shutil.rmtree(W, ignore_errors=True)       # keep Output small: only the mp4 / srt / qa sheet
    print("DONE ->", f"/kaggle/working/{TITLE}.mp4")

if __name__ == "__main__":
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    if stage == "setup" or stage == "all": setup()
    if stage == "render" or stage == "all": render()
    if stage == "encode" or stage == "all": encode()
