#!/usr/bin/env bash
# builds kaggle_bundle/ + pak-hendra-render.zip (upload the zip as a Kaggle Dataset)
set -e; cd "$(dirname "$0")/.."
node build.mjs . >/dev/null
rm -rf kaggle_bundle; mkdir -p kaggle_bundle/work
cp -r web render.mjs kaggle/render2.mjs kaggle_bundle/
cp work/words.json kaggle_bundle/work/
cp kaggle/make_subs.py kaggle/kaggle_render.py kaggle_bundle/
[ -f mix_final.wav ] && cp mix_final.wav kaggle_bundle/ && echo "audio included" || echo "WARNING: mix_final.wav not found, video would be silent"
rm -f pak-hendra-render.zip; (cd kaggle_bundle && zip -qr ../pak-hendra-render.zip .)
ls -la pak-hendra-render.zip
