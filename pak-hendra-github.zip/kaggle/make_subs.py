# words.json (from timing.py) -> subs.ass (burned-in, karaoke highlight of the spoken word) + subs.srt
import json, sys, re
words = json.load(open(sys.argv[1], encoding="utf-8"))
out_ass, out_srt = sys.argv[2], sys.argv[3]
MAXW, END = 5, re.compile(r"[.,:;?!]$")
groups, cur = [], []
for w in words:
    cur.append(w)
    if END.search(w["w"]) or len(cur) >= MAXW:
        groups.append(cur); cur = []
if cur: groups.append(cur)
def ts_ass(t): h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60; return f"{h}:{m:02d}:{s:05.2f}"
def ts_srt(t): h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60); ms = int(round((t - int(t)) * 1000)); return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
hdr = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,68,&H0000E5FF,&H00FFFFFF,&H00140A0A,&H80000000,-1,0,0,0,100,100,0,0,1,7,2,2,90,90,430,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
ass, srt = [hdr], []
for i, g in enumerate(groups):
    s0 = float(g[0]["s"]) - 0.06
    nxt = float(groups[i + 1][0]["s"]) - 0.06 if i + 1 < len(groups) else 1e9
    e0 = min(float(g[-1]["e"]) + 0.30, nxt - 0.02)
    parts = ["{\\k6}"]
    for j, w in enumerate(g):
        end = float(g[j + 1]["s"]) if j + 1 < len(g) else float(g[-1]["e"]) + 0.05
        parts.append("{\\k%d}%s " % (max(1, round((end - float(w["s"])) * 100)), w["w"]))
    ass.append(f"Dialogue: 0,{ts_ass(max(0, s0))},{ts_ass(e0)},Default,,0,0,0,,{''.join(parts).strip()}\n")
    srt.append(f"{i + 1}\n{ts_srt(max(0, s0))} --> {ts_srt(e0)}\n{' '.join(w['w'] for w in g)}\n")
open(out_ass, "w", encoding="utf-8").write("".join(ass))
open(out_srt, "w", encoding="utf-8").write("\n".join(srt))
print(len(groups), "subtitle lines")
