// Our cast as lit flat sprites in the 3D world. Each frame every character asks for a drawing (a key + a draw call);
// the pool keeps one canvas per distinct drawing, so soldiers marching in step share canvases (7 head shapes x 4
// outfits). Characters are yaw-only billboards shaded by cardShade() (scene tint, bright floor, side gradient toward
// the sun, painted crescent in the drawing); standing ones get a soft multiply contact blob. Effects are unlit cards.
// Cards, effects and blobs live on the NOINK layer so the world ink pass never outlines their quads.
import * as THREE from "three";
import {
  Pen, bodyFront, bodySide, fxBurst, fxStars, fxShadow, fxContact, fxMarble, fxChalk, fxPuff, fxDrop, fxSweat, fxBang, fxCones, fxBag, fxSpeed, SKINS,
  Outfit, Expr, FrontOpts, SideOpts,
} from "./toon";
import {
  FPS, TY, HEN, CAR0, MC, TIRE, WIN, NKIDS, T_CALL, T_ARRIVE, T_FLEE, T_RUNOUT0, T_RUNOUT1, T_THROW0, MARBLES, CONE_KID, CAR_T0, CAR_T1, V3,
  SHOTS, kidAt, kidSpot, marbleAt, nbRun, henSits, carAt, clamp01, smooth, hash as hh,
} from "./story";
import { NOINK } from "./ink";
import { cardShade, blobMaterial, CARD_K } from "./cardshade";

// ---------------- canvas pool ----------------
type Entry = { cv: HTMLCanvasElement; tex: THREE.CanvasTexture; w: number; h: number };
export type Req = { key: string; w: number; h: number; k: number; draw: (p: Pen) => void; tex?: THREE.CanvasTexture };
const makeEntry = (w: number, h: number): Entry => {
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return { cv, tex, w, h };
};
export class Pool {
  private live = new Map<string, Entry>();
  private free: Entry[] = [];
  private reqs: Req[] = [];
  req(key: string, w: number, h: number, k: number, draw: (p: Pen) => void) {
    const r: Req = { key: `${w}x${h}|${key}`, w, h, k, draw };
    this.reqs.push(r);
    return r;
  }
  flush() {
    const want = new Map<string, Req[]>();
    for (const r of this.reqs) { const l = want.get(r.key); if (l) l.push(r); else want.set(r.key, [r]); }
    for (const [key, e] of this.live) if (!want.has(key)) { this.live.delete(key); this.free.push(e); }
    for (const [key, rs] of want) {
      let e = this.live.get(key);
      if (!e) {
        const r = rs[0], i = this.free.findIndex((x) => x.w === r.w && x.h === r.h);
        e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
        const g = e.cv.getContext("2d")!;
        g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, e.w, e.h); g.setTransform(r.k, 0, 0, r.k, 0, 0);
        r.draw(new Pen(g));
        e.tex.needsUpdate = true;
        this.live.set(key, e);
      }
      for (const r of rs) r.tex = e.tex;
    }
    this.reqs = [];
  }
}

// ---------------- sprite meshes ----------------
const blank = (() => { const c = document.createElement("canvas"); c.width = c.height = 2; return new THREE.CanvasTexture(c); })();
export const SU = 0.00216; // metres per design unit: 1000 units = 2.16 m
export const SU_SWING = 2.3 / 1830; // swing canvas: rope of 1830 units = 2.3 m
const BODY = (() => { const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU); g.translate(0, (975 - 500) * SU, 0); return g; })();
const CARD = new THREE.PlaneGeometry(1, 1);
/** world roots that hold actors (to find the scene's sun when world.ts does not pass it) */
const ROOTS = new Set<THREE.Object3D>();

/** lit flat character: cardShade() material, receives shadows (dims to the bright floor only), casts its silhouette
 *  when world.ts says so (golden). Drawn after the contact blobs (renderOrder 1). */
export class Actor {
  mesh: THREE.Mesh; mat: THREE.MeshLambertMaterial; dmat: THREE.MeshDepthMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D, geo: THREE.BufferGeometry = BODY) {
    this.mat = cardShade(new THREE.MeshLambertMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide }));
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.dmat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.customDepthMaterial = this.dmat;
    // rim width is in output pixels: tell the card shader the render height (1920 = 1080 x 1920 frame)
    this.mesh.onBeforeRender = (r) => { const rt = r.getRenderTarget(); CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920; };
    this.mesh.castShadow = false; this.mesh.receiveShadow = true; this.mesh.visible = false;
    this.mesh.rotation.order = "YXZ"; this.mesh.renderOrder = 1; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
    ROOTS.add(parent);
  }
  bind() { const t = this.r?.tex; if (t) { this.mat.map = t; this.dmat.map = t; } }
}
/** unlit effect card: hard cut-out (ink drawings), soft see-through (dust, mist) or a multiply ground blob */
export class Fx {
  mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; soft: THREE.MeshBasicMaterial; blob: THREE.MeshBasicMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.soft = new THREE.MeshBasicMaterial({ map: blank, transparent: true, depthWrite: false, side: THREE.DoubleSide });
    this.blob = blobMaterial(blank);
    this.mesh = new THREE.Mesh(CARD, this.mat);
    this.mesh.visible = false; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
  }
  use(soft: boolean) { this.mesh.material = soft ? this.soft : this.mat; }
  bind() {
    const t = this.r?.tex;
    if (!t) return;
    if (this.r!.key.includes("|blob|")) {
      // no mipmaps: at grazing views the mip chain averages the blob with its white surround and it fades out
      if (t.generateMipmaps) { t.generateMipmaps = false; t.minFilter = THREE.LinearFilter; t.needsUpdate = true; }
      this.blob.map = t; this.mesh.material = this.blob; this.mesh.renderOrder = 0.5;
    }
    else { this.mat.map = t; this.soft.map = t; this.mesh.renderOrder = 0; }
  }
}

// ---------------- placements ----------------
export type Place = {
  key: string; draw: (p: Pen) => void; x: number; y: number; z: number;
  scale?: number; mirror?: boolean; yaw?: number; geo?: "body" | "swing"; roll?: number; size?: [number, number, number];
};
export type FxPlace = { key: string; cw: number; ch: number; draw: (p: Pen) => void; x: number; y: number; z: number; w: number; h: number; flat?: boolean; rot?: number; soft?: boolean };
/** sun = world direction TOWARD the sun (optional: when absent the scene's shadow-casting light is used) */
export type CamInfo = { pos: THREE.Vector3; right: THREE.Vector3; sun?: THREE.Vector3 };

const q = (v: number, n = 120) => Math.round(v * n) / n;
/** head-shape seed: 7 shapes, so marching soldiers in step still share canvases */
const seedOf = (i: number) => ((i * 5 + 3) % 7) + 1;
/** drawing resolution by distance: [canvas w, h, scale from the 600 x 1000 design]; sized for the 1440 x 2560 final */
const tier = (d: number): [number, number, number] =>
  d < 3.2 ? [1800, 3000, 3.0] : d < 6.5 ? [1080, 1800, 1.8] : d < 16 ? [480, 800, 0.8] : [240, 400, 0.4];

// ---------------- light ----------------
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME: "day" | "golden" = "day";
const sunOf = (root: THREE.Object3D) => {
  let s: THREE.DirectionalLight | null = null;
  root.traverse((o) => { if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o; });
  return s as THREE.DirectionalLight | null;
};
/** the sun of the world that is calling: the attached root whose sun target sits on this camera's view axis */
const findSun = (cam: CamInfo, out: THREE.Vector3) => {
  if (cam.sun) return out.copy(cam.sun).normalize();
  let best: THREE.DirectionalLight | null = null, err = Infinity;
  for (const r of ROOTS) {
    if (!r.parent) continue;
    const s = sunOf(r);
    if (!s) continue;
    const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
    if (e < err) { err = e; best = s; }
  }
  return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
/** canvas angle the sun comes FROM on an upright card facing the camera, in 45-degree steps (small texture cache) */
const light2D = (cam: CamInfo, mirror: boolean) => {
  const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
  return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};

/** front / side view and mirroring for someone at (x, z) walking along (dx, dz); fs = foreshortening of the walk */
const viewOf = (cam: CamInfo, x: number, z: number, dx: number, dz: number) => {
  const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
  const c = (tx * dx + tz * dz) / tl;
  return { side: c < 0.57, mirror: dx * cam.right.x + dz * cam.right.z < 0, fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20 };
};

// ---------------- life: blinks and reaction timing ----------------
/** reference expression and action changes land 0-3 f before the word onset */
const LEAD = 2 / FPS;
/** eyelid 0 open .. 1 shut. Reference: gaps 0.5-2.3 s, 4-frame blink half / shut / shut / half, plus a blink across
 *  every expression swap (the shut frames hide the swap) */
const LID = [0.5, 1, 1, 0.5];
const SWAPS: Record<number, number[]> = {};
const lidAt = (t: number, i: number, swaps: number[] = []) => {
  const f = Math.round(t * FPS);
  for (const ts of swaps) { const k = f - Math.round((ts - LEAD) * FPS) + 1; if (k >= 0 && k < 4) return LID[k]; }
  let s = Math.round(-60 * hh(i, 9));
  for (let n = 0; s <= f && n < 400; n++) {
    const k = f - s;
    if (k >= 0 && k < 4) return LID[k];
    s += Math.round(15 + 54 * hh(i * 31 + n, 13)); // next blink 0.5-2.3 s later
  }
  return 0;
};
const fkey = (o: object) => JSON.stringify(o, (_k, v) => (typeof v === "number" ? q(v) : v));

type Who = { i: number; o: Outfit; okey: string };
/** one character drawing in the 600 x 1000 design space, sized by distance, lit from the scene's sun */
const person = (cam: CamInfo, who: Who, x: number, y: number, z: number, view: { side: boolean; mirror: boolean }, fo: FrontOpts, so: SideOpts, scale = 1): Place & { tierKey: string } => {
  const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
  const [w, h, k] = tier(d);
  const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
  const f2: FrontOpts = { ...fo, light, seed }, s2: SideOpts = { ...so, light, seed };
  const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
  return {
    key, x, y, z, scale, mirror, tierKey: `${w}`,
    draw: (p) => (view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2)),
    size: [w, h, k],
  };
};

/** ground shadow under a standing / sitting card (review rounds 2-4), multiply, blue-violet: a TIGHT contact pool right under
 *  the feet (~.5 on screen at the core) so nobody floats, plus by day (cards cast no real shadow) a lighter soft tail
 *  stretched AWAY from the sun, length ~1.6 m / tan(sun elevation), capped. Golden: world.ts casts real card shadows. */
const CONTACT: Record<"day" | "golden", [number, number, number]> = { day: [0.2, 0.21, 0.33], golden: [0.24, 0.2, 0.33] };
const TAIL: [number, number, number] = [0.42, 0.44, 0.62];
const toSrgb = (v: number) => { const c = clamp01(v); return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055; };
const hexOf = (c: [number, number, number], k: number) => "#" + c.map((v) => Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out: Stage, x: number, y: number, z: number, sc = 1, k = 1) => {
  const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
  if (LNAME === "day") {
    const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
    const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h; // feet at v = .2 of the card
    const tc = hexOf(TAIL, k);
    out.fx.push({ key: `blob|shadow|${tc}`, cw: 128, ch: 256, draw: (p) => fxShadow(p, tc), x: x + ox * c, y: y + 0.018, z: z + oz * c,
      w: 0.72 * sc, h, flat: true, rot });
  }
  const cc = hexOf(CONTACT[LNAME], k);
  out.fx.push({ key: `blob|contact|${cc}`, cw: 128, ch: 128, draw: (p) => fxContact(p, cc), x: x + ox * 0.03 * sc, y: y + 0.022, z: z + oz * 0.03 * sc,
    w: 0.52 * sc, h: 0.4 * sc, flat: true, rot });
};

// ---------------- the cast ----------------
export type Stage = { places: Place[]; fx: FxPlace[] };

const HENO: Outfit = { jacket: "#d2833a", pants: "#3b3f52", boots: "#4a3426", hat: "peci", skin: SKINS[3], moustache: "#2a201a", build: "stout", buttons: "#e8c45a" };
const NBO: Outfit = { jacket: "#2f8a8a", pants: "#2e3440", boots: "#1f1f24", hat: "hair", hair: "#1b1b1f", skin: SKINS[1], build: "adult" };
const KJ = ["#e2453c", "#3f8fd2", "#f2c230", "#4aa564", "#ef8a2c", "#9a5bd0", "#e46fa0", "#36b7b0", "#8c6a3c", "#e9e9ee"];
const KP = ["#3b5b9a", "#5a4a3a", "#2f3b52", "#7a6a52"];
const KC = ["#e2453c", "#2f6f9a", "#f2c230", "#4aa564"];
const KIDO: Outfit[] = Array.from({ length: NKIDS }, (_, i) => ({
  jacket: KJ[i], pants: KP[i % 4], boots: "#f4f1ea", build: "kid" as const, skin: SKINS[1 + (i % 3)],
  hat: i % 3 === 0 ? "cap" : "hair", cap: KC[i % 4], hair: i % 2 ? "#1b1b1f" : "#4a3426",
}));
const KS = 0.85; // kids' scale
const FRONT = { side: false, mirror: false };
const lickPat = (t: number, k = 0, rate = 0.6, duty = 0.38) => (t * rate + k) % 1 < duty;

const hendra = (cam: CamInfo, t: number, out: Stage) => {
  let mode: FrontOpts["mode"] = "stand", y = TY, expr: Expr = "smile_closed", wave: number | undefined, prop: FrontOpts["prop"] = null;
  if (henSits(t)) { mode = "sit"; y = TY + 0.05; expr = "relief"; }
  else if (t >= 1.5 && t < 3.3) { wave = q(Math.sin(t * 11), 30); }
  else if (t >= 4.9 && t < 6.2) expr = "smile";
  else if (t >= 6.2 && t < 8.4) expr = "grin";
  else if (t >= T_CALL - 0.3 && t < 14.1) { wave = q(Math.sin(t * 8), 30); expr = lickPat(t, 0, 2, 0.6) ? "laugh" : "grin"; }
  else if (t >= 14.3 && t < 16.6) { wave = 0.4 + 0.05 * Math.sin(t * 6); expr = "grin"; }
  else if (t >= 16.6 && t < 20.7) expr = "grin";
  else if (t >= 20.7 && t < 22.6) { prop = "icecream"; expr = "laugh"; }
  else if (t >= 22.6) { prop = "icecream"; expr = t >= 37.2 && t < 40 ? "grin" : lickPat(t, 0.2, 0.55, 0.35) ? "lick" : "smile_closed"; }
  const fo: FrontOpts = { mode, expr, wave, prop, blink: lidAt(t, 99), tilt: 0.8 * Math.sin(t * 1.6), look: 0 };
  out.places.push(person(cam, { i: 99, o: HENO, okey: "hen" }, HEN[0], y, HEN[2], FRONT, fo, {}, 1));
  blob(out, HEN[0], TY, HEN[2], 1.05);
};

const neighbour = (cam: CamInfo, t: number, out: Stage) => {
  const run = nbRun(t), WINDOW = (t >= 31.55 && t < T_RUNOUT0) || t >= 47.35;
  if (WINDOW) {
    let expr: Expr = "neutral", shake = 0;
    if (t < 33.0) expr = "neutral";
    else if (t < 33.45) { expr = "shock"; shake = 2.5; }
    else if (t < T_RUNOUT0) { expr = "nervous"; shake = 3; }
    else if (t < 48.33) { expr = "nervous"; shake = 2; }
    else { expr = "shock"; shake = 3.5; }
    const fo: FrontOpts = { mode: "stand", expr, blink: lidAt(t, 98), tilt: shake * Math.sin(t * 38), look: t >= 47.35 && t < 48.33 ? -1 : 0 };
    out.places.push(person(cam, { i: 98, o: NBO, okey: "nb" }, WIN[0], WIN[1], WIN[2], FRONT, fo, {}, 1));
    const sw = (t * 2.2) % 1;
    if (t >= 33.0 && t < T_RUNOUT0 || t >= 47.6)
      out.fx.push({ key: `sweat${q(sw, 20)}`, cw: 300, ch: 300, draw: (p) => fxSweat(p, q(sw, 20)), x: WIN[0] - 0.25, y: 4.78, z: WIN[2] + 0.1, w: 0.9, h: 0.9 });
    if ((t >= 33.0 && t < 33.7) || (t >= 48.33 && t < 49.2))
      out.fx.push({ key: "bang", cw: 200, ch: 260, draw: fxBang, x: WIN[0] - 0.25, y: 5.45, z: WIN[2] + 0.1, w: 0.32, h: 0.42, rot: 0.12 });
  } else if (run.on && t < T_RUNOUT1 + 0.12) {
    const view = viewOf(cam, run.x, run.z, run.dx, run.dz), ph = q((t * 3.1) % 1, 60);
    const fo: FrontOpts = { mode: "march", phase: ph, expr: "shock", lift: 85, blink: 0 };
    const so: SideOpts = { mode: "march", phase: ph, expr: "shock", stomp: 1.5, stride: 1.5 * view.fs };
    out.places.push(person(cam, { i: 98, o: NBO, okey: "nb" }, run.x, 0, run.z, view, fo, so, 1));
    blob(out, run.x, 0, run.z, 1);
    out.fx.push({ key: "speed", cw: 400, ch: 120, draw: fxSpeed, x: run.x - run.dx * 0.9, y: 0.8, z: run.z - run.dz * 0.9, w: 1.4, h: 0.42 });
  }
};

const kids = (cam: CamInfo, t: number, out: Stage) => {
  if (t < T_CALL - 0.1) return;
  const cones = t >= 27.0;
  for (let i = 0; i < NKIDS; i++) {
    const k = kidAt(i, t), o = KIDO[i], who: Who = { i: 300 + i, o, okey: `k${i}` };
    const running = k.mode === "run";
    let expr: Expr;
    if (t >= T_FLEE && t < 39) expr = t < T_FLEE + 1.4 ? "shock" : "nervous";
    else if (running) expr = i % 2 ? "laugh" : "grin";
    else if (k.cheer > 0.3) expr = "laugh";
    else if (cones) expr = lickPat(t, hh(i, 4), 0.7, 0.36) ? "lick" : "smile";
    else expr = i % 3 ? "grin" : "smile";
    const view = running ? viewOf(cam, k.x, k.z, k.dx, k.dz) : { ...FRONT, fs: 1 };
    const prop: FrontOpts["prop"] = cones ? "icecream" : null;
    const wave = !prop && k.cheer > 0.3 ? q(Math.sin(t * 10 + i * 1.3), 30) : undefined;
    const blink = expr === "lick" ? 0 : lidAt(t, i + 5);
    const fo: FrontOpts = { mode: running ? "march" : "stand", phase: q(k.phase, 60), expr, blink, wave, prop, lift: 70, tilt: running ? 0 : 1.6 * Math.sin(t * 2.1 + i), look: 0 };
    const so: SideOpts = { mode: running ? "march" : "stand", phase: q(k.phase, 60), expr, blink, stomp: 1.1, stride: 0.95 * ("fs" in view ? view.fs : 1) };
    const pl = person(cam, who, k.x, k.hop, k.z, view, fo, so, KS);
    if (i === CONE_KID && cones && !running) {
      const dxs = -0.93 - k.x, dzs = 1.05 - k.z; // the car's flank is on the left of the screen: turn the cone toward it
      if (cam.right.x * dxs + cam.right.z * dzs < 0) pl.mirror = true;
    }
    out.places.push(pl);
    blob(out, k.x, 0, k.z, KS, k.hop > 0 ? 0.6 : 1);
  }
};

const props = (id: number, t: number, out: Stage) => {
  // ice-cream cones standing out of the box once he has bought it
  if (id >= 4) out.fx.push({ key: "cones", cw: 360, ch: 260, draw: fxCones, x: -5.2, y: TY + 0.45 + 0.27, z: -2.3, w: 0.78, h: 0.56 });
  // two bags of marbles, until the kids take over the game
  if (t >= 7.0 && t < T_CALL) {
    out.fx.push({ key: "bag|#3f8fd2", cw: 240, ch: 300, draw: (p) => fxBag(p, "#3f8fd2"), x: -4.55, y: TY + 0.22, z: -1.95, w: 0.34, h: 0.42 });
    out.fx.push({ key: "bag|#e2453c", cw: 240, ch: 300, draw: (p) => fxBag(p, "#e2453c"), x: -4.3, y: TY + 0.2, z: -1.55, w: 0.34, h: 0.42, rot: 0.12 });
  }
  // the chalk circle + marbles (moves to where the car was once the car is gone)
  const gone = t >= 38.8, cx = gone ? CAR0[0] + 0.55 : MC[0], cz = gone ? CAR0[2] - 0.7 : MC[1];
  if (t >= T_ARRIVE - 0.6 && !(t >= T_FLEE && t < 38.8)) {
    out.fx.push({ key: "chalk", cw: 600, ch: 600, draw: fxChalk, x: cx, y: 0.025, z: cz, w: 1.25, h: 1.25, flat: true });
    MARBLES.forEach((m, i) => out.fx.push({ key: `marble|${m.c}`, cw: 100, ch: 100, draw: (p) => fxMarble(p, m.c), x: cx + m.dx * 0.9, y: 0.06, z: cz + m.dz * 0.9, w: 0.12, h: 0.12, rot: i }));
  }
  // the winning marble rolls to the tyre and stops 7 cm from it
  const mb = marbleAt(t);
  if (mb.on && t < CAR_T0 + 0.2) out.fx.push({ key: "marble|#ff7ab8", cw: 100, ch: 100, draw: (p) => fxMarble(p, "#ff7ab8"), x: mb.x, y: 0.075, z: mb.z, w: 0.15, h: 0.15, rot: t * 6 });
  // melting drips beside the paint (shots 19-20)
  if (t >= 27.5 && t < T_FLEE) {
    const u = ((t - 27.5) * 0.7) % 1, v = q(u, 20);
    out.fx.push({ key: `drop${v}`, cw: 120, ch: 200, draw: (p) => fxDrop(p, v), x: -0.8, y: 0.78 - 0.4 * u, z: 1.03, w: 0.08, h: 0.13 });
    const w2 = clamp01((t - 28.8) / 1.5);
    out.fx.push({ key: `drop${q(w2, 20)}b`, cw: 120, ch: 200, draw: (p) => fxDrop(p, q(w2, 20)), x: -0.915, y: 0.72 - 0.15 * w2, z: 1.0, w: 0.07 + 0.05 * w2, h: 0.1 + 0.1 * w2 });
  }
  // the car peels out: dust from the wheels and speed streaks
  if (t >= CAR_T0 && t < CAR_T1 + 0.3) {
    const c = carAt(t), hx = Math.sin(c.yaw), hz = Math.cos(c.yaw), u = clamp01((t - CAR_T0) / 0.5), v = q(u, 20);
    if (u < 1) out.fx.push({ key: `puff${v}`, cw: 300, ch: 300, draw: (p) => fxPuff(p, v), x: c.x - hx * 2.3, y: 0.25, z: c.z - hz * 2.3, w: 1.6, h: 1.6, soft: true });
    out.fx.push({ key: "speed", cw: 400, ch: 120, draw: fxSpeed, x: c.x - hx * 2.9, y: 0.75, z: c.z - hz * 2.9, w: 2.2, h: 0.66 });
  }
};

/** everything with a face in shot `id` at time t */
export const stage = (id: number, t: number, cam: CamInfo): Stage => {
  const out: Stage = { places: [], fx: [] };
  LNAME = SHOTS[id - 1].light;
  findSun(cam, SUN);
  hendra(cam, t, out); neighbour(cam, t, out); kids(cam, t, out); props(id, t, out);
  return out;
};
export { FPS, smooth };
