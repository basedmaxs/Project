// Timeline of "Pak Hendra and the ice cream": 28 shots timed to the voice (work/phrases.json), the gang's layout,
// story physics (kids, marbles, the neighbour, the car) and the camera grammar of the reference study:
// slow creeping push-ins, symmetric smootherstep glides of 18-40 f, hard cuts on big reframes, kicks on impacts.
export const FPS = 30;
export const TOTAL = 1478;
export const D0 = 0; // ground level
export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 3;
const hh = (i: number, s = 0) => { const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return v - Math.floor(v); };

// ---------------- layout (metres; the gang runs along z, x = across; road centre x = 0) ----------------
export const TY = 0.35; // Pak Hendra's terrace floor
export const HEN: V3 = [-4.7, TY, -1.3]; // where Pak Hendra stands / sits
export const CAR0: V3 = [-1.85, 0, 3.3]; // the luxury car, parked facing -z in front of the terrace's end
export const MC: [number, number] = [-0.1, 1.8]; // centre of the marble circle, beside the car's front wheel
export const TIRE: V3 = [-0.8, 0.07, 1.95]; // where the winning marble stops (7 cm from the tyre)
export const WIN: V3 = [7.2, 3.3, -0.2]; // the neighbour's card at his upstairs window
export const DOOR: V3 = [5.95, 0, 3.6]; // his front door
export const GAR_Z = -0.2; // garage axis (z)
export const BOX: V3 = [-5.2, TY, -2.3]; // the cardboard box of ice cream
export const SPOT: V3[] = [[-4.5, TY, 0.2], [-4.2, TY, -2.4]]; // spare

// ---------------- shots ----------------
export type Light = "day" | "golden";
export type ShotDef = { id: number; a: number; b: number; light: Light };
const S = (id: number, a: number, b: number, light: Light = "golden"): ShotDef => ({ id, a, b, light });
export const SHOTS: ShotDef[] = [
  S(1, 0, 46, "day"), S(2, 46, 98, "day"), S(3, 98, 148, "day"),
  S(4, 148, 180), S(5, 180, 216), S(6, 216, 252), S(7, 252, 304), S(8, 304, 352), S(9, 352, 398), S(10, 398, 429),
  S(11, 429, 496), S(12, 496, 550), S(13, 550, 590), S(14, 590, 623), S(15, 623, 675), S(16, 675, 705), S(17, 705, 774),
  S(18, 774, 810), S(19, 810, 870), S(20, 870, 947), S(21, 947, 990), S(22, 990, 1059), S(23, 1059, 1104), S(24, 1104, 1171),
  S(25, 1171, 1268, "day"), S(26, 1268, 1369, "day"), S(27, 1369, 1424, "day"), S(28, 1424, TOTAL, "day"),
];
/** crossfades (frames) at time changes */
export const XFADE: Record<number, number> = { 4: 8, 25: 8 };
export const FLASH_AT = 99999; // no flash

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [{ id: s.id - 1, alpha: 1 }, { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) }];
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};
const T = (f: number) => f / FPS;

// ---------------- story physics ----------------
/** the kids (10): where each stands around the chalk circle, when they arrive, how they move */
export const NKIDS = 10;
export const CONE_KID = 4; // the kid whose cone melts a few cm from the paint
export const T_CALL = 10.1, T_ARRIVE = 13.4, T_CHEER0 = 20.75, T_CHEER1 = 22.6, T_BUSY0 = 23.5, T_RUN0 = 25.8, T_RUN1 = 27.0, T_FLEE = 35.3;
export const kidSpot = (i: number): [number, number] => {
  const inner = i % 2 === 0, k = i >> 1, R = inner ? 1.05 : 1.85, th = (inner ? -80 + k * 40 : -66 + k * 33) * Math.PI / 180;
  return [MC[0] + R * Math.cos(th) + (hh(i) - 0.5) * 0.15, MC[1] + R * Math.sin(th) * 1.0 + (hh(i, 2) - 0.5) * 0.15];
};
/** the huddle at the terrace when the neighbour hurries out */
export const kidHuddle = (i: number): [number, number] => [-4.0 - 0.35 * (i % 3) - 0.5 * hh(i, 5), -3.0 + 0.62 * i * 0.55 + (hh(i, 3) - 0.5) * 0.3];
export type KidState = { x: number; z: number; dx: number; dz: number; mode: "run" | "stand"; hop: number; cheer: number; speed: number; phase: number };
export const kidAt = (i: number, t: number): KidState => {
  const [sx, sz] = kidSpot(i);
  const ta = T_ARRIVE - 0.5 + 0.1 * i; // arrival
  const v = 5.6;
  let x = sx, z = sz, dx = 0, dz = 0, mode: "run" | "stand" = "stand", hop = 0, cheer = 0, speed = 0;
  // approach: run along the gang from the far end toward the circle
  if (t < ta) {
    const d = v * (ta - t), a = 0.25 * Math.sin(i);
    z = sz - d; x = sx + (hh(i, 4) - 0.5) * 0.8 * Math.min(1, d / 6) + a * (d / 12);
    dz = 1; dx = 0; mode = "run"; speed = v;
  } else {
    // loose standing sway around the spot, bigger when "busy"
    const busy = smooth((t - T_BUSY0) / 0.6) * (1 - smooth((t - T_RUN0) / 0.4)) + (smooth((t - T_RUN1) / 0.6) < 1 ? 0 : 0);
    const k = 0.1 + 0.28 * busy;
    x = sx + k * Math.sin(t * 2.3 + i * 1.7); z = sz + k * Math.cos(t * 1.9 + i * 2.1);
    // cheer: "dapat es krim gratis"
    const c = smooth((t - T_CHEER0 + 0.1) / 0.2) * (1 - smooth((t - T_CHEER1) / 0.3));
    cheer = Math.max(c, 0.9 * busy);
    hop = (c > 0.05 ? Math.max(0, Math.sin(t * 9 + i * 1.3)) * 0.2 * c : 0) + (busy > 0.05 ? Math.max(0, Math.sin(t * 8 + i * 2.1)) * 0.14 * busy : 0);
    // "lari-larian": loops along the gang
    if (t >= T_RUN0 - 0.3 && t < T_RUN1 + 0.4) {
      const u = smooth((t - (T_RUN0 - 0.3)) / 0.4) * (1 - smooth((t - T_RUN1) / 0.4));
      const A = 3.0, w = 1.7, ph = i * 0.9;
      const zr = MC[1] + A * Math.sin(w * t + ph), vz = A * w * Math.cos(w * t + ph);
      const xr = (hh(i, 7) - 0.5) * 2.6 + 0.2;
      x = x + (xr - x) * u; z = z + (zr - z) * u;
      if (u > 0.5) { dz = Math.sign(vz) || 1; mode = "run"; speed = Math.abs(vz); hop = 0; }
    }
    if (i === CONE_KID && t >= 27.0) { x = -0.73 + 0.012 * Math.sin(t * 3); z = 1.05 + 0.01 * Math.cos(t * 2.6); hop = 0; }
    // the car is about to move: everybody to the terrace
    if (t >= T_FLEE) {
      const [hx, hz] = kidHuddle(i), u = smooth((t - T_FLEE - 0.06 * i) / 1.3);
      const x0 = x, z0 = z;
      x = x0 + (hx - x0) * u; z = z0 + (hz - z0) * u;
      if (u > 0.02 && u < 0.98) { dx = hx - x0; dz = hz - z0; const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L; mode = "run"; speed = 2.6; }
    }
    // day: back to play on the empty spot (t > 39)
    if (t >= 39.0) {
      const u = smooth((t - 39.0 - 0.05 * i) / 0.8);
      const px = CAR0[0] + 0.6 + (kidSpot(i)[0] - MC[0]) * 0.9, pz = CAR0[2] - 0.8 + (kidSpot(i)[1] - MC[1]) * 0.9;
      const [hx, hz] = kidHuddle(i);
      x = hx + (px - hx) * u; z = hz + (pz - hz) * u;
      if (u > 0.02 && u < 0.98) { dx = px - hx; dz = pz - hz; const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L; mode = "run"; speed = 2.4; }
    }
  }
  const cad = 1.15 + 0.12 * speed / 5.6; // steps cycle rate (Hz)
  return { x, z, dx, dz, mode, hop, cheer, speed, phase: (t * cad + hh(i, 6)) % 1 };
};

/** the winning marble: thrown by kid 0 from the circle's edge, rolls to the tyre */
export const T_THROW0 = 18.0, T_THROW1 = 19.6;
export const marbleAt = (t: number): { x: number; y: number; z: number; on: boolean } => {
  const u = clamp01((t - T_THROW0) / (T_THROW1 - T_THROW0)), e = 1 - (1 - u) ** 2.4;
  const x0 = MC[0] + 0.55, z0 = MC[1] - 0.35;
  return { x: x0 + (TIRE[0] - x0) * e, y: 0.07 + 0.22 * Math.sin(Math.PI * Math.min(1, u * 1.6)) * (1 - u) * 0.0, z: z0 + (TIRE[2] - z0) * e, on: t >= T_THROW0 - 0.02 };
};
/** static marbles lying around the chalk circle once the game is on */
export const MARBLES: { dx: number; dz: number; c: string }[] = [
  { dx: 0.0, dz: 0.0, c: "#e2453c" }, { dx: 0.2, dz: -0.1, c: "#3f8fd2" }, { dx: -0.15, dz: 0.2, c: "#f2c230" }, { dx: 0.1, dz: 0.22, c: "#4aa564" },
  { dx: -0.28, dz: -0.12, c: "#9a5bd0" }, { dx: 0.3, dz: 0.15, c: "#36b7b0" }, { dx: -0.05, dz: -0.28, c: "#ffffff" },
];

/** Pak Hendra: 0 stands, 1 sits on the stool (f252-285), then up again */
export const henSits = (t: number) => t >= 252 / FPS && t < 288 / FPS;
/** neighbour: window until f1056, runs out of the door to the car (f1059-1104), gets in; back at the window at f1424 */
export const T_RUNOUT0 = 1057 / FPS, T_RUNOUT1 = 1104 / FPS;
export const nbRun = (t: number): { x: number; z: number; dx: number; dz: number; on: boolean } => {
  const u = clamp01((t - T_RUNOUT0) / (T_RUNOUT1 - T_RUNOUT0));
  const P: [number, number][] = [[DOOR[0], DOOR[2]], [3.0, 3.5], [-0.5, 3.05]];
  const seg = u < 0.5 ? 0 : 1, w = seg === 0 ? u / 0.5 : (u - 0.5) / 0.5;
  const a = P[seg], b = P[seg + 1];
  const dx = b[0] - a[0], dz = b[1] - a[1], L = Math.hypot(dx, dz);
  return { x: a[0] + dx * w, z: a[1] + dz * w, dx: dx / L, dz: dz / L, on: t >= T_RUNOUT0 && t < T_RUNOUT1 + 0.12 };
};
export const T_DOOR = 1052 / FPS; // the door flies open

/** the car pulls out and swings right into the garage: arc of radius R about C, then straight in */
export const CAR_T0 = 1113 / FPS, CAR_T1 = 1163 / FPS;
const R_ARC = 3.5, L_ARC = (Math.PI / 2) * R_ARC, L_STR = 7.8;
export const carAt = (t: number): { x: number; z: number; yaw: number; s: number } => {
  const u = clamp01((t - CAR_T0) / (CAR_T1 - CAR_T0)), s = (u * u * (3 - 2 * u)) * (L_ARC + L_STR) * 0.55 + u * u * (L_ARC + L_STR) * 0.45;
  if (s <= 0) return { x: CAR0[0], z: CAR0[2], yaw: Math.PI, s: 0 };
  if (s < L_ARC) {
    const ph = s / R_ARC, cx = CAR0[0] + R_ARC;
    // heading (sin ph * ... ) -z at 0 -> +x at pi/2; yaw = atan2(hx, hz)
    const hx = Math.sin(ph), hz = -Math.cos(ph);
    return { x: cx - R_ARC * Math.cos(ph), z: CAR0[2] - R_ARC * Math.sin(ph), yaw: Math.atan2(hx, hz), s };
  }
  return { x: CAR0[0] + R_ARC + (s - L_ARC), z: CAR0[2] - R_ARC, yaw: Math.PI / 2, s };
};
export const carGone = (t: number) => t >= CAR_T0;

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const mixC = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3, look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k, roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mixC(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};
const pushK = (f: number, f0: number, rate: number, punch = 0, n = 35) => {
  const x = Math.max(0, f - f0);
  let s = rate * x;
  if (punch > rate) for (let i = 0; i < Math.min(x, n); i++) s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
  return Math.exp(-s);
};
const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [look[0] + (pos[0] - look[0]) * k, look[1] + (pos[1] - look[1]) * k, look[2] + (pos[2] - look[2]) * k], look, ...rest });
const zoom = (pos: V3, look: V3, fov: number, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos, look, fov: (360 / Math.PI) * Math.atan(Math.tan((fov * Math.PI) / 360) * k), ...rest });
const rolled = (s: (f: number) => Shot, roll: number) => (f: number): Shot => ({ ...s(f), roll });
const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];

// reference points
const PHx = HEN[0], PHz = HEN[2];
const PHEAD: V3 = [PHx, 1.8, PHz]; // Pak Hendra's face when he stands
const CARC: V3 = [CAR0[0], 0.8, CAR0[2]];

// shot 1 (hook): wide-ish, Pak Hendra left, the luxury car right, calm. Pushes in on his face.
const S1a = (f: number) => dolly([-1.4, 1.55, -5.0], [-4.7, 1.45, -1.3], pushK(f, 0, 0.004), { fov: 38 });
// shot 2: MS Pak Hendra waving "no" (day)
const S2a = (f: number) => dolly([-1.2, 1.7, -4.6], [PHx, 1.62, PHz], pushK(f, 46, 0.0035), { fov: 40 });
const S2b = (f: number) => dolly([-1.7, 1.55, -3.9], [PHx, 1.7, PHz], pushK(f, 70, 0.003, 0.006, 25), { fov: 36, roll: -0.035 });
// shot 3: the scratch (close-up, glides along it), then pulls out to the whole car
const S3a = (f: number) => dolly([-4.4, 1.0, 5.0], [-2.78, 0.75, 3.1], pushK(f, 98, 0.003), { fov: 36 });
const S3b = (f: number) => dolly([-3.9, 1.2, -0.6], [-2.2, 0.8, 3.4], pushK(f, 118, 0.0022), { fov: 40, roll: 0.03 });
// shot 4: golden wide of the gang, car in the foreground
const S4a = (f: number) => zoom([2.4, 2.4, -9.5], [-1.2, 1.2, 5], 44, pushK(f, 148, 0.003));
// shot 5: Pak Hendra with the box
const S5a = (f: number) => dolly([-0.7, 1.3, -3.6], [-4.9, 1.3, -1.8], pushK(f, 180, 0.003), { fov: 46 });
// shot 6: insert: the box with cones, then the marble bags
const S6a = (f: number) => dolly([-3.1, 1.0, -2.7], [BOX[0], TY + 0.55, BOX[2]], pushK(f, 216, 0.003), { fov: 38 });
const S6b = (f: number) => dolly([-3.3, 0.95, -1.5], [-4.5, TY + 0.2, -1.9], pushK(f, 236, 0.003), { fov: 36, roll: -0.03 });
// shot 7: sits on the terrace
const S7a = (f: number) => dolly([-1.5, 1.2, -4.0], [PHx, TY + 0.95, PHz], pushK(f, 252, 0.003), { fov: 40 });
// shot 8: stands, waves them over
const S8a = (f: number) => dolly([-1.4, 1.6, -4.4], [PHx, 1.62, PHz], pushK(f, 304, 0.0035, 0.005, 30), { fov: 40 });
// shot 9: wide: the kids run in down the gang toward us
const S9a = (f: number) => dolly([1.8, 2.8, 10.5], [-0.3, 0.9, -6], pushK(f, 352, 0.0022), { fov: 42 });
// shot 10: low by the car, the kids arrive next to it
const S10a = (f: number) => dolly([0.2, 0.7, 5.8], [-1.0, 0.8, 2.2], pushK(f, 398, 0.003, 0.006, 25), { fov: 40, roll: 0.03 });
// shot 11: Pak Hendra, one finger
const S11a = (f: number) => dolly([-1.5, 1.7, -4.4], [PHx, 1.7, PHz], pushK(f, 429, 0.0028), { fov: 38 });
// shot 12: kids at the chalk circle beside the car (wide, low)
const S12a = (f: number) => dolly([1.9, 1.1, 5.2], [-0.4, 0.7, 1.7], pushK(f, 496, 0.0022), { fov: 44 });
// shot 13: low insert: the marble rolls to the tyre
const S13a = (f: number) => dolly([0.55, 0.25, 0.4], [-0.5, 0.2, 1.9], pushK(f, 550, 0.002), { fov: 38 });
// shot 14: close-up on the tyre and the marble
const S14a = (f: number) => dolly([-0.2, 0.2, 2.75], [-0.85, 0.2, 1.95], pushK(f, 590, 0.0028, 0.006, 25), { fov: 34, roll: -0.03 });
// shot 15: free ice cream! kids cheer, Pak Hendra holds a cone out
const S15a = (f: number) => dolly([-1.4, 1.75, -4.8], [PHx, 1.6, PHz], pushK(f, 623, 0.003), { fov: 40 });
const S15b = (f: number) => dolly([1.9, 1.0, -1.6], [-0.4, 0.8, 1.8], pushK(f, 650, 0.0025), { fov: 44, roll: 0.03 });
// shot 16: golden high wide: the whole gang
const S16a = (f: number) => dolly([3.1, 4.8, 9.5], [-1.5, 0.8, 0.8], pushK(f, 675, 0.0022), { fov: 44, roll: -0.03 });
// shot 17: ten kids play
const S17a = (f: number) => dolly([1.6, 1.0, 5.5], [-0.3, 0.8, 1.2], pushK(f, 705, 0.0022), { fov: 46 });
// shot 18: kids run, side tracking
const S18a = (f: number) => dolly([3.4, 0.9, 6.5], [0.2, 0.7, 1.8], pushK(f, 774, 0.0025), { fov: 46, roll: 0.03 });
// shot 19: kids with cones near the car
const S19a = (f: number) => dolly([0.9, 0.95, 4.8], [-0.6, 0.85, 1.8], pushK(f, 810, 0.0022), { fov: 40 });
// shot 20: close-up: cone a few cm from the paint, drip falls
const S20a = (f: number) => dolly([0.7, 0.8, 3.4], [-0.85, 0.66, 1.0], pushK(f, 870, 0.0025, 0.005, 40), { fov: 36, roll: 0.03 });
// shots 21-22: the neighbour at the window
const S21a = (f: number) => dolly([1.6, 4.0, -1.0], [WIN[0] - 0.8, 4.5, WIN[2]], pushK(f, 947, 0.0022), { fov: 40 });
const S22a = (f: number) => dolly([2.6, 3.7, WIN[2] - 0.2], [WIN[0] - 0.5, 4.45, WIN[2]], pushK(f, 990, 0.003, 0.006, 30), { fov: 30, roll: -0.04 });
// shot 23: he runs out
const S23a = (f: number) => dolly([2.0, 1.0, 7.5], [3.2, 0.9, 3.4], pushK(f, 1059, 0.002), { fov: 46 });
// shot 24: the car swings into the garage
const S24a = (f: number) => dolly([-3.2, 2.3, -4.8], [1.5, 0.9, 1.5], pushK(f, 1104, 0.002), { fov: 48, roll: 0.03 });
// shot 25: day: the empty spot, kids playing there
const S25a = (f: number) => dolly([1.6, 1.1, 6.6], [-1.2, 0.7, 2.2], pushK(f, 1171, 0.002), { fov: 46 });
// shot 26: Pak Hendra with his cone
const S26a = (f: number) => dolly([-1.5, 1.6, -4.4], [PHx, 1.6, PHz], pushK(f, 1268, 0.0028, 0.005, 30), { fov: 38 });
// shot 27: kid licking a cone, close
const S27a = (f: number) => dolly([1.8, 0.9, 6.0], [-1.0, 0.8, 2.3], pushK(f, 1369, 0.0026), { fov: 44, roll: -0.03 });
// shot 28: push in on the neighbour's window; the last word lands on the sweat
const S28a = (f: number) => dolly([2.4, 4.3, -0.9], [WIN[0] - 0.4, 4.6, WIN[2]], pushK(f, 1424, 0.003, 0.008, 40), { fov: 38 });

const CAMS: Record<number, Key[]> = {
  1: [{ f: 0, s: S1a }],
  2: [{ f: 46, s: S2a }, { f: 70, dur: 24, s: S2b }],
  3: [{ f: 98, s: S3a }, { f: 118, dur: 26, s: S3b }],
  4: [{ f: 148, s: S4a }],
  5: [{ f: 180, s: S5a }],
  6: [{ f: 216, s: S6a }, { f: 236, cut: true, s: S6b }],
  7: [{ f: 252, s: S7a }],
  8: [{ f: 304, s: S8a }],
  9: [{ f: 352, s: S9a }],
  10: [{ f: 398, s: S10a }],
  11: [{ f: 429, s: S11a }],
  12: [{ f: 496, s: S12a }],
  13: [{ f: 550, s: S13a }],
  14: [{ f: 590, s: S14a }],
  15: [{ f: 623, s: S15a }, { f: 650, cut: true, s: S15b }],
  16: [{ f: 675, s: S16a }],
  17: [{ f: 705, s: S17a }],
  18: [{ f: 774, s: S18a }],
  19: [{ f: 810, s: S19a }],
  20: [{ f: 870, s: S20a }],
  21: [{ f: 947, s: S21a }],
  22: [{ f: 990, s: S22a }],
  23: [{ f: 1059, s: S23a }],
  24: [{ f: 1104, s: S24a }],
  25: [{ f: 1171, s: S25a }],
  26: [{ f: 1268, s: S26a }],
  27: [{ f: 1369, s: S27a }],
  28: [{ f: 1424, s: S28a }],
};

// impact kicks: image offset flips sign every frame and decays over 7 f
const KICKS: [number, number][] = [[1112 / FPS, 0.8], [1163 / FPS, 0.6], [1452 / FPS, 1.0], [19.55, 0.5]];
export const kickAt = (t: number) => {
  let a = 0;
  for (const [t0, g] of KICKS) {
    const n = Math.floor((t - t0) * FPS + 1e-6);
    if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
  }
  return a;
};
export const camAt = (id: number, f: number): Cam => {
  const c = run(CAMS[id], f), a = kickAt(T(f));
  if (!a) return c;
  const d: V3 = [c.look[0] - c.pos[0], c.look[1] - c.pos[1], c.look[2] - c.pos[2]];
  const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
  const m = (3 / 640) * Math.tan((c.fov * Math.PI) / 360) * L * a;
  return { ...c, look: [c.look[0] - (d[2] / h) * m, c.look[1] + 0.6 * m, c.look[2] + (d[0] / h) * m], roll: c.roll + a * 0.004 };
};
export const keyEnd = (id: number, f: number) => {
  let e = 0;
  for (const k of CAMS[id]) if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
  return Math.max(f, e);
};

// ---------------- lens ----------------
export type Dof = { f: number; dur?: number; cInf: number; focus?: (f: number) => V3 };
export const DOF: Dof[] = [
  { f: 0, cInf: 8 },
  { f: 46, cInf: 12 }, // MS Pak Hendra
  { f: 98, cInf: 13 }, // scratch close-up
  { f: 118, dur: 26, cInf: 0 }, // pull out
  { f: 148, cInf: 0 },
  { f: 180, cInf: 8 },
  { f: 216, cInf: 14 }, // box insert
  { f: 252, cInf: 10 },
  { f: 304, cInf: 10 },
  { f: 352, cInf: 0 }, // wide: kids run in
  { f: 398, cInf: 10 },
  { f: 429, cInf: 10 },
  { f: 496, cInf: 0 },
  { f: 550, cInf: 12 }, // marble
  { f: 590, cInf: 14 },
  { f: 623, cInf: 9 },
  { f: 675, cInf: 0 },
  { f: 705, cInf: 8 },
  { f: 774, cInf: 0 },
  { f: 810, cInf: 10 },
  { f: 870, cInf: 14 }, // cone at the paint
  { f: 947, cInf: 6 },
  { f: 990, cInf: 13 }, // neighbour close-up
  { f: 1059, cInf: 0 },
  { f: 1104, cInf: 0 },
  { f: 1171, cInf: 0 },
  { f: 1268, cInf: 10 },
  { f: 1369, cInf: 14 },
  { f: 1424, cInf: 8 },
];
export const dofAt = (f: number) => {
  let i = 0; while (i + 1 < DOF.length && f >= DOF[i + 1].f) i++;
  const d = DOF[i], p = DOF[Math.max(0, i - 1)];
  const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
  return { cInf: p.cInf + (d.cInf - p.cInf) * k, focus: d.focus };
};
export const focusAt = (id: number, f: number): V3 => {
  const d = dofAt(f);
  return d.focus ? d.focus(f) : camAt(id, f).look;
};

export type Fg = { a: number; b: number; kit: string; pos: V3; s?: number; yaw?: number };
export const FOREGROUND: Fg[] = [];
export { hh as hash, add as addV, PHEAD, CARC };
