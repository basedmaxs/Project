# Pak Hendra dan Es Krim — render di GitHub Actions

Video 1080x1920, 30 fps, 1478 frame (49,27 detik), subtitle karaoke tertanam.

## Langkah
1. Buat repository baru di github.com (public: runner gratis; private: memakai menit gratis bulanan).
2. Ekstrak zip ini, lalu di foldernya:
   ```
   git init && git add -A && git commit -m "pak hendra"
   git branch -M main
   git remote add origin https://github.com/<user>/<repo>.git
   git push -u origin main
   ```
   (atau tarik semua file ke repo lewat "Add file → Upload files"; pastikan folder `.github` ikut terunggah).
3. Buka tab **Actions → render → Run workflow**.
   - `title`: Pak-Hendra-dan-Es-Krim
   - `chunk`: 74 (20 job, sesuai batas 20 job bersamaan akun Free)
   - `total`: kosongkan (seluruh video). Isi `60` dulu kalau mau uji coba cepat.
4. Setelah selesai, unduh artifact **final-video** (MP4, .srt, qa_sheet.jpg).

## Catatan
- Subtitle dibakar per potongan oleh `ci/encode_chunk.sh` dari `subs.ass`. Ubah teks/gaya: jalankan `python3 kaggle/make_subs.py work/words.json subs.ass subs.srt`.
- Suara: jika `mix_final.wav` ada di root repo, ikut digabung; jika tidak ada, hasilnya video tanpa suara.
- Syarat layanan GitHub Actions membatasi penggunaan untuk pengembangan/pengujian proyek perangkat lunak di repositori. Merender video lewat repo masuk area abu-abu: pakai sesekali saja dan Anda yang memutuskan.
- Workflow ini sudah lolos cek sintaks YAML tetapi belum pernah dijalankan di GitHub.
