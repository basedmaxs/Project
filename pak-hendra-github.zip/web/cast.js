import * as THREE from "three";
import { Pen, bodyFront, bodySide, fxBurst, fxStars, fxShadow, fxContact, fxMarble, fxChalk, fxPuff, fxDrop, fxSweat, fxBang, fxCones, fxBag, fxSpeed, SKINS } from "./toon.js";
import { FPS, TY, HEN, CAR0, MC, TIRE, WIN, NKIDS, T_CALL, T_ARRIVE, T_FLEE, T_RUNOUT0, T_RUNOUT1, T_THROW0, MARBLES, CONE_KID, CAR_T0, CAR_T1, SHOTS, kidAt, kidSpot, marbleAt, nbRun, henSits, carAt, clamp01, smooth, hash as hh } from "./story.js";
import { NOINK } from "./ink.js";
import { cardShade, blobMaterial, CARD_K } from "./cardshade.js";
const makeEntry = (w, h)=>{
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return {
        cv,
        tex,
        w,
        h
    };
};
export class Pool {
    live = new Map();
    free = [];
    reqs = [];
    req(key, w, h, k, draw) {
        const r = {
            key: `${w}x${h}|${key}`,
            w,
            h,
            k,
            draw
        };
        this.reqs.push(r);
        return r;
    }
    flush() {
        const want = new Map();
        for (const r of this.reqs){
            const l = want.get(r.key);
            if (l) l.push(r);
            else want.set(r.key, [
                r
            ]);
        }
        for (const [key, e] of this.live)if (!want.has(key)) {
            this.live.delete(key);
            this.free.push(e);
        }
        for (const [key, rs] of want){
            let e = this.live.get(key);
            if (!e) {
                const r = rs[0], i = this.free.findIndex((x)=>x.w === r.w && x.h === r.h);
                e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
                const g = e.cv.getContext("2d");
                g.setTransform(1, 0, 0, 1, 0, 0);
                g.clearRect(0, 0, e.w, e.h);
                g.setTransform(r.k, 0, 0, r.k, 0, 0);
                r.draw(new Pen(g));
                e.tex.needsUpdate = true;
                this.live.set(key, e);
            }
            for (const r of rs)r.tex = e.tex;
        }
        this.reqs = [];
    }
}
const blank = (()=>{
    const c = document.createElement("canvas");
    c.width = c.height = 2;
    return new THREE.CanvasTexture(c);
})();
export const SU = 0.00216;
export const SU_SWING = 2.3 / 1830;
const BODY = (()=>{
    const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU);
    g.translate(0, (975 - 500) * SU, 0);
    return g;
})();
const CARD = new THREE.PlaneGeometry(1, 1);
const ROOTS = new Set();
export class Actor {
    mesh;
    mat;
    dmat;
    r = null;
    constructor(parent, geo = BODY){
        this.mat = cardShade(new THREE.MeshLambertMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        }));
        this.mat.alphaToCoverage = false;
        this.dmat = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mesh = new THREE.Mesh(geo, this.mat);
        this.mesh.customDepthMaterial = this.dmat;
        this.mesh.onBeforeRender = (r)=>{
            const rt = r.getRenderTarget();
            CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920;
        };
        this.mesh.castShadow = false;
        this.mesh.receiveShadow = true;
        this.mesh.visible = false;
        this.mesh.rotation.order = "YXZ";
        this.mesh.renderOrder = 1;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
        ROOTS.add(parent);
    }
    bind() {
        const t = this.r?.tex;
        if (t) {
            this.mat.map = t;
            this.dmat.map = t;
        }
    }
}
export class Fx {
    mesh;
    mat;
    soft;
    blob;
    r = null;
    constructor(parent){
        this.mat = new THREE.MeshBasicMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mat.alphaToCoverage = false;
        this.soft = new THREE.MeshBasicMaterial({
            map: blank,
            transparent: true,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.blob = blobMaterial(blank);
        this.mesh = new THREE.Mesh(CARD, this.mat);
        this.mesh.visible = false;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
    }
    use(soft) {
        this.mesh.material = soft ? this.soft : this.mat;
    }
    bind() {
        const t = this.r?.tex;
        if (!t) return;
        if (this.r.key.includes("|blob|")) {
            if (t.generateMipmaps) {
                t.generateMipmaps = false;
                t.minFilter = THREE.LinearFilter;
                t.needsUpdate = true;
            }
            this.blob.map = t;
            this.mesh.material = this.blob;
            this.mesh.renderOrder = 0.5;
        } else {
            this.mat.map = t;
            this.soft.map = t;
            this.mesh.renderOrder = 0;
        }
    }
}
const q = (v, n = 120)=>Math.round(v * n) / n;
const seedOf = (i)=>(i * 5 + 3) % 7 + 1;
const tier = (d)=>d < 3.2 ? [
        1800,
        3000,
        3.0
    ] : d < 6.5 ? [
        1080,
        1800,
        1.8
    ] : d < 16 ? [
        480,
        800,
        0.8
    ] : [
        240,
        400,
        0.4
    ];
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME = "day";
const sunOf = (root)=>{
    let s = null;
    root.traverse((o)=>{
        if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o;
    });
    return s;
};
const findSun = (cam, out)=>{
    if (cam.sun) return out.copy(cam.sun).normalize();
    let best = null, err = Infinity;
    for (const r of ROOTS){
        if (!r.parent) continue;
        const s = sunOf(r);
        if (!s) continue;
        const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
        if (e < err) {
            err = e;
            best = s;
        }
    }
    return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
const light2D = (cam, mirror)=>{
    const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
    return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};
const viewOf = (cam, x, z, dx, dz)=>{
    const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
    const c = (tx * dx + tz * dz) / tl;
    return {
        side: c < 0.57,
        mirror: dx * cam.right.x + dz * cam.right.z < 0,
        fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20
    };
};
const LEAD = 2 / FPS;
const LID = [
    0.5,
    1,
    1,
    0.5
];
const SWAPS = {};
const lidAt = (t, i, swaps = [])=>{
    const f = Math.round(t * FPS);
    for (const ts of swaps){
        const k = f - Math.round((ts - LEAD) * FPS) + 1;
        if (k >= 0 && k < 4) return LID[k];
    }
    let s = Math.round(-60 * hh(i, 9));
    for(let n = 0; s <= f && n < 400; n++){
        const k = f - s;
        if (k >= 0 && k < 4) return LID[k];
        s += Math.round(15 + 54 * hh(i * 31 + n, 13));
    }
    return 0;
};
const fkey = (o)=>JSON.stringify(o, (_k, v)=>typeof v === "number" ? q(v) : v);
const person = (cam, who, x, y, z, view, fo, so, scale = 1)=>{
    const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
    const [w, h, k] = tier(d);
    const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
    const f2 = {
        ...fo,
        light,
        seed
    }, s2 = {
        ...so,
        light,
        seed
    };
    const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
    return {
        key,
        x,
        y,
        z,
        scale,
        mirror,
        tierKey: `${w}`,
        draw: (p)=>view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2),
        size: [
            w,
            h,
            k
        ]
    };
};
const CONTACT = {
    day: [
        0.2,
        0.21,
        0.33
    ],
    golden: [
        0.24,
        0.2,
        0.33
    ]
};
const TAIL = [
    0.42,
    0.44,
    0.62
];
const toSrgb = (v)=>{
    const c = clamp01(v);
    return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055;
};
const hexOf = (c, k)=>"#" + c.map((v)=>Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out, x, y, z, sc = 1, k = 1)=>{
    const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
    if (LNAME === "day") {
        const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
        const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h;
        const tc = hexOf(TAIL, k);
        out.fx.push({
            key: `blob|shadow|${tc}`,
            cw: 128,
            ch: 256,
            draw: (p)=>fxShadow(p, tc),
            x: x + ox * c,
            y: y + 0.018,
            z: z + oz * c,
            w: 0.72 * sc,
            h,
            flat: true,
            rot
        });
    }
    const cc = hexOf(CONTACT[LNAME], k);
    out.fx.push({
        key: `blob|contact|${cc}`,
        cw: 128,
        ch: 128,
        draw: (p)=>fxContact(p, cc),
        x: x + ox * 0.03 * sc,
        y: y + 0.022,
        z: z + oz * 0.03 * sc,
        w: 0.52 * sc,
        h: 0.4 * sc,
        flat: true,
        rot
    });
};
const HENO = {
    jacket: "#d2833a",
    pants: "#3b3f52",
    boots: "#4a3426",
    hat: "peci",
    skin: SKINS[3],
    moustache: "#2a201a",
    build: "stout",
    buttons: "#e8c45a"
};
const NBO = {
    jacket: "#2f8a8a",
    pants: "#2e3440",
    boots: "#1f1f24",
    hat: "hair",
    hair: "#1b1b1f",
    skin: SKINS[1],
    build: "adult"
};
const KJ = [
    "#e2453c",
    "#3f8fd2",
    "#f2c230",
    "#4aa564",
    "#ef8a2c",
    "#9a5bd0",
    "#e46fa0",
    "#36b7b0",
    "#8c6a3c",
    "#e9e9ee"
];
const KP = [
    "#3b5b9a",
    "#5a4a3a",
    "#2f3b52",
    "#7a6a52"
];
const KC = [
    "#e2453c",
    "#2f6f9a",
    "#f2c230",
    "#4aa564"
];
const KIDO = Array.from({
    length: NKIDS
}, (_, i)=>({
        jacket: KJ[i],
        pants: KP[i % 4],
        boots: "#f4f1ea",
        build: "kid",
        skin: SKINS[1 + i % 3],
        hat: i % 3 === 0 ? "cap" : "hair",
        cap: KC[i % 4],
        hair: i % 2 ? "#1b1b1f" : "#4a3426"
    }));
const KS = 0.85;
const FRONT = {
    side: false,
    mirror: false
};
const lickPat = (t, k = 0, rate = 0.6, duty = 0.38)=>(t * rate + k) % 1 < duty;
const hendra = (cam, t, out)=>{
    let mode = "stand", y = TY, expr = "smile_closed", wave, prop = null;
    if (henSits(t)) {
        mode = "sit";
        y = TY + 0.05;
        expr = "relief";
    } else if (t >= 1.5 && t < 3.3) {
        wave = q(Math.sin(t * 11), 30);
    } else if (t >= 4.9 && t < 6.2) expr = "smile";
    else if (t >= 6.2 && t < 8.4) expr = "grin";
    else if (t >= T_CALL - 0.3 && t < 14.1) {
        wave = q(Math.sin(t * 8), 30);
        expr = lickPat(t, 0, 2, 0.6) ? "laugh" : "grin";
    } else if (t >= 14.3 && t < 16.6) {
        wave = 0.4 + 0.05 * Math.sin(t * 6);
        expr = "grin";
    } else if (t >= 16.6 && t < 20.7) expr = "grin";
    else if (t >= 20.7 && t < 22.6) {
        prop = "icecream";
        expr = "laugh";
    } else if (t >= 22.6) {
        prop = "icecream";
        expr = t >= 37.2 && t < 40 ? "grin" : lickPat(t, 0.2, 0.55, 0.35) ? "lick" : "smile_closed";
    }
    const fo = {
        mode,
        expr,
        wave,
        prop,
        blink: lidAt(t, 99),
        tilt: 0.8 * Math.sin(t * 1.6),
        look: 0
    };
    out.places.push(person(cam, {
        i: 99,
        o: HENO,
        okey: "hen"
    }, HEN[0], y, HEN[2], FRONT, fo, {}, 1));
    blob(out, HEN[0], TY, HEN[2], 1.05);
};
const neighbour = (cam, t, out)=>{
    const run = nbRun(t), WINDOW = t >= 31.55 && t < T_RUNOUT0 || t >= 47.35;
    if (WINDOW) {
        let expr = "neutral", shake = 0;
        if (t < 33.0) expr = "neutral";
        else if (t < 33.45) {
            expr = "shock";
            shake = 2.5;
        } else if (t < T_RUNOUT0) {
            expr = "nervous";
            shake = 3;
        } else if (t < 48.33) {
            expr = "nervous";
            shake = 2;
        } else {
            expr = "shock";
            shake = 3.5;
        }
        const fo = {
            mode: "stand",
            expr,
            blink: lidAt(t, 98),
            tilt: shake * Math.sin(t * 38),
            look: t >= 47.35 && t < 48.33 ? -1 : 0
        };
        out.places.push(person(cam, {
            i: 98,
            o: NBO,
            okey: "nb"
        }, WIN[0], WIN[1], WIN[2], FRONT, fo, {}, 1));
        const sw = t * 2.2 % 1;
        if (t >= 33.0 && t < T_RUNOUT0 || t >= 47.6) out.fx.push({
            key: `sweat${q(sw, 20)}`,
            cw: 300,
            ch: 300,
            draw: (p)=>fxSweat(p, q(sw, 20)),
            x: WIN[0] - 0.25,
            y: 4.78,
            z: WIN[2] + 0.1,
            w: 0.9,
            h: 0.9
        });
        if (t >= 33.0 && t < 33.7 || t >= 48.33 && t < 49.2) out.fx.push({
            key: "bang",
            cw: 200,
            ch: 260,
            draw: fxBang,
            x: WIN[0] - 0.25,
            y: 5.45,
            z: WIN[2] + 0.1,
            w: 0.32,
            h: 0.42,
            rot: 0.12
        });
    } else if (run.on && t < T_RUNOUT1 + 0.12) {
        const view = viewOf(cam, run.x, run.z, run.dx, run.dz), ph = q(t * 3.1 % 1, 60);
        const fo = {
            mode: "march",
            phase: ph,
            expr: "shock",
            lift: 85,
            blink: 0
        };
        const so = {
            mode: "march",
            phase: ph,
            expr: "shock",
            stomp: 1.5,
            stride: 1.5 * view.fs
        };
        out.places.push(person(cam, {
            i: 98,
            o: NBO,
            okey: "nb"
        }, run.x, 0, run.z, view, fo, so, 1));
        blob(out, run.x, 0, run.z, 1);
        out.fx.push({
            key: "speed",
            cw: 400,
            ch: 120,
            draw: fxSpeed,
            x: run.x - run.dx * 0.9,
            y: 0.8,
            z: run.z - run.dz * 0.9,
            w: 1.4,
            h: 0.42
        });
    }
};
const kids = (cam, t, out)=>{
    if (t < T_CALL - 0.1) return;
    const cones = t >= 27.0;
    for(let i = 0; i < NKIDS; i++){
        const k = kidAt(i, t), o = KIDO[i], who = {
            i: 300 + i,
            o,
            okey: `k${i}`
        };
        const running = k.mode === "run";
        let expr;
        if (t >= T_FLEE && t < 39) expr = t < T_FLEE + 1.4 ? "shock" : "nervous";
        else if (running) expr = i % 2 ? "laugh" : "grin";
        else if (k.cheer > 0.3) expr = "laugh";
        else if (cones) expr = lickPat(t, hh(i, 4), 0.7, 0.36) ? "lick" : "smile";
        else expr = i % 3 ? "grin" : "smile";
        const view = running ? viewOf(cam, k.x, k.z, k.dx, k.dz) : {
            ...FRONT,
            fs: 1
        };
        const prop = cones ? "icecream" : null;
        const wave = !prop && k.cheer > 0.3 ? q(Math.sin(t * 10 + i * 1.3), 30) : undefined;
        const blink = expr === "lick" ? 0 : lidAt(t, i + 5);
        const fo = {
            mode: running ? "march" : "stand",
            phase: q(k.phase, 60),
            expr,
            blink,
            wave,
            prop,
            lift: 70,
            tilt: running ? 0 : 1.6 * Math.sin(t * 2.1 + i),
            look: 0
        };
        const so = {
            mode: running ? "march" : "stand",
            phase: q(k.phase, 60),
            expr,
            blink,
            stomp: 1.1,
            stride: 0.95 * ("fs" in view ? view.fs : 1)
        };
        const pl = person(cam, who, k.x, k.hop, k.z, view, fo, so, KS);
        if (i === CONE_KID && cones && !running) {
            const dxs = -0.93 - k.x, dzs = 1.05 - k.z;
            if (cam.right.x * dxs + cam.right.z * dzs < 0) pl.mirror = true;
        }
        out.places.push(pl);
        blob(out, k.x, 0, k.z, KS, k.hop > 0 ? 0.6 : 1);
    }
};
const props = (id, t, out)=>{
    if (id >= 4) out.fx.push({
        key: "cones",
        cw: 360,
        ch: 260,
        draw: fxCones,
        x: -5.2,
        y: TY + 0.45 + 0.27,
        z: -2.3,
        w: 0.78,
        h: 0.56
    });
    if (t >= 7.0 && t < T_CALL) {
        out.fx.push({
            key: "bag|#3f8fd2",
            cw: 240,
            ch: 300,
            draw: (p)=>fxBag(p, "#3f8fd2"),
            x: -4.55,
            y: TY + 0.22,
            z: -1.95,
            w: 0.34,
            h: 0.42
        });
        out.fx.push({
            key: "bag|#e2453c",
            cw: 240,
            ch: 300,
            draw: (p)=>fxBag(p, "#e2453c"),
            x: -4.3,
            y: TY + 0.2,
            z: -1.55,
            w: 0.34,
            h: 0.42,
            rot: 0.12
        });
    }
    const gone = t >= 38.8, cx = gone ? CAR0[0] + 0.55 : MC[0], cz = gone ? CAR0[2] - 0.7 : MC[1];
    if (t >= T_ARRIVE - 0.6 && !(t >= T_FLEE && t < 38.8)) {
        out.fx.push({
            key: "chalk",
            cw: 600,
            ch: 600,
            draw: fxChalk,
            x: cx,
            y: 0.025,
            z: cz,
            w: 1.25,
            h: 1.25,
            flat: true
        });
        MARBLES.forEach((m, i)=>out.fx.push({
                key: `marble|${m.c}`,
                cw: 100,
                ch: 100,
                draw: (p)=>fxMarble(p, m.c),
                x: cx + m.dx * 0.9,
                y: 0.06,
                z: cz + m.dz * 0.9,
                w: 0.12,
                h: 0.12,
                rot: i
            }));
    }
    const mb = marbleAt(t);
    if (mb.on && t < CAR_T0 + 0.2) out.fx.push({
        key: "marble|#ff7ab8",
        cw: 100,
        ch: 100,
        draw: (p)=>fxMarble(p, "#ff7ab8"),
        x: mb.x,
        y: 0.075,
        z: mb.z,
        w: 0.15,
        h: 0.15,
        rot: t * 6
    });
    if (t >= 27.5 && t < T_FLEE) {
        const u = (t - 27.5) * 0.7 % 1, v = q(u, 20);
        out.fx.push({
            key: `drop${v}`,
            cw: 120,
            ch: 200,
            draw: (p)=>fxDrop(p, v),
            x: -0.8,
            y: 0.78 - 0.4 * u,
            z: 1.03,
            w: 0.08,
            h: 0.13
        });
        const w2 = clamp01((t - 28.8) / 1.5);
        out.fx.push({
            key: `drop${q(w2, 20)}b`,
            cw: 120,
            ch: 200,
            draw: (p)=>fxDrop(p, q(w2, 20)),
            x: -0.915,
            y: 0.72 - 0.15 * w2,
            z: 1.0,
            w: 0.07 + 0.05 * w2,
            h: 0.1 + 0.1 * w2
        });
    }
    if (t >= CAR_T0 && t < CAR_T1 + 0.3) {
        const c = carAt(t), hx = Math.sin(c.yaw), hz = Math.cos(c.yaw), u = clamp01((t - CAR_T0) / 0.5), v = q(u, 20);
        if (u < 1) out.fx.push({
            key: `puff${v}`,
            cw: 300,
            ch: 300,
            draw: (p)=>fxPuff(p, v),
            x: c.x - hx * 2.3,
            y: 0.25,
            z: c.z - hz * 2.3,
            w: 1.6,
            h: 1.6,
            soft: true
        });
        out.fx.push({
            key: "speed",
            cw: 400,
            ch: 120,
            draw: fxSpeed,
            x: c.x - hx * 2.9,
            y: 0.75,
            z: c.z - hz * 2.9,
            w: 2.2,
            h: 0.66
        });
    }
};
export const stage = (id, t, cam)=>{
    const out = {
        places: [],
        fx: []
    };
    LNAME = SHOTS[id - 1].light;
    findSun(cam, SUN);
    hendra(cam, t, out);
    neighbour(cam, t, out);
    kids(cam, t, out);
    props(id, t, out);
    return out;
};
export { FPS, smooth };
