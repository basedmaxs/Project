import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { Batch, boxGeo, V, lam, prop, house, quad, setSight } from "./build.js";
import { ctex, grassHD, cloudHD, rng } from "./paint.js";
import { LIGHTS, LOOK } from "./lights.js";
import { TONE, CHAR, twoTone, untone } from "./shade.js";
import { NOINK } from "./ink.js";
import { Pool, Actor, Fx, stage } from "./cast.js";
import { FPS, SHOTS, TY, CAR0, DOOR, T_DOOR, camAt, carAt, carGone, kickAt, smooth } from "./story.js";
const KENNEY = [
    "tree_oak",
    "tree_default",
    "tree_detailed",
    "tree_fat",
    "plant_bushLarge",
    "plant_bushDetailed",
    "plant_bush",
    "hedge"
];
let kitP = null;
export const loadKit = ()=>{
    if (!kitP) {
        const loader = new GLTFLoader();
        kitP = Promise.all(KENNEY.map((n)=>loader.loadAsync(`./kenney/${n}.glb`).then((g)=>[
                    n,
                    g.scene
                ]).catch(()=>[
                    n,
                    null
                ]))).then((list)=>Object.fromEntries(list.filter((e)=>e[1]).map(([n, s])=>[
                    n,
                    s
                ])));
    }
    return kitP;
};
const discTex = ()=>ctex("sunDisc", 128, 128, (g)=>{
        const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
        gr.addColorStop(0, "#fff");
        gr.addColorStop(0.85, "#fff");
        gr.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 128, 128);
    });
const haloTex = ()=>ctex("sunHalo", 256, 256, (g)=>{
        const gr = g.createRadialGradient(128, 128, 0, 128, 128, 128);
        gr.addColorStop(0, "rgba(255,255,255,.9)");
        gr.addColorStop(0.25, "rgba(255,255,255,.35)");
        gr.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 256, 256);
    });
const pavingTex = ()=>ctex("paving", 512, 512, (g, r)=>{
        g.fillStyle = "#7e7970";
        g.fillRect(0, 0, 512, 512);
        const bw = 64, bh = 32, tints = [
            "#b3ada2",
            "#aaa498",
            "#bab4a8",
            "#a39d91",
            "#b7aea0"
        ];
        for(let y = 0; y < 512 / bh; y++)for(let x = -1; x < 512 / bw + 1; x++){
            g.fillStyle = tints[Math.floor(r() * tints.length)];
            g.fillRect(x * bw + (y % 2 ? bw / 2 : 0) + 2, y * bh + 2, bw - 4, bh - 4);
        }
        g.fillStyle = "rgba(60,50,40,.05)";
        for(let i = 0; i < 40; i++)g.fillRect(r() * 512, r() * 512, 30 + r() * 60, 8 + r() * 16);
    });
const tileTex = ()=>ctex("terraceTile", 256, 256, (g, r)=>{
        g.fillStyle = "#a58c6c";
        g.fillRect(0, 0, 256, 256);
        for(let y = 0; y < 2; y++)for(let x = 0; x < 2; x++){
            g.fillStyle = [
                "#e0c9a3",
                "#dcc39b",
                "#e6d0ab"
            ][Math.floor(r() * 3)];
            g.fillRect(x * 128 + 3, y * 128 + 3, 122, 122);
        }
    });
const scratchTex = ()=>ctex("scratch", 512, 128, (g)=>{
        g.lineCap = "round";
        g.lineJoin = "round";
        const pts = [
            [
                24,
                78
            ],
            [
                90,
                50
            ],
            [
                150,
                84
            ],
            [
                215,
                46
            ],
            [
                280,
                82
            ],
            [
                350,
                52
            ],
            [
                420,
                80
            ],
            [
                488,
                48
            ]
        ];
        g.strokeStyle = "rgba(20,24,34,.9)";
        g.lineWidth = 14;
        g.beginPath();
        pts.forEach(([x, y], i)=>i ? g.lineTo(x, y + 2) : g.moveTo(x, y + 2));
        g.stroke();
        g.strokeStyle = "#f4f6fb";
        g.lineWidth = 7;
        g.beginPath();
        pts.forEach(([x, y], i)=>i ? g.lineTo(x, y) : g.moveTo(x, y));
        g.stroke();
    });
const boxLabelTex = ()=>ctex("esKrim", 256, 160, (g)=>{
        g.fillStyle = "#f5efe1";
        g.fillRect(0, 0, 256, 160);
        g.fillStyle = "#d63a4a";
        g.fillRect(0, 0, 256, 18);
        g.fillRect(0, 142, 256, 18);
        g.fillStyle = "#2a3d7a";
        g.font = "bold 62px sans-serif";
        g.textAlign = "center";
        g.textBaseline = "middle";
        g.fillText("ES KRIM", 128, 82);
        g.fillStyle = "#b8794a";
        g.beginPath();
        g.moveTo(104, 120);
        g.lineTo(152, 120);
        g.lineTo(128, 150);
        g.closePath();
        g.fill();
    });
const sightLines = ()=>{
    const out = [];
    for (const s of SHOTS)for(let f = s.a - 8; f < s.b + 8; f += 3){
        const c = camAt(s.id, Math.max(0, f)), o = V(...c.pos), look = V(...c.look);
        const fw = look.clone().sub(o), len = fw.length();
        fw.normalize();
        const rt = fw.clone().cross(V(0, 1, 0)).normalize(), up = rt.clone().cross(fw);
        const ty = Math.tan(c.fov * Math.PI / 360), tx = ty * (9 / 16);
        for (const [sx, sy] of [
            [
                0,
                0
            ],
            [
                -0.6,
                0
            ],
            [
                0.6,
                0
            ],
            [
                0,
                0.6
            ],
            [
                0,
                -0.4
            ]
        ])out.push({
            o,
            d: fw.clone().addScaledVector(rt, sx * tx).addScaledVector(up, sy * ty),
            len,
            core: sx === 0 && sy === 0
        });
    }
    return out;
};
const col = (hex, extra = {})=>lam("c" + hex, ()=>({
            color: hex,
            ...extra
        }));
const phong = (hex, spec = "#8a8a8a", shin = 60)=>twoTone(new THREE.MeshPhongMaterial({
        color: hex,
        specular: spec,
        shininess: shin
    }), 0.15);
function quadUp(x0, x1, z0, z1, u, v, y = 0) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute([
        x0,
        y,
        z1,
        x1,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z0
    ], 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute([
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0
    ], 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute([
        0,
        0,
        u,
        0,
        u,
        v,
        0,
        0,
        u,
        v,
        0,
        v
    ], 2));
    return g;
}
function prism(hx, y0, y1, zb0, zb1, zt0, zt1) {
    const g = new THREE.BufferGeometry();
    const P = [
        [
            -hx,
            y0,
            zb0
        ],
        [
            hx,
            y0,
            zb0
        ],
        [
            hx,
            y0,
            zb1
        ],
        [
            -hx,
            y0,
            zb1
        ],
        [
            -hx,
            y1,
            zt0
        ],
        [
            hx,
            y1,
            zt0
        ],
        [
            hx,
            y1,
            zt1
        ],
        [
            -hx,
            y1,
            zt1
        ]
    ];
    const faces = [
        [
            0,
            3,
            7,
            4
        ],
        [
            1,
            5,
            6,
            2
        ],
        [
            0,
            4,
            5,
            1
        ],
        [
            3,
            2,
            6,
            7
        ],
        [
            4,
            7,
            6,
            5
        ],
        [
            0,
            1,
            2,
            3
        ]
    ];
    const pos = [];
    for (const [a, b, c, d] of faces)for (const k of [
        a,
        b,
        c,
        a,
        c,
        d
    ])pos.push(...P[k]);
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.computeVertexNormals();
    return g;
}
export class World {
    root = new THREE.Group();
    pool = new Pool();
    actors = [];
    fxs = [];
    hemi;
    sun;
    fill;
    sky;
    skyMat;
    fog = new THREE.Fog("#bccbec", 25, 420);
    sunDisc;
    sunHalo;
    sunCache = new Map();
    cloudMaps;
    clouds = [];
    car = new THREE.Group();
    wheels = [];
    door = new THREE.Group();
    stool = new THREE.Group();
    frustum = new THREE.Frustum();
    m4 = new THREE.Matrix4();
    v = new THREE.Vector3();
    sph = new THREE.Sphere();
    constructor(kit){
        const R = this.root;
        this.skyMat = new THREE.ShaderMaterial({
            uniforms: {
                c0: {
                    value: new THREE.Color()
                },
                c1: {
                    value: new THREE.Color()
                },
                c2: {
                    value: new THREE.Color()
                },
                c3: {
                    value: new THREE.Color()
                },
                c4: {
                    value: new THREE.Color()
                },
                e: {
                    value: new THREE.Vector4()
                }
            },
            vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
            fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
            side: THREE.BackSide,
            depthWrite: false,
            fog: false
        });
        this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
        this.sky.renderOrder = -1;
        this.sky.frustumCulled = false;
        this.sky.layers.set(NOINK);
        R.add(this.sky);
        this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({
            map: discTex(),
            color: new THREE.Color(6.0, 4.4, 2.4),
            fog: false,
            depthWrite: false
        }));
        this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({
            map: haloTex(),
            color: new THREE.Color(1, 1, 1),
            fog: false,
            depthWrite: false,
            depthTest: true,
            transparent: true,
            blending: THREE.AdditiveBlending
        }));
        this.sunDisc.renderOrder = -0.5;
        this.sunHalo.renderOrder = 5;
        for (const m of [
            this.sunDisc,
            this.sunHalo
        ]){
            m.frustumCulled = false;
            m.layers.set(NOINK);
            R.add(m);
        }
        this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
        this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
        this.sun.castShadow = true;
        this.sun.shadow.mapSize.set(4096, 4096);
        this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
        R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
        this.cloudMaps = {
            day: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.day.cloud)),
            golden: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.golden.cloud))
        };
        for(let i = 0; i < 9; i++){
            const a = i / 9 * Math.PI * 2 + 0.3, d = 620 + i % 3 * 60;
            const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({
                map: this.cloudMaps.day[i % 4],
                color: new THREE.Color(1.1, 1.1, 1.1),
                transparent: true,
                depthWrite: false,
                fog: false
            }));
            const w = 130 + i % 4 * 30;
            m.position.set(Math.cos(a) * d, 120 + i % 4 * 38, Math.sin(a) * d);
            m.scale.set(w, w / 2, 1);
            m.layers.set(NOINK);
            this.clouds.push(m);
            R.add(m);
        }
        setSight(sightLines());
        const b = new Batch();
        const bx = (x0, x1, y0, y1, z0, z1, m, tile = 0)=>b.add(boxGeo(V(x0, y0, z0), V(x1, y1, z1), tile), m);
        const grass = lam("grassHD", ()=>({
                map: grassHD()
            }));
        const paving = lam("paving", ()=>({
                map: pavingTex()
            }));
        const slab = col("#cbc5b6"), curb = col("#bdb7aa"), drain = col("#6c6e74");
        b.add(quadUp(-400, 400, -400, 400, 200, 200, 0), grass);
        b.add(quadUp(-2.8, 2.8, -100, 100, 3.5, 125, 0.012), paving);
        for (const s of [
            -1,
            1
        ]){
            bx(s < 0 ? -3.15 : 2.8, s < 0 ? -2.8 : 3.15, 0, 0.14, -100, 100, curb);
            bx(s < 0 ? -4.0 : 3.15, s < 0 ? -3.15 : 4.0, 0, 0.1, -100, 100, slab);
            bx(s < 0 ? -2.95 : 2.8, s < 0 ? -2.8 : 2.95, 0.0, 0.015, -100, 100, drain);
        }
        const tile = lam("terraceTile", ()=>({
                map: tileTex()
            })), cream = col("#e8dcc0"), terra = col("#b5614a"), potC = col("#b8684a"), leaf = col("#4c9a37");
        b.add(boxGeo(V(-6.2, 0, -3.2), V(-3.9, TY, 3.2), 1.2), tile);
        bx(-3.95, -3.55, 0, 0.18, -1.0, 1.0, col("#cfc6b3"));
        bx(-4.2, -4.0, 0, 2.6, -3.15, -2.95, cream);
        bx(-4.2, -4.0, 0, 2.6, 2.95, 3.15, cream);
        bx(-6.4, -3.85, 2.6, 2.78, -3.4, 3.4, terra);
        bx(-3.9, -3.82, 2.5, 2.6, -3.4, 3.4, terra);
        for (const z of [
            3.05
        ]){
            b.add(new THREE.CylinderGeometry(0.2, 0.15, 0.34, 10), potC, new THREE.Matrix4().makeTranslation(-4.5, TY + 0.17, z * 0.93));
            b.add(new THREE.SphereGeometry(0.36, 10, 8), leaf, new THREE.Matrix4().makeTranslation(-4.5, TY + 0.62, z * 0.93));
        }
        const stoolM = col("#c93b3b");
        const sb = (x0, x1, y0, y1, z0, z1)=>{
            const m = new THREE.Mesh(boxGeo(V(x0, y0, z0), V(x1, y1, z1)), stoolM);
            m.castShadow = true;
            m.receiveShadow = true;
            this.stool.add(m);
        };
        sb(-4.95, -4.45, TY + 0.15, TY + 0.2, -1.55, -1.05);
        for (const [dx, dz] of [
            [
                -4.9,
                -1.5
            ],
            [
                -4.5,
                -1.5
            ],
            [
                -4.9,
                -1.1
            ],
            [
                -4.5,
                -1.1
            ]
        ])sb(dx - 0.03, dx + 0.03, TY, TY + 0.15, dz - 0.03, dz + 0.03);
        R.add(this.stool);
        const card = col("#b88a54"), cardD = col("#8f6a3c");
        bx(-5.55, -4.85, TY, TY + 0.04, -2.6, -2.0, cardD);
        bx(-5.55, -5.5, TY, TY + 0.45, -2.6, -2.0, card);
        bx(-4.9, -4.85, TY, TY + 0.45, -2.6, -2.0, card);
        bx(-5.55, -4.85, TY, TY + 0.45, -2.6, -2.55, card);
        bx(-5.55, -4.85, TY, TY + 0.45, -2.05, -2.0, card);
        for (const s of [
            -1,
            1
        ])b.add(boxGeo(V(-5.58, 0, -0.012), V(-4.82, 0.02, 0.012)), card, new THREE.Matrix4().makeRotationX(s * 0.5).setPosition(0, TY + 0.47, -2.3 + s * 0.35));
        house(b, -9.2, 0, Math.PI / 2, 7, 6, 3.2, 3);
        const hs = [
            3.2,
            5.6,
            3.2,
            5.6,
            3.2,
            3.2,
            5.6,
            3.2
        ];
        [
            -48,
            -40,
            -32,
            -24,
            -16,
            -7.9,
            7.9,
            16,
            24,
            32,
            40,
            48
        ].forEach((z, i)=>house(b, -9.2, z, Math.PI / 2, 7, 6, hs[i % 8], (i * 3 + 1) % 8));
        [
            -48,
            -40,
            -32,
            -24,
            -16,
            -9,
            12.5,
            20.5,
            28.5,
            36.5,
            44.5
        ].forEach((z, i)=>house(b, 8.6, z, -Math.PI / 2, 7, 6, hs[(i + 3) % 8], (i * 5 + 2) % 8));
        house(b, 0, -65, 0, 18, 6, 5.6, 4);
        house(b, 0, 65, Math.PI, 18, 6, 5.6, 6);
        for (const [x, z, h] of [
            [
                -5.1,
                -12,
                6
            ],
            [
                -5.3,
                13,
                7
            ],
            [
                -5.0,
                -26,
                6.5
            ],
            [
                -5.2,
                28,
                6
            ],
            [
                4.7,
                -15,
                6
            ],
            [
                4.9,
                18,
                6.5
            ],
            [
                4.6,
                -30,
                7
            ],
            [
                4.8,
                32,
                6
            ]
        ])prop(b, kit, "tree_default", x, 0, z, h, x * z);
        for (const z of [
            -14,
            11,
            26,
            -30,
            40
        ]){
            const x = z % 2 ? 3.35 : -3.35;
            bx(x - 0.1, x + 0.1, 0, 7, z - 0.1, z + 0.1, col("#7a6a58"));
            bx(x - 0.6, x + 0.6, 6.4, 6.55, z - 0.05, z + 0.05, col("#7a6a58"));
        }
        const wall = col("#e6dfcd"), clad = col("#6e747d"), roofM = col("#5d626b"), inner = col("#e6d3ab"), garW = col("#9a948a"), trim = col("#e8e2d4");
        const X0 = 5.6, X1 = 5.9;
        const front = [
            [
                -4.5,
                -2.2,
                0,
                3.3,
                wall
            ],
            [
                -2.2,
                1.8,
                2.5,
                3.3,
                clad
            ],
            [
                1.8,
                3.0,
                0,
                3.3,
                wall
            ],
            [
                3.0,
                4.2,
                2.2,
                3.3,
                wall
            ],
            [
                4.2,
                8.0,
                0,
                3.3,
                wall
            ],
            [
                -4.5,
                -1.5,
                3.3,
                6.3,
                wall
            ],
            [
                1.1,
                8.0,
                3.3,
                6.3,
                wall
            ],
            [
                -1.5,
                1.1,
                3.3,
                3.95,
                wall
            ],
            [
                -1.5,
                1.1,
                5.55,
                6.3,
                wall
            ]
        ];
        for (const [z0, z1, y0, y1, m] of front)bx(X0, X1, y0, y1, z0, z1, m);
        bx(X0, 13.6, 3.0, 3.3, -4.5, 8.0, clad);
        bx(X0, 13.6, 0, 6.3, -4.5, -4.2, wall);
        bx(X0, 13.6, 0, 6.3, 7.7, 8.0, wall);
        bx(13.3, 13.6, 0, 6.3, -4.5, 8.0, wall);
        bx(5.4, 13.8, 6.3, 6.6, -4.7, 8.2, roofM);
        bx(X1, 10.3, 5.9, 6.0, -2.0, 1.8, inner);
        bx(X1, 12.5, 0, 3.0, -2.5, -2.2, garW);
        bx(X1, 12.5, 0, 3.0, 1.8, 2.1, garW);
        bx(12.2, 12.5, 0, 3.0, -2.5, 2.1, garW);
        bx(X1, 12.2, 0.0, 0.02, -2.2, 1.8, col("#b9b4a8"));
        bx(5.55, 5.85, 2.45, 2.62, -2.2, 1.8, col("#7d8791"));
        b.add(quadUp(3.1, 5.6, -2.2, 1.8, 2.5, 4, 0.016), slab);
        bx(X1, 10.3, 3.3, 6.3, -2.0, -1.9, inner);
        bx(X1, 10.3, 3.3, 6.3, 1.7, 1.8, inner);
        bx(10.0, 10.3, 3.3, 6.3, -2.0, 1.8, inner);
        bx(5.95, 6.12, 3.95, 5.78, -1.5, -1.0, col("#b8445a"));
        bx(5.95, 6.12, 3.95, 5.78, 0.6, 1.1, col("#b8445a"));
        bx(5.3, 5.9, 3.9, 3.98, -1.65, 1.25, trim);
        bx(5.5, 5.9, 5.55, 5.62, -1.55, 1.15, col("#3b3f46"));
        bx(X1, 7.5, 0, 3.0, 2.9, 3.0, col("#c9bda2"));
        bx(X1, 7.5, 0, 3.0, 4.2, 4.3, col("#c9bda2"));
        bx(7.4, 7.5, 0, 3.0, 2.9, 4.3, col("#7a6850"));
        b.build(R);
        const doorM = col("#6a4a32", {
            side: THREE.DoubleSide
        });
        const leaf2 = new THREE.Mesh(boxGeo(V(-0.04, 0, 0), V(0.04, 2.2, 1.2)), doorM);
        leaf2.castShadow = true;
        leaf2.receiveShadow = true;
        this.door.add(leaf2);
        this.door.position.set(5.72, 0, 3.0);
        R.add(this.door);
        const label = new THREE.Mesh(quad(V(-4.848, TY + 0.06, -2.05), V(-4.848, TY + 0.06, -2.55), V(-4.848, TY + 0.4, -2.55), V(-4.848, TY + 0.4, -2.05)), new THREE.MeshBasicMaterial({
            map: boxLabelTex(),
            color: 0xe8e8e8,
            side: THREE.DoubleSide
        }));
        label.layers.set(NOINK);
        R.add(label);
        const body = phong("#3f62b5", "#d0dcff", 80), glass = phong("#27324a", "#9fb0d8", 90), tire = col("#15161b"), hub = phong("#cfd3d9", "#ffffff", 90);
        const chrome = phong("#c9ced6", "#ffffff", 90), lamp = col("#fff4cf"), tail = col("#d6283a"), dark = col("#1b1e26");
        const add = (g, m, x = 0, y = 0, z = 0)=>{
            const mesh = new THREE.Mesh(g, m);
            mesh.position.set(x, y, z);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            this.car.add(mesh);
            return mesh;
        };
        const box = (x0, x1, y0, y1, z0, z1)=>boxGeo(V(x0, y0, z0), V(x1, y1, z1), 0, true);
        add(box(-0.92, 0.92, 0.3, 0.95, -2.3, 2.3), body);
        add(prism(0.86, 0.95, 1.5, -1.75, 1.25, -1.3, 0.5), body);
        add(prism(0.855, 1.0, 1.44, -1.6, 1.05, -1.2, 0.42), glass);
        add(box(-0.7, 0.7, 0.55, 0.78, 2.3, 2.34), chrome);
        for (const s of [
            -1,
            1
        ]){
            add(box(s * 0.72 - 0.2, s * 0.72 + 0.2, 0.7, 0.82, 2.29, 2.34), lamp);
            add(box(s * 0.72 - 0.2, s * 0.72 + 0.2, 0.74, 0.86, -2.34, -2.29), tail);
            add(box(s * 0.93 - 0.04, s * 0.93 + 0.04, 0.94, 1.04, 0.5, 0.75), body);
        }
        add(box(-0.93, 0.93, 0.28, 0.42, 2.05, 2.34), dark);
        add(box(-0.93, 0.93, 0.28, 0.42, -2.34, -2.05), dark);
        add(box(-0.925, 0.925, 0.55, 0.57, -0.5, 1.9), dark);
        add(box(-0.925, 0.925, 0.5, 1.0, 0.0, 0.03), dark);
        const cyl = new THREE.CylinderGeometry(0.36, 0.36, 0.26, 14);
        cyl.rotateZ(Math.PI / 2);
        const hubG = new THREE.CylinderGeometry(0.2, 0.2, 0.05, 12);
        hubG.rotateZ(Math.PI / 2);
        for (const sx of [
            -1,
            1
        ])for (const z of [
            -1.45,
            1.45
        ]){
            const w = new THREE.Group();
            w.position.set(sx * 0.8, 0.36, z);
            const t = new THREE.Mesh(cyl, tire);
            t.castShadow = true;
            w.add(t);
            const hb = new THREE.Mesh(hubG, hub);
            hb.position.x = sx * 0.12;
            w.add(hb);
            this.car.add(w);
            this.wheels.push(w);
        }
        const sm = new THREE.MeshBasicMaterial({
            map: scratchTex(),
            transparent: true,
            alphaTest: 0.5
        });
        for (const s of [
            -1,
            1
        ]){
            const sc = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.375), sm);
            sc.position.set(s * 0.931, 0.66, 0.3);
            sc.rotation.y = s * Math.PI / 2;
            sc.layers.set(NOINK);
            this.car.add(sc);
        }
        R.add(this.car);
        this.car.position.set(CAR0[0], 0, CAR0[2]);
        this.car.rotation.y = Math.PI;
    }
    shotSun(id, s, L) {
        let v = this.sunCache.get(id);
        if (v) return v;
        let fx = 0, fz = 0;
        for(let f = s.a; f < s.b; f += 3){
            const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
            fx += x / n;
            fz += z / n;
        }
        const n = Math.hypot(fx, fz) || 1;
        fx /= n;
        fz /= n;
        const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
        const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
        v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
        this.sunCache.set(id, v);
        return v;
    }
    actor(i) {
        while(this.actors.length <= i)this.actors.push(new Actor(this.root));
        return this.actors[i];
    }
    fx(i) {
        while(this.fxs.length <= i)this.fxs.push(new Fx(this.root));
        return this.fxs[i];
    }
    update(id, f, cam, scene) {
        const t = f / FPS, s = SHOTS[id - 1], L = LIGHTS[s.light];
        const c = camAt(id, f);
        cam.position.set(...c.pos);
        cam.up.set(0, 1, 0);
        cam.lookAt(...c.look);
        cam.rotateZ(c.roll);
        cam.fov = c.fov;
        cam.near = 0.1;
        cam.far = 1500;
        cam.updateProjectionMatrix();
        cam.updateMatrixWorld();
        const focus = V(...c.look), dist = cam.position.distanceTo(focus);
        cam.layers.enable(NOINK);
        const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
        this.hemi.color.set(L.sky);
        this.hemi.groundColor.set(L.ground);
        this.hemi.intensity = L.hemiI;
        this.sun.color.set(L.sunCol);
        this.sun.intensity = L.sunI;
        let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
        if (s.light === "golden") Rr = Math.max(Rr, 30);
        this.sun.position.copy(focus).addScaledVector(sunDir, 220);
        this.sun.target.position.copy(focus);
        const sc = this.sun.shadow.camera;
        sc.left = -Rr;
        sc.right = Rr;
        sc.top = Rr;
        sc.bottom = -Rr;
        sc.near = 20;
        sc.far = 480;
        sc.updateProjectionMatrix();
        this.sun.shadow.bias = L.bias;
        this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
        this.fill.intensity = 0;
        TONE.uLitCol.value.set(...L.lit);
        TONE.uShadeCol.value.set(...L.shade);
        TONE.uShadeLift.value.set(...L.lift);
        TONE.uLambert.value = L.lambert;
        TONE.uSideK.value = L.sideK;
        TONE.uTerm.value = L.term;
        TONE.uBounce.value.set(...LOOK[s.light].bounce);
        TONE.uSat.value = LOOK[s.light].sat;
        CHAR.uCharTint.value.set(...L.charTint);
        CHAR.uCharShade.value = L.charShade;
        CHAR.uGrad.value = L.charGrad;
        CHAR.uBodyGrad.value = L.bodyGrad;
        CHAR.uSideTint.value.set(...L.sideTint);
        const su = this.skyMat.uniforms;
        K.sky.c.forEach((h, i)=>untone(h, su["c" + i].value));
        const e = K.sky.e.map((deg)=>THREE.MathUtils.degToRad(deg));
        su.e.value.set(e[1], e[2], e[3], e[4]);
        this.sky.position.copy(cam.position);
        untone(L.fog, this.fog.color);
        this.fog.near = L.fogNear;
        this.fog.far = L.fogFar;
        scene.fog = this.fog;
        scene.background = null;
        const showSun = s.light === "golden";
        this.sunDisc.visible = this.sunHalo.visible = showSun;
        if (showSun) {
            this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
            this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
            this.sunHalo.position.copy(this.sunDisc.position);
            this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
            this.sunHalo.material.color.set(L.sunDisc).multiplyScalar(1.3);
        }
        for(let i = 0; i < this.clouds.length; i++){
            const m = this.clouds[i], mat = m.material;
            m.lookAt(cam.position.x, m.position.y, cam.position.z);
            mat.map = this.cloudMaps[s.light][i % 4];
        }
        const ca = carAt(t);
        this.car.position.set(ca.x, 0, ca.z);
        this.car.rotation.y = ca.yaw;
        const roll = ca.s / 0.36;
        for (const w of this.wheels)w.children[0].rotation.x = -roll;
        this.car.rotation.x = ca.s > 0.1 && ca.s < 5 ? -0.02 : 0;
        this.door.rotation.y = -1.7 * smooth((t - T_DOOR) / 0.2);
        this.door.visible = true;
        this.stool.visible = t >= 8.3 && t < 9.7;
        const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
        const st = stage(id, t, {
            pos: cam.position,
            right
        });
        this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
        const tint = s.light === "golden" ? "#ffcf9e" : "#ffffff";
        let ai = 0;
        const used = [];
        for (const p of st.places){
            const sc2 = p.scale ?? 1;
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
            const a = this.actor(ai++);
            const [w, h, k] = p.size ?? [
                300,
                500,
                0.5
            ];
            a.r = this.pool.req(p.key, w, h, k, p.draw);
            a.mesh.visible = true;
            a.mesh.position.set(p.x, p.y, p.z);
            a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
            a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
            if (a.mat.emissiveMap) a.mat.emissive.set(tint);
            a.mesh.castShadow = L.actorShadow;
            used.push(a);
        }
        for(let i = ai; i < this.actors.length; i++)this.actors[i].mesh.visible = false;
        let fi = 0;
        const fused = [];
        for (const p of st.fx){
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
            const e2 = this.fx(fi++);
            e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
            e2.use(!!p.soft);
            e2.mesh.visible = true;
            e2.mesh.position.set(p.x, p.y, p.z);
            if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
            else {
                e2.mesh.quaternion.copy(cam.quaternion);
                e2.mesh.rotateZ(p.rot ?? 0);
            }
            e2.mesh.scale.set(p.w, p.h, 1);
            fused.push(e2);
        }
        for(let i = fi; i < this.fxs.length; i++)this.fxs[i].mesh.visible = false;
        this.pool.flush();
        for (const a of used)a.bind();
        for (const e2 of fused)e2.bind();
        void kickAt;
        void carGone;
        void DOOR;
        void rng;
        return focus;
    }
}
